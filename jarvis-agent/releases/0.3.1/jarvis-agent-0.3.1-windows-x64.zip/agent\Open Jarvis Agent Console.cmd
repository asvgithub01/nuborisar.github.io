@echo off
setlocal
if not defined JARVIS_AGENT_LOG_DIR set "JARVIS_AGENT_LOG_DIR=%~dp0logs"
cd /d "%~dp0"
node agent-console.js
