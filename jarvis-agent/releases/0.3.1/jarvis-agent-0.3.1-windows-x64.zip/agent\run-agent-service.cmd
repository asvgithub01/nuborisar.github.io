@echo off
if not defined JARVIS_AGENT_LOG_DIR set "JARVIS_AGENT_LOG_DIR=%~dp0logs"
if not exist "%JARVIS_AGENT_LOG_DIR%" mkdir "%JARVIS_AGENT_LOG_DIR%"
cd /d "%~dp0"
node agent.js >> "%JARVIS_AGENT_LOG_DIR%\agent.log" 2>&1
