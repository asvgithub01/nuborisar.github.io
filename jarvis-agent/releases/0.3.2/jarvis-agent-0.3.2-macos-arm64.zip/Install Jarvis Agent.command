#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [[ -f "${SCRIPT_DIR}/agent/installers/macos/install-agent.sh" ]]; then
  PACKAGE_ROOT="$SCRIPT_DIR"
  MAC_INSTALLER_DIR="${SCRIPT_DIR}/agent/installers/macos"
  DEV_INSTALLER="${SCRIPT_DIR}/agent/installers/dev-platform/macos/install-dev-platform.sh"
else
  PACKAGE_ROOT="$(cd "${SCRIPT_DIR}/../../.." && pwd)"
  MAC_INSTALLER_DIR="$SCRIPT_DIR"
  DEV_INSTALLER="${SCRIPT_DIR}/../dev-platform/macos/install-dev-platform.sh"
fi

DEFAULT_BACKEND_URL="${JARVIS_DEFAULT_BACKEND_URL:-http://localhost:8080}"
DEFAULT_AGENT_TOKEN="${JARVIS_DEFAULT_AGENT_TOKEN:-}"
DEFAULT_WORKSPACE_ROOT="${JARVIS_DEFAULT_WORKSPACE_ROOT:-$HOME/Projects}"
DEFAULT_DISPLAY_NAME="${JARVIS_DEFAULT_DISPLAY_NAME:-Jarvis MacBook (agente 2)}"
DEFAULT_AGENT_VERSION="${JARVIS_DEFAULT_AGENT_VERSION:-dev}"
EXISTING_CONFIG="$HOME/Library/Application Support/JarvisAgent/app/.env"

read_defaults_file() {
  local defaults_file=""
  for candidate in "${SCRIPT_DIR}/installer-defaults.env" "${PACKAGE_ROOT}/installer-defaults.env"; do
    if [[ -f "$candidate" ]]; then defaults_file="$candidate"; break; fi
  done
  [[ -z "$defaults_file" ]] && return 0

  while IFS='=' read -r key value; do
    [[ -z "$key" || "$key" == \#* ]] && continue
    case "$key" in
      JARVIS_DEFAULT_BACKEND_URL) DEFAULT_BACKEND_URL="$value" ;;
      JARVIS_DEFAULT_AGENT_TOKEN) DEFAULT_AGENT_TOKEN="$value" ;;
      JARVIS_DEFAULT_WORKSPACE_ROOT) DEFAULT_WORKSPACE_ROOT="${value/#\~/$HOME}" ;;
      JARVIS_DEFAULT_DISPLAY_NAME) DEFAULT_DISPLAY_NAME="$value" ;;
      JARVIS_DEFAULT_AGENT_VERSION) DEFAULT_AGENT_VERSION="$value" ;;
    esac
  done < "$defaults_file"
}

pause_before_close() {
  local code="$?"
  echo
  if [[ "$code" -eq 0 ]]; then
    echo "Instalacion finalizada. Ya puedes cerrar esta ventana."
  else
    echo "La instalacion termino con error (codigo ${code}). Revisa el mensaje anterior."
  fi
  if [[ -t 0 ]]; then read -r -p "Pulsa Enter para cerrar..." _ || true; fi
  exit "$code"
}
trap pause_before_close EXIT

if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "ERROR: este instalador solo funciona en macOS." >&2
  exit 1
fi

read_defaults_file
if [[ -f "$EXISTING_CONFIG" ]]; then
  existing_value() {
    local key="$1"
    sed -n "s/^${key}=//p" "$EXISTING_CONFIG" | head -n 1
  }
  DEFAULT_BACKEND_URL="$(existing_value JARVIS_BASE_URL || true)"
  DEFAULT_BACKEND_URL="${DEFAULT_BACKEND_URL:-${JARVIS_DEFAULT_BACKEND_URL:-http://localhost:8080}}"
  DEFAULT_AGENT_TOKEN="$(existing_value JARVIS_AGENT_TOKEN || true)"
  DEFAULT_AGENT_TOKEN="${DEFAULT_AGENT_TOKEN:-${JARVIS_DEFAULT_AGENT_TOKEN:-}}"
  DEFAULT_WORKSPACE_ROOT="$(existing_value JARVIS_WORKSPACE_ROOTS || true)"
  DEFAULT_WORKSPACE_ROOT="${DEFAULT_WORKSPACE_ROOT:-${JARVIS_DEFAULT_WORKSPACE_ROOT:-$HOME/Projects}}"
  DEFAULT_DISPLAY_NAME="$(existing_value JARVIS_AGENT_DISPLAY_NAME || true)"
  DEFAULT_DISPLAY_NAME="${DEFAULT_DISPLAY_NAME:-${JARVIS_DEFAULT_DISPLAY_NAME:-Jarvis MacBook (agente 2)}}"
fi
clear || true
cat <<'BANNER'
============================================================
  JARVIS - INSTALADOR DEL SEGUNDO AGENTE PARA MACBOOK
============================================================

Instala el worker, lo registra con un id unico y lo deja
arrancando automaticamente con tu sesion de macOS.
BANNER

if [[ ! -x "$DEV_INSTALLER" || ! -f "${MAC_INSTALLER_DIR}/install-agent.sh" ]]; then
  echo "ERROR: el ZIP esta incompleto; faltan scripts de instalacion." >&2
  exit 1
fi

if ! command -v node >/dev/null 2>&1 || ! command -v git >/dev/null 2>&1; then
  echo
  echo "Faltan Node.js o Git. Se instalaran con Homebrew."
  "$DEV_INSTALLER" --yes --skip-npm-globals
fi

if ! command -v codex >/dev/null 2>&1; then
  echo
  read -r -p "Codex CLI no esta instalado. Instalar Codex, Claude y OpenCode ahora? [S/n]: " install_clis
  case "$install_clis" in
    n|N|no|NO) echo "Se continua sin CLIs; el agente arrancara pero no ejecutara esas tareas." ;;
    *) "$DEV_INSTALLER" --yes ;;
  esac
fi

if [[ ! -d "/Applications/Android Studio.app/Contents/jbr/Contents/Home" \
   && ! -d "/opt/homebrew/opt/openjdk@21/libexec/openjdk.jdk/Contents/Home" \
   && ! -d "/usr/local/opt/openjdk@21/libexec/openjdk.jdk/Contents/Home" ]]; then
  echo
  echo "No se encontro JDK 17/21 compatible para Gradle. Se instalara OpenJDK 21."
  "$DEV_INSTALLER" --yes --skip-npm-globals
fi

echo
read -r -p "URL del backend Jarvis [${DEFAULT_BACKEND_URL}]: " backend_url
backend_url="${backend_url:-$DEFAULT_BACKEND_URL}"

read -r -s -p "Token del agente${DEFAULT_AGENT_TOKEN:+ [pulsa Enter para conservar el actual]}: " agent_token
echo
agent_token="${agent_token:-$DEFAULT_AGENT_TOKEN}"
if [[ -z "$agent_token" ]]; then
  echo "ERROR: el ZIP publico no incluye credenciales; introduce el token del agente." >&2
  exit 1
fi

read -r -p "Nombre visible [${DEFAULT_DISPLAY_NAME}]: " display_name
display_name="${display_name:-$DEFAULT_DISPLAY_NAME}"

echo
if [[ -f "$EXISTING_CONFIG" ]]; then
  echo "Actualizacion detectada: se conserva el vinculo actual con tu cuenta de Ops."
  read -r -p "Nuevo codigo de vinculacion [Enter para conservar el vinculo actual]: " pairing_code
else
  echo "En Ops > Settings > Cuenta y agentes, genera un codigo de vinculacion."
  read -r -p "Codigo de vinculacion (JARVIS-XXXX-XXXX): " pairing_code
fi
if [[ -z "$pairing_code" && ! -f "$EXISTING_CONFIG" ]]; then
  echo "ERROR: necesitas el codigo para vincular un agente nuevo a tu cuenta de Ops." >&2
  exit 1
fi

read -r -p "Carpeta raiz de repositorios [${DEFAULT_WORKSPACE_ROOT}]: " workspace_root
workspace_root="${workspace_root:-$DEFAULT_WORKSPACE_ROOT}"
workspace_root="${workspace_root/#\~/$HOME}"

agent_id="$(hostname -s 2>/dev/null || hostname)-jarvis-agent-02"
echo
echo "Configuracion:"
echo "  Backend:    ${backend_url}"
echo "  Agent id:   ${agent_id}"
echo "  Nombre:     ${display_name}"
echo "  Version:    ${DEFAULT_AGENT_VERSION}"
echo "  Cuenta Ops: se vinculara mediante codigo de un solo uso"
echo "  Proyectos:  ${workspace_root}"
echo
read -r -p "Instalar y arrancar este segundo agente? [S/n]: " confirm
case "$confirm" in n|N|no|NO) echo "Instalacion cancelada."; exit 0 ;; esac

install_args=(
  --backend-url "$backend_url"
  --token "$agent_token"
  --agent-id "$agent_id"
  --display-name "$display_name"
  --agent-version "$DEFAULT_AGENT_VERSION"
  --workspace-root "$workspace_root"
  --non-interactive
  --force
)
[[ -n "$pairing_code" ]] && install_args+=(--pairing-code "$pairing_code")
"${MAC_INSTALLER_DIR}/install-agent.sh" "${install_args[@]}"

sleep 3
echo
"${MAC_INSTALLER_DIR}/doctor-agent.sh"

cat <<NEXT

El segundo agente queda activo en segundo plano y arrancara al iniciar sesion.
Los repositorios Git existentes en tu Mac ya se han detectado automaticamente.

Para que pueda trabajar:
  1. Guarda/clona nuevos repositorios donde quieras.
  2. Para actualizar la lista abre:
     $HOME/Applications/Jarvis Agent/Scan Jarvis Projects.command
  3. Autentica Codex si aun no lo hiciste: codex
  4. Autentica GitHub para push/PR: gh auth login

Log:
  tail -f "$HOME/Library/Application Support/JarvisAgent/logs/agent.log"
NEXT
