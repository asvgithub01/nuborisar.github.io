#!/usr/bin/env node
"use strict";

const fs = require("node:fs");
const path = require("node:path");
const os = require("node:os");
const { spawn, spawnSync } = require("node:child_process");

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function parentIsAlive(pid) {
  try {
    process.kill(pid, 0);
    return true;
  } catch (_error) {
    return false;
  }
}

async function main() {
  const parentPid = Number.parseInt(process.argv[2] || "0", 10);
  const appDir = path.resolve(process.argv[3] || __dirname);
  const logFile = path.resolve(process.argv[4] || path.join(appDir, "logs", "agent.log"));
  const expectedVersion = String(process.argv[5] || "").trim();
  const backupRoot = path.resolve(process.argv[6] || path.join(appDir, "update-backup-missing"));
  const statusFile = path.resolve(process.argv[7] || path.join(path.dirname(logFile), "runtime-status.json"));
  const healthTimeoutMs = readPositiveInteger(
    process.env.JARVIS_AGENT_UPDATE_HEALTH_TIMEOUT_MS,
    120_000,
    1_000
  );
  const deadline = Date.now() + 60_000;
  while (parentPid > 0 && parentIsAlive(parentPid) && Date.now() < deadline) {
    await sleep(500);
  }

  if (process.platform !== "darwin") startAgent(appDir, logFile);
  const healthy = await waitForHealthyVersion(statusFile, expectedVersion, parentPid, healthTimeoutMs);
  if (healthy) {
    writeResult(logFile, {
      success: true,
      version: expectedVersion,
      verifiedAt: new Date().toISOString(),
    });
    return;
  }

  const status = readJson(statusFile);
  if (status?.pid && Number(status.pid) !== parentPid) {
    try { process.kill(Number(status.pid), "SIGTERM"); } catch (_error) { /* already stopped */ }
    await sleep(1_500);
  }
  if (!fs.existsSync(path.join(backupRoot, "agent.js"))) {
    throw new Error(`Updated agent did not become healthy and backup is missing: ${backupRoot}`);
  }

  if (process.platform === "darwin") stopMacLaunchAgent();
  copyTree(backupRoot, appDir);
  if (process.platform === "darwin") restartMacLaunchAgent();
  else startAgent(appDir, logFile);
  writeResult(logFile, {
    success: false,
    rolledBack: true,
    failedVersion: expectedVersion,
    restoredFrom: backupRoot,
    rolledBackAt: new Date().toISOString(),
  });
}

function readPositiveInteger(raw, fallback, minimum = 1) {
  const parsed = Number.parseInt(String(raw || ""), 10);
  return Number.isFinite(parsed) && parsed >= minimum ? parsed : fallback;
}

function readJson(filePath) {
  try { return JSON.parse(fs.readFileSync(filePath, "utf8")); } catch (_error) { return null; }
}

async function waitForHealthyVersion(statusFile, expectedVersion, parentPid, timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    const status = readJson(statusFile);
    if (
      status
      && status.pid !== parentPid
      && status.agentVersion === expectedVersion
      && status.backend?.connected === true
      && !["STARTING", "ERROR", "STOPPING"].includes(status.state)
    ) {
      return true;
    }
    await sleep(1_000);
  }
  return false;
}

function startAgent(appDir, logFile) {
  fs.mkdirSync(path.dirname(logFile), { recursive: true });
  const output = fs.openSync(logFile, "a");
  const child = spawn(process.execPath, [path.join(appDir, "agent.js")], {
    cwd: appDir,
    env: process.env,
    detached: true,
    stdio: ["ignore", output, output],
    windowsHide: true,
  });
  child.unref();
  return child.pid;
}

function copyTree(source, destination) {
  fs.mkdirSync(destination, { recursive: true });
  for (const entry of fs.readdirSync(source, { withFileTypes: true })) {
    if ([".env", "logs", "runtime-status.json", "update-staging", "update-backups"].includes(entry.name)) continue;
    const from = path.join(source, entry.name);
    const to = path.join(destination, entry.name);
    if (entry.isDirectory()) copyTree(from, to);
    else if (entry.isFile()) fs.copyFileSync(from, to);
  }
}

function macLaunchDomain() {
  return `gui/${typeof process.getuid === "function" ? process.getuid() : os.userInfo().uid}`;
}

function stopMacLaunchAgent() {
  spawnSync("launchctl", ["bootout", `${macLaunchDomain()}/com.jarvis.agent`], { stdio: "ignore" });
}

function restartMacLaunchAgent() {
  const plist = path.join(os.homedir(), "Library", "LaunchAgents", "com.jarvis.agent.plist");
  spawnSync("launchctl", ["bootstrap", macLaunchDomain(), plist], { stdio: "ignore" });
  spawnSync("launchctl", ["kickstart", "-k", `${macLaunchDomain()}/com.jarvis.agent`], { stdio: "ignore" });
}

function writeResult(logFile, result) {
  const resultPath = path.join(path.dirname(logFile), "last-update-result.json");
  fs.writeFileSync(resultPath, `${JSON.stringify(result, null, 2)}\n`, { encoding: "utf8", mode: 0o600 });
}

if (require.main === module) {
  main().catch((error) => {
    console.error(`[jarvis-restart] ${error.message}`);
    process.exitCode = 1;
  });
}

module.exports = { copyTree, readJson, readPositiveInteger, waitForHealthyVersion };
