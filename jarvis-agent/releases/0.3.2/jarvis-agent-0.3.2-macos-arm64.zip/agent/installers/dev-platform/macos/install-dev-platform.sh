#!/usr/bin/env bash
set -euo pipefail

YES="false"
DRY_RUN="false"
WITH_ANDROID="false"
SKIP_NPM_GLOBALS="false"

usage() {
  cat <<USAGE
Jarvis agentic development platform installer for macOS

Usage:
  ./install-dev-platform.sh [options]

Options:
  --yes              Non-interactive installs where possible.
  --dry-run          Print commands without executing them.
  --with-android     Install Android Studio via Homebrew cask.
  --skip-npm-globals Skip Codex/Claude/OpenCode npm global installs.
  -h, --help         Show help.

Installs/checks:
  - Homebrew (if missing; prompts unless --yes)
  - node, git, gh, OpenJDK 21 (Gradle/Android compatible runtime)
  - npm globals: @openai/codex, @anthropic-ai/claude-code, opencode-ai
  - optional Android Studio (--with-android)
USAGE
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --yes|-y) YES="true"; shift ;;
    --dry-run) DRY_RUN="true"; shift ;;
    --with-android) WITH_ANDROID="true"; shift ;;
    --skip-npm-globals) SKIP_NPM_GLOBALS="true"; shift ;;
    -h|--help) usage; exit 0 ;;
    *) echo "Unknown argument: $1" >&2; usage >&2; exit 2 ;;
  esac
done

if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "ERROR: this installer is for macOS only." >&2
  exit 1
fi

run() {
  echo "+ $*"
  if [[ "${DRY_RUN}" != "true" ]]; then
    "$@"
  fi
}

run_shell() {
  echo "+ $*"
  if [[ "${DRY_RUN}" != "true" ]]; then
    /bin/bash -lc "$*"
  fi
}

confirm() {
  local prompt="$1"
  if [[ "${YES}" == "true" ]]; then return 0; fi
  read -r -p "${prompt} [y/N]: " reply
  case "${reply}" in y|Y|yes|YES) return 0 ;; *) return 1 ;; esac
}

ensure_brew() {
  if command -v brew >/dev/null 2>&1; then
    echo "[ok] Homebrew: $(command -v brew)"
    return
  fi
  if ! confirm "Homebrew is missing. Install it now"; then
    echo "ERROR: Homebrew is required for this installer. Install it from https://brew.sh/ or rerun with --yes." >&2
    exit 1
  fi
  run_shell '/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"'
  if [[ -x "/opt/homebrew/bin/brew" ]]; then
    eval "$(/opt/homebrew/bin/brew shellenv)"
  elif [[ -x "/usr/local/bin/brew" ]]; then
    eval "$(/usr/local/bin/brew shellenv)"
  fi
}

brew_install_if_missing() {
  local command_name="$1"
  local formula="$2"
  if command -v "${command_name}" >/dev/null 2>&1; then
    echo "[ok] ${command_name}: $(command -v "${command_name}")"
    return
  fi
  run brew install "${formula}"
}

npm_install_global_if_missing() {
  local command_name="$1"
  local package_name="$2"
  if command -v "${command_name}" >/dev/null 2>&1; then
    echo "[ok] ${command_name}: $(command -v "${command_name}")"
    return
  fi
  run npm install -g "${package_name}"
}

print_versions() {
  echo
  echo "== Version check =="
  for cmd in node npm git gh codex claude opencode; do
    if command -v "${cmd}" >/dev/null 2>&1; then
      echo "--- ${cmd} ---"
      "${cmd}" --version 2>&1 | head -n 3 || true
    else
      echo "[missing] ${cmd}"
    fi
  done
  if [[ -n "${ANDROID_HOME:-}" ]]; then echo "ANDROID_HOME=${ANDROID_HOME}"; fi
  if [[ -n "${ANDROID_SDK_ROOT:-}" ]]; then echo "ANDROID_SDK_ROOT=${ANDROID_SDK_ROOT}"; fi
}

ensure_brew
run brew update
brew_install_if_missing node node
brew_install_if_missing git git
brew_install_if_missing gh gh
if [[ -d "/Applications/Android Studio.app/Contents/jbr/Contents/Home" ]]; then
  echo "[ok] Android Studio JBR: /Applications/Android Studio.app/Contents/jbr/Contents/Home"
elif [[ -d "/opt/homebrew/opt/openjdk@21/libexec/openjdk.jdk/Contents/Home" || -d "/usr/local/opt/openjdk@21/libexec/openjdk.jdk/Contents/Home" ]]; then
  echo "[ok] OpenJDK 21 already installed"
else
  run brew install openjdk@21
fi

NODE_MAJOR="$(node -p 'process.versions.node.split(".")[0]' 2>/dev/null || echo 0)"
if [[ "${NODE_MAJOR}" -lt 18 ]]; then
  echo "ERROR: Node.js 18+ is required. Current: $(node -v 2>/dev/null || echo missing)" >&2
  exit 1
fi

if [[ "${SKIP_NPM_GLOBALS}" != "true" ]]; then
  npm_install_global_if_missing codex @openai/codex
  npm_install_global_if_missing claude @anthropic-ai/claude-code
  npm_install_global_if_missing opencode opencode-ai
fi

if [[ "${WITH_ANDROID}" == "true" ]]; then
  if brew list --cask android-studio >/dev/null 2>&1; then
    echo "[ok] Android Studio cask installed"
  else
    run brew install --cask android-studio
  fi
  cat <<'ANDROID_NOTE'

Android Studio installed/requested. Open Android Studio once and install:
  - Android SDK Platform Tools
  - Android SDK Build Tools
  - a project-compatible Android platform
Then set ANDROID_HOME or ANDROID_SDK_ROOT if needed.
ANDROID_NOTE
fi

print_versions
cat <<'NEXT'

Next steps:
  1. Login/configure GitHub CLI: gh auth login
  2. Login/configure Codex CLI if needed: codex
  3. Login/configure Claude Code if needed: claude
  4. Start local Ollama/LM Studio if using local providers.
  5. Install Jarvis Agent with agent/installers/macos/install-agent.sh.
NEXT
