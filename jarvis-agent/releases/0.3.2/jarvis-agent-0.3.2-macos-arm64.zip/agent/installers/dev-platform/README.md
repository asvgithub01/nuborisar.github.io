# Jarvis Agentic Dev Platform installers

These scripts prepare a workstation to run Jarvis Agent tasks.

## macOS

```bash
cd agent/installers/dev-platform/macos
chmod +x install-dev-platform.sh
./install-dev-platform.sh --yes
```

Optional Android Studio install:

```bash
./install-dev-platform.sh --yes --with-android
```

Dry run:

```bash
./install-dev-platform.sh --dry-run --with-android
```

## Windows PowerShell

Open PowerShell as a user with permission to install packages, then:

```powershell
cd agent\installers\dev-platform\windows
Set-ExecutionPolicy -Scope Process Bypass -Force
.\install-dev-platform.ps1 -Yes
```

Optional Android Studio install:

```powershell
.\install-dev-platform.ps1 -Yes -WithAndroid
```

Dry run:

```powershell
.\install-dev-platform.ps1 -DryRun -WithAndroid
```

## What gets installed/checked

- Node.js LTS / Node 18+
- Git
- GitHub CLI (`gh`)
- npm global CLIs:
  - `@openai/codex` -> `codex`
  - `@anthropic-ai/claude-code` -> `claude`
  - `opencode-ai` -> `opencode`
- Optional Android Studio for Android SDK setup.

The scripts do not log into Codex, Claude, GitHub, Ollama, LM Studio, or Jarvis. Users still need to configure credentials/tokens.
