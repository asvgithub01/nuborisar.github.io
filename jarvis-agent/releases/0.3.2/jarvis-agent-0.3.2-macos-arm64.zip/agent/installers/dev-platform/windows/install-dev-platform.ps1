[CmdletBinding()]
param(
  [switch]$Yes,
  [switch]$DryRun,
  [switch]$WithAndroid,
  [switch]$SkipNpmGlobals
)

$ErrorActionPreference = "Stop"

function Invoke-Step {
  param([string]$Command, [string[]]$Arguments = @())
  Write-Host "+ $Command $($Arguments -join ' ')"
  if (-not $DryRun) {
    & $Command @Arguments
    if ($LASTEXITCODE -ne 0) {
      throw "Command failed ($LASTEXITCODE): $Command $($Arguments -join ' ')"
    }
  }
}

function Test-CommandExists {
  param([string]$Name)
  return [bool](Get-Command $Name -ErrorAction SilentlyContinue)
}

function Confirm-Install {
  param([string]$Prompt)
  if ($Yes) { return $true }
  $reply = Read-Host "$Prompt [y/N]"
  return $reply -match '^(y|yes|s|si)$'
}

function Ensure-Winget {
  if (Test-CommandExists winget) {
    Write-Host "[ok] winget: $((Get-Command winget).Source)"
    return
  }
  throw "winget is required. Install App Installer from Microsoft Store or install dependencies manually."
}

function Install-WingetPackageIfMissing {
  param(
    [string]$CommandName,
    [string]$PackageId,
    [string]$DisplayName
  )
  if (Test-CommandExists $CommandName) {
    Write-Host "[ok] ${CommandName}: $((Get-Command $CommandName).Source)"
    return
  }
  if (-not (Confirm-Install "$DisplayName is missing. Install $PackageId with winget")) {
    throw "$DisplayName is required or must be installed manually."
  }
  Invoke-Step winget @('install','--id', $PackageId, '-e', '--accept-package-agreements', '--accept-source-agreements')
}

function Install-NpmGlobalIfMissing {
  param([string]$CommandName, [string]$PackageName)
  if (Test-CommandExists $CommandName) {
    Write-Host "[ok] ${CommandName}: $((Get-Command $CommandName).Source)"
    return
  }
  Invoke-Step npm @('install','-g', $PackageName)
}

function Write-VersionCheck {
  Write-Host "`n== Version check =="
  foreach ($cmd in @('node','npm','git','gh','codex','claude','opencode')) {
    if (Test-CommandExists $cmd) {
      Write-Host "--- $cmd ---"
      try { & $cmd --version 2>&1 | Select-Object -First 3 | ForEach-Object { Write-Host $_ } } catch { Write-Host $_ }
    } else {
      Write-Host "[missing] $cmd"
    }
  }
  if ($env:ANDROID_HOME) { Write-Host "ANDROID_HOME=$env:ANDROID_HOME" }
  if ($env:ANDROID_SDK_ROOT) { Write-Host "ANDROID_SDK_ROOT=$env:ANDROID_SDK_ROOT" }
}

Ensure-Winget
Install-WingetPackageIfMissing -CommandName node -PackageId OpenJS.NodeJS.LTS -DisplayName 'Node.js LTS'
Install-WingetPackageIfMissing -CommandName git -PackageId Git.Git -DisplayName 'Git for Windows'
Install-WingetPackageIfMissing -CommandName gh -PackageId GitHub.cli -DisplayName 'GitHub CLI'

$nodeMajor = 0
if (Test-CommandExists node) {
  $nodeMajor = [int](& node -p "process.versions.node.split('.')[0]")
}
if ($nodeMajor -lt 18) {
  throw "Node.js 18+ is required. Current: $(& node -v 2>$null)"
}

if (-not $SkipNpmGlobals) {
  Install-NpmGlobalIfMissing -CommandName codex -PackageName '@openai/codex'
  Install-NpmGlobalIfMissing -CommandName claude -PackageName '@anthropic-ai/claude-code'
  Install-NpmGlobalIfMissing -CommandName opencode -PackageName 'opencode-ai'
}

if ($WithAndroid) {
  Install-WingetPackageIfMissing -CommandName studio64 -PackageId Google.AndroidStudio -DisplayName 'Android Studio'
  Write-Host "`nOpen Android Studio once and install SDK Platform Tools, Build Tools, and a project-compatible Android platform."
  Write-Host "Then set ANDROID_HOME or ANDROID_SDK_ROOT if needed."
}

Write-VersionCheck
Write-Host ""
Write-Host "Next steps:"
Write-Host "  1. Login/configure GitHub CLI: gh auth login"
Write-Host "  2. Login/configure Codex CLI if needed: codex"
Write-Host "  3. Login/configure Claude Code if needed: claude"
Write-Host "  4. Start local Ollama/LM Studio if using local providers."
Write-Host "  5. Install/run Jarvis Agent with agent\\start-agent.cmd or the macOS installer on Mac."

