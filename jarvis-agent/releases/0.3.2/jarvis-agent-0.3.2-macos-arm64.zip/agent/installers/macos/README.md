# Jarvis Agent macOS - segundo agente

Instalador headless para registrar un MacBook como worker adicional de Jarvis, sin sustituir al agente que ya corre en Windows.

## Instalacion recomendada (doble clic)

El ZIP generado incluye `Install Jarvis Agent.command` en la raiz. Al abrirlo desde Finder:

- instala Node/Git mediante Homebrew si faltan;
- ofrece instalar Codex, Claude y OpenCode;
- solicita URL del backend, token, nombre visible y raiz de repositorios;
- asigna el id unico `<hostname>-jarvis-agent-02`;
- escanea automaticamente raices de desarrollo acotadas y los repositorios directos de `$HOME`;
- aplica timeout por raiz y excluye caches, dependencias, builds, FVM y backups `.bak-*`;
- verifica que el backend reconoce el mismo id externo e interno antes de sincronizar;
- crea y arranca `~/Library/LaunchAgents/com.jarvis.agent.plist`.

Si Gatekeeper bloquea el primer arranque, usar **Control + clic > Abrir**.

## Instalacion manual

```bash
cd agent/installers/macos
chmod +x *.sh "Install Jarvis Agent.command"
./install-agent.sh \
  --backend-url http://IP-DEL-PC-WINDOWS:8080 \
  --token YOUR_AGENT_TOKEN \
  --agent-id "$(hostname -s)-jarvis-agent-02" \
  --display-name "Jarvis MacBook (agente 2)" \
  --workspace-root "$HOME/Projects"
```

La URL debe ser accesible desde el MacBook. `localhost` solo sirve si el backend tambien corre en el Mac; normalmente se usa la IP LAN o Tailscale del PC Windows.

## Archivos instalados

- Runtime y configuracion: `~/Library/Application Support/JarvisAgent/app`
- Escaner instalado: `~/Library/Application Support/JarvisAgent/bin/jarvis-agent-projects`
- Acceso desde Finder: `~/Applications/Jarvis Agent/Scan Jarvis Projects.command`
- Logs: `~/Library/Application Support/JarvisAgent/logs`
- Servicio de usuario: `~/Library/LaunchAgents/com.jarvis.agent.plist`
- Configuracion protegida: `app/.env` con permisos `0600`

## Diagnostico

```bash
./doctor-agent.sh
launchctl print "gui/$(id -u)/com.jarvis.agent"
tail -f "$HOME/Library/Application Support/JarvisAgent/logs/agent.log"
```

`doctor-agent.sh` comprueba dependencias, version, conectividad, LaunchAgent y consulta
`/agents/me/config` para verificar el registro real del id externo.

## Actualizar proyectos

Al instalar se revisan solo repositorios directos de `$HOME` (profundidad 2) y las
raices habituales `~/Projects`, `~/repos`, `~/src`, `~/code`, `~/workspace`,
`~/Documents/GitHub`, `~/Documents/Playground` y `~/Documents/Projects`. Cada raiz
tiene un timeout de 30 segundos. Cuando clones, muevas o borres repositorios, abre desde Finder:

```text
~/Applications/Jarvis Agent/Scan Jarvis Projects.command
```

La utilidad actualiza `JARVIS_WORKSPACE_PATHS`, reinicia el agente y provoca una
nueva sincronizacion visible en Ops y JarvisMobile. Tambien puede ejecutarse en terminal:

```bash
"$HOME/Library/Application Support/JarvisAgent/bin/jarvis-agent-projects"
"$HOME/Library/Application Support/JarvisAgent/bin/jarvis-agent-projects" --dry-run
"$HOME/Library/Application Support/JarvisAgent/bin/jarvis-agent-projects" --root "$HOME/otra-raiz" --timeout-seconds 30
```

## Desinstalacion

```bash
./uninstall-agent.sh --purge
```

## Limitaciones

El paquete actual es un ZIP ejecutable y versionado, no un `.pkg`/`.dmg` firmado y notarizado. Codex y GitHub requieren autenticacion interactiva (`codex` y `gh auth login`) en el MacBook.
