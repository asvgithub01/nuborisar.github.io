#!/usr/bin/env bash
set -euo pipefail

LABEL="com.jarvis.agent"
INSTALL_ROOT="${JARVIS_AGENT_INSTALL_ROOT:-$HOME/Library/Application Support/JarvisAgent}"
USER_APP_DIR="${HOME}/Applications/Jarvis Agent"
PLIST_FILE="${HOME}/Library/LaunchAgents/${LABEL}.plist"
LAUNCH_DOMAIN="gui/$(id -u)"
PURGE="false"

usage() {
  cat <<USAGE
Jarvis Agent macOS uninstaller

Usage:
  ./uninstall-agent.sh [--purge]

Options:
  --purge    Also remove app/config/logs from ~/Library/Application Support/JarvisAgent.
USAGE
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --purge) PURGE="true"; shift ;;
    -h|--help) usage; exit 0 ;;
    *) echo "Unknown argument: $1" >&2; usage >&2; exit 2 ;;
  esac
done

if [[ -f "${PLIST_FILE}" ]]; then
  launchctl bootout "${LAUNCH_DOMAIN}" "${PLIST_FILE}" >/dev/null 2>&1 || true
  launchctl unload "${PLIST_FILE}" >/dev/null 2>&1 || true
  rm -f "${PLIST_FILE}"
  echo "Removed LaunchAgent: ${PLIST_FILE}"
else
  echo "LaunchAgent not found: ${PLIST_FILE}"
fi

if [[ "${PURGE}" == "true" ]]; then
  rm -rf "${INSTALL_ROOT}"
  rm -f "${USER_APP_DIR}/Scan Jarvis Projects.command"
  rmdir "${USER_APP_DIR}" >/dev/null 2>&1 || true
  echo "Removed install root: ${INSTALL_ROOT}"
else
  echo "Keeping install root: ${INSTALL_ROOT}"
  echo "Run with --purge to remove app/config/logs."
fi
