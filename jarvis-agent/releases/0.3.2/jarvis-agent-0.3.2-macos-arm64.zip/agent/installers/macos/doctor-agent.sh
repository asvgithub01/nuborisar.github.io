#!/usr/bin/env bash
set -euo pipefail

LABEL="com.jarvis.agent"
INSTALL_ROOT="${JARVIS_AGENT_INSTALL_ROOT:-$HOME/Library/Application Support/JarvisAgent}"
CONFIG_FILE="${INSTALL_ROOT}/app/.env"
LOG_DIR="${INSTALL_ROOT}/logs"
PLIST_FILE="${HOME}/Library/LaunchAgents/${LABEL}.plist"
LAUNCH_DOMAIN="gui/$(id -u)"
SCANNER_BIN="${INSTALL_ROOT}/bin/jarvis-agent-projects"
SCANNER_LAUNCHER="${HOME}/Applications/Jarvis Agent/Scan Jarvis Projects.command"

status=0

check_cmd() {
  local name="$1"
  local required="${2:-false}"
  if command -v "$name" >/dev/null 2>&1; then
    echo "[ok] ${name}: $(command -v "$name")"
  elif [[ "$required" == "true" ]]; then
    echo "[missing] ${name} (required)"
    status=1
  else
    echo "[missing] ${name} (optional/runtime dependent)"
  fi
}

config_value() {
  local key="$1"
  [[ -f "$CONFIG_FILE" ]] || return 0
  sed -n "s/^${key}=//p" "$CONFIG_FILE" | head -n 1
}

echo "Jarvis Agent macOS doctor"
echo "Install root: ${INSTALL_ROOT}"
echo
check_cmd node true
check_cmd git true
check_cmd curl true
check_cmd codex false
check_cmd claude false
check_cmd opencode false
check_cmd gh false

echo
if [[ -f "$CONFIG_FILE" ]]; then
  echo "[ok] config: ${CONFIG_FILE}"
  backend_url="$(config_value JARVIS_BASE_URL)"
  agent_id="$(config_value JARVIS_AGENT_ID)"
  agent_version="$(config_value JARVIS_AGENT_RELEASE_VERSION)"
  display_name="$(config_value JARVIS_AGENT_DISPLAY_NAME)"
  workspace_roots="$(config_value JARVIS_WORKSPACE_ROOTS)"
  workspace_paths="$(config_value JARVIS_WORKSPACE_PATHS)"
  echo "     backend=${backend_url:-missing}"
  echo "     agentId=${agent_id:-missing}"
  echo "     agentVersion=${agent_version:-missing}"
  echo "     displayName=${display_name:-missing}"
  echo "     workspaces=${workspace_roots:-missing}"
  if [[ -n "$workspace_paths" ]]; then
    workspace_count="$(printf '%s' "$workspace_paths" | awk -F';' '{ print NF }')"
  else
    workspace_count=0
  fi
  echo "     detectedProjects=${workspace_count}"
  if [[ -n "$(config_value JARVIS_AGENT_TOKEN)" ]]; then
    echo "[ok] config has JARVIS_AGENT_TOKEN (value hidden)"
  else
    echo "[missing] JARVIS_AGENT_TOKEN in config"
    status=1
  fi

  if [[ -n "$backend_url" ]]; then
    if curl --fail --silent --show-error --connect-timeout 5 --max-time 10 \
        "${backend_url%/}/health" >/dev/null; then
      echo "[ok] backend reachable: ${backend_url}"
    else
      echo "[error] backend unreachable: ${backend_url}"
      status=1
    fi
  fi

  agent_token="$(config_value JARVIS_AGENT_TOKEN)"
  if [[ -n "$backend_url" && -n "$agent_id" && -n "$agent_token" ]]; then
    registration_response="$(mktemp -t jarvis-agent-registration.XXXXXX)"
    registration_code="$(curl --silent --show-error --connect-timeout 5 --max-time 10 \
      --output "$registration_response" --write-out '%{http_code}' \
      --header "Authorization: Bearer ${agent_token}" \
      --header "X-Agent-Id: ${agent_id}" \
      "${backend_url%/}/agents/me/config" || true)"
    if [[ "$registration_code" == "200" ]] && grep -Fq "\"agentId\":\"${agent_id}\"" "$registration_response"; then
      echo "[ok] backend registration verified for external agent id ${agent_id}"
    else
      echo "[error] backend does not recognize external agent id ${agent_id} (HTTP ${registration_code:-000})"
      status=1
    fi
    rm -f "$registration_response"
  fi
else
  echo "[missing] config: ${CONFIG_FILE}"
  status=1
fi

if [[ -x "$SCANNER_BIN" ]]; then
  echo "[ok] project scanner: ${SCANNER_BIN}"
else
  echo "[missing] project scanner: ${SCANNER_BIN}"
  status=1
fi
if [[ -x "$SCANNER_LAUNCHER" ]]; then
  echo "[ok] Finder scanner: ${SCANNER_LAUNCHER}"
else
  echo "[missing] Finder scanner: ${SCANNER_LAUNCHER}"
  status=1
fi

if [[ -f "$PLIST_FILE" ]]; then
  echo "[ok] LaunchAgent plist: ${PLIST_FILE}"
else
  echo "[missing] LaunchAgent plist: ${PLIST_FILE}"
  status=1
fi

if launchctl print "${LAUNCH_DOMAIN}/${LABEL}" >/dev/null 2>&1; then
  echo "[ok] LaunchAgent is loaded: ${LAUNCH_DOMAIN}/${LABEL}"
else
  echo "[error] LaunchAgent is not loaded: ${LAUNCH_DOMAIN}/${LABEL}"
  status=1
fi

if [[ -f "${LOG_DIR}/agent.log" ]]; then
  if grep -q '\[agent\] bootstrap verified' "${LOG_DIR}/agent.log"; then
    echo "[ok] agent bootstrap handshake verified in log"
  else
    echo "[wait] no successful bootstrap line yet; inspect ${LOG_DIR}/agent.log"
  fi
fi

if [[ -s "${LOG_DIR}/agent.err.log" ]]; then
  echo "[warn] agent stderr is not empty: ${LOG_DIR}/agent.err.log"
  tail -n 5 "${LOG_DIR}/agent.err.log" || true
fi

exit "$status"
