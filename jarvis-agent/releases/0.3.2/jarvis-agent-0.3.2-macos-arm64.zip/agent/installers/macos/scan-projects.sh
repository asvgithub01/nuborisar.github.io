#!/usr/bin/env bash
set -euo pipefail

LABEL="com.jarvis.agent"
INSTALL_ROOT="${JARVIS_AGENT_INSTALL_ROOT:-$HOME/Library/Application Support/JarvisAgent}"
CONFIG_FILE="${INSTALL_ROOT}/app/.env"
PLIST_FILE="${HOME}/Library/LaunchAgents/${LABEL}.plist"
LAUNCH_DOMAIN="gui/$(id -u)"
MAX_DEPTH=4
HOME_TOP_LEVEL_DEPTH=2
ROOT_TIMEOUT_SECONDS="${JARVIS_PROJECT_SCAN_TIMEOUT_SECONDS:-30}"
DRY_RUN="false"
RESTART_AGENT="true"
SCAN_ROOTS=()
EXPLICIT_ROOTS="false"

usage() {
  cat <<USAGE
Jarvis Agent macOS project scanner

Busca repositorios Git del Mac, actualiza JARVIS_WORKSPACE_PATHS y reinicia el agente.

Usage:
  ./scan-projects.sh [options]

Options:
  --root PATH        Root to scan. Can be repeated. Defaults: common dev folders
  --max-depth N      Maximum depth for explicit/common roots. Default: 4
  --timeout-seconds N  Maximum seconds per root. Default: 30
  --dry-run          Print detected projects without changing config.
  --no-restart       Update config without restarting the LaunchAgent.
  -h, --help         Show this help.
USAGE
}

require_value() {
  local option="$1"
  local value="${2:-}"
  if [[ -z "$value" ]]; then
    echo "ERROR: ${option} requires a value." >&2
    exit 2
  fi
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --root)
      require_value "$1" "${2:-}"
      SCAN_ROOTS+=("${2/#\~/$HOME}")
      EXPLICIT_ROOTS="true"
      shift 2
      ;;
    --max-depth)
      require_value "$1" "${2:-}"
      MAX_DEPTH="$2"
      shift 2
      ;;
    --timeout-seconds)
      require_value "$1" "${2:-}"
      ROOT_TIMEOUT_SECONDS="$2"
      shift 2
      ;;
    --dry-run)
      DRY_RUN="true"
      shift
      ;;
    --no-restart)
      RESTART_AGENT="false"
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "Unknown argument: $1" >&2
      usage >&2
      exit 2
      ;;
  esac
done

if [[ ! "$MAX_DEPTH" =~ ^[1-9][0-9]*$ ]]; then
  echo "ERROR: --max-depth must be a positive integer." >&2
  exit 2
fi
if [[ ! "$ROOT_TIMEOUT_SECONDS" =~ ^[1-9][0-9]*$ ]]; then
  echo "ERROR: --timeout-seconds must be a positive integer." >&2
  exit 2
fi

if [[ ${#SCAN_ROOTS[@]} -eq 0 ]]; then
  # Scan only top-level repositories under HOME, then inspect conventional
  # development directories deeply. Never traverse the entire user profile.
  SCAN_ROOTS=("$HOME")
  configured_roots=""
  if [[ -f "$CONFIG_FILE" ]]; then
    configured_roots="$(sed -n 's/^JARVIS_PROJECT_SCAN_ROOTS=//p' "$CONFIG_FILE" | head -n 1)"
    configured_timeout="$(sed -n 's/^JARVIS_PROJECT_SCAN_TIMEOUT_SECONDS=//p' "$CONFIG_FILE" | head -n 1)"
    [[ -n "$configured_timeout" ]] && ROOT_TIMEOUT_SECONDS="$configured_timeout"
  fi
  if [[ -n "$configured_roots" ]]; then
    while IFS= read -r configured_root; do
      [[ -n "$configured_root" ]] && SCAN_ROOTS+=("${configured_root/#\~/$HOME}")
    done < <(printf '%s\n' "$configured_roots" | tr ';' '\n')
  else
    SCAN_ROOTS+=(
      "$HOME/Projects"
      "$HOME/repos"
      "$HOME/src"
      "$HOME/code"
      "$HOME/workspace"
      "$HOME/Documents/GitHub"
      "$HOME/Documents/Playground"
      "$HOME/Documents/Projects"
    )
  fi
fi

if [[ ! "$ROOT_TIMEOUT_SECONDS" =~ ^[1-9][0-9]*$ ]]; then
  echo "ERROR: configured scan timeout must be a positive integer." >&2
  exit 2
fi

if [[ "$DRY_RUN" != "true" && ! -f "$CONFIG_FILE" ]]; then
  echo "ERROR: Jarvis Agent config not found: ${CONFIG_FILE}" >&2
  echo "Install the agent first or use --dry-run." >&2
  exit 1
fi

TEMP_FOUND="$(mktemp -t jarvis-projects-found.XXXXXX)"
TEMP_SORTED="$(mktemp -t jarvis-projects-sorted.XXXXXX)"
TEMP_CONFIG=""
TEMP_FIND_FILES=()
cleanup() {
  rm -f "$TEMP_FOUND" "$TEMP_SORTED"
  [[ -z "$TEMP_CONFIG" ]] || rm -f "$TEMP_CONFIG"
  for temp_find in "${TEMP_FIND_FILES[@]}"; do
    rm -f "$temp_find"
  done
}
trap cleanup EXIT

should_ignore_repo() {
  local repo="$1"
  case "$repo" in
    "$HOME/.codex"|"$HOME/.codex/"*|\
    "$HOME/.cache"|"$HOME/.cache/"*|\
    "$HOME/.Trash"|"$HOME/.Trash/"*|\
    "$HOME/Library"|"$HOME/Library/"*|\
    "$HOME/fvm"|"$HOME/fvm/"*|\
    *"/node_modules/"*|*"/.tmp/"*|*"/.cache/"*|*"/.gradle/"*|\
    *".bak-"*|*"/cache.git")
      return 0
      ;;
  esac
  return 1
}

echo "Buscando repositorios Git del Mac..."
for scan_root in "${SCAN_ROOTS[@]}"; do
  if [[ ! -d "$scan_root" ]]; then
    echo "[warn] no existe: ${scan_root}" >&2
    continue
  fi
  root_depth="$MAX_DEPTH"
  if [[ "$EXPLICIT_ROOTS" != "true" && "$scan_root" == "$HOME" ]]; then
    root_depth="$HOME_TOP_LEVEL_DEPTH"
  fi
  echo "  root=${scan_root} (profundidad ${root_depth}, timeout ${ROOT_TIMEOUT_SECONDS}s)"

  find_output="$(mktemp -t jarvis-projects-find.XXXXXX)"
  TEMP_FIND_FILES+=("$find_output")
  find "$scan_root" -maxdepth "$root_depth" \
    \( -type d -name .git -print -prune \) -o \
    \( -type d \
       \( -name '.*' -o -name Library -o -name node_modules -o -name .gradle \
          -o -name Pods -o -name DerivedData -o -name build \) -prune \) \
    > "$find_output" 2>/dev/null &
  find_pid=$!
  elapsed=0
  timed_out="false"
  while kill -0 "$find_pid" >/dev/null 2>&1; do
    if [[ "$elapsed" -ge "$ROOT_TIMEOUT_SECONDS" ]]; then
      timed_out="true"
      kill "$find_pid" >/dev/null 2>&1 || true
      sleep 1
      kill -9 "$find_pid" >/dev/null 2>&1 || true
      break
    fi
    sleep 1
    elapsed=$((elapsed + 1))
  done
  wait "$find_pid" >/dev/null 2>&1 || true
  if [[ "$timed_out" == "true" ]]; then
    echo "  [warn] timeout en ${scan_root}; se conservan los repositorios encontrados hasta ese momento." >&2
  fi

  # Prune common macOS/tool caches early. The case filter below protects custom roots too.
  while IFS= read -r git_dir; do
    repo="${git_dir%/.git}"
    [[ -n "$repo" ]] || continue
    should_ignore_repo "$repo" && continue
    if [[ "$repo" == *';'* || "$repo" == *','* || "$repo" == *$'\n'* || "$repo" == *$'\r'* ]]; then
      echo "[warn] ruta omitida por contener un separador no soportado: ${repo}" >&2
      continue
    fi
    printf '%s\n' "$repo" >> "$TEMP_FOUND"
  done < "$find_output"
done

LC_ALL=C sort -u "$TEMP_FOUND" > "$TEMP_SORTED"
PROJECT_COUNT="$(awk 'NF { count++ } END { print count + 0 }' "$TEMP_SORTED")"

echo
echo "Proyectos encontrados: ${PROJECT_COUNT}"
if [[ "$PROJECT_COUNT" -gt 0 ]]; then
  while IFS= read -r repo; do
    [[ -n "$repo" ]] && echo "  - ${repo}"
  done < "$TEMP_SORTED"
fi

if [[ "$DRY_RUN" == "true" ]]; then
  echo
  echo "Modo dry-run: no se ha cambiado la configuracion."
  exit 0
fi

WORKSPACE_PATHS=""
while IFS= read -r repo; do
  [[ -n "$repo" ]] || continue
  if [[ -z "$WORKSPACE_PATHS" ]]; then
    WORKSPACE_PATHS="$repo"
  else
    WORKSPACE_PATHS="${WORKSPACE_PATHS};${repo}"
  fi
done < "$TEMP_SORTED"

TEMP_CONFIG="$(mktemp -t jarvis-agent-env.XXXXXX)"
found_key="false"
while IFS= read -r line || [[ -n "$line" ]]; do
  if [[ "$line" == JARVIS_WORKSPACE_PATHS=* ]]; then
    printf 'JARVIS_WORKSPACE_PATHS=%s\n' "$WORKSPACE_PATHS" >> "$TEMP_CONFIG"
    found_key="true"
  else
    printf '%s\n' "$line" >> "$TEMP_CONFIG"
  fi
done < "$CONFIG_FILE"
if [[ "$found_key" != "true" ]]; then
  printf 'JARVIS_WORKSPACE_PATHS=%s\n' "$WORKSPACE_PATHS" >> "$TEMP_CONFIG"
fi
cat "$TEMP_CONFIG" > "$CONFIG_FILE"
chmod 600 "$CONFIG_FILE"

echo
echo "Configuracion actualizada: ${CONFIG_FILE}"
echo "JARVIS_WORKSPACE_PATHS contiene ${PROJECT_COUNT} proyectos."

if [[ "$RESTART_AGENT" == "true" ]]; then
  if launchctl print "${LAUNCH_DOMAIN}/${LABEL}" >/dev/null 2>&1; then
    launchctl kickstart -k "${LAUNCH_DOMAIN}/${LABEL}"
    echo "Agente reiniciado; sincronizara los proyectos con Ops/JarvisMobile."
  elif [[ -f "$PLIST_FILE" ]]; then
    if launchctl bootstrap "$LAUNCH_DOMAIN" "$PLIST_FILE" 2>/dev/null; then
      launchctl enable "${LAUNCH_DOMAIN}/${LABEL}" >/dev/null 2>&1 || true
      launchctl kickstart -k "${LAUNCH_DOMAIN}/${LABEL}"
    else
      launchctl load -w "$PLIST_FILE"
    fi
    echo "Agente arrancado; sincronizara los proyectos con Ops/JarvisMobile."
  else
    echo "[warn] LaunchAgent no encontrado; la configuracion queda guardada." >&2
  fi
fi
