﻿---
name: liquid-glass-android-glassmorphism
description: Use this skill when implementing Glassmorphism / frosted-glass UI in Android Jetpack Compose using Mortd3kay/liquid-glass-android, especially for cards, overlays, buttons, and map HUD panels. Applies to new or existing Android projects, including cases where the library must be vendored locally.
metadata:
  short-description: Liquid-glass Android glassmorphism for Compose
---

# Liquid Glass Android Glassmorphism

Use this when a project needs real/fallback glassmorphism in Jetpack Compose via `Mortd3kay/liquid-glass-android`.

## Quick workflow

1. **Check dependency availability first**
   - Try Maven Central only if the project already uses a published coordinate.
   - If `com.mrtdk:glass:0.1.0` or similar is unavailable, vendor the upstream `glass` module locally from:
     `https://github.com/Mortd3kay/liquid-glass-android`

2. **Prefer local module integration when Maven is unavailable**
   - Create a module such as `:liquid-glass`.
   - Copy upstream `glass/src/androidMain/kotlin/com/mrtdk/glass/GlassBox.kt`.
   - Copy upstream `LICENSE`.
   - Convert the module to a normal Android library if the host project is not KMP.

3. **Wire Gradle**

   `settings.gradle.kts`:
   ```kotlin
   include(":liquid-glass")
   ```

   app `build.gradle.kts`:
   ```kotlin
   implementation(project(":liquid-glass"))
   ```

   local `liquid-glass/build.gradle.kts` baseline:
   ```kotlin
   plugins {
       alias(libs.plugins.android.library)
       alias(libs.plugins.kotlin.android)
       alias(libs.plugins.kotlin.compose)
   }

   android {
       namespace = "com.mrtdk.glass"
       compileSdk = 35
       defaultConfig { minSdk = 21 }
       compileOptions {
           sourceCompatibility = JavaVersion.VERSION_17
           targetCompatibility = JavaVersion.VERSION_17
       }
       kotlinOptions { jvmTarget = "17" }
       buildFeatures { compose = true }
   }

   dependencies {
       implementation(platform(libs.androidx.compose.bom))
       implementation(libs.androidx.compose.ui)
       implementation("androidx.compose.ui:ui-graphics")
       implementation("androidx.compose.runtime:runtime")
       implementation("androidx.compose.foundation:foundation")
   }
   ```

## Compose pattern

Wrap the visual background in `GlassContainer.content` and draw the glass UI in `GlassContainer.glassContent`:

```kotlin
GlassContainer(
    modifier = Modifier.fillMaxSize(),
    content = {
        // Map/image/list/background content to be distorted/blurred behind glass.
        ScreenBackground()
    },
    glassContent = glassContent@{
        this@glassContent.GlassPanel(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(16.dp)
        ) {
            PanelContent()
        }
    }
)
```

Reusable panel:

```kotlin
@Composable
private fun GlassBoxScope.GlassPanel(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    val shape = RoundedCornerShape(22.dp)
    GlassBox(
        modifier = modifier.clip(shape),
        blur = 0.24f,
        scale = 0.04f,
        centerDistortion = 0.01f,
        elevation = 0.dp,
        tint = MaterialTheme.colorScheme.surface.copy(alpha = 0.58f),
        darkness = 0.02f,
        warpEdges = 0.04f,
        shape = shape
    ) {
        content()
    }
}
```

## Important gotchas

- **Android 13+**: library uses AGSL shader for real liquid-glass effect.
- **Android 12 or lower**: library falls back to simulated glass with gradients/transparency, not real backdrop blur.
- Do **not** stack `Card`, heavy `.shadow`, extra gradient backgrounds, or manual white borders on top of `GlassBox` unless intentionally styling; it often makes cards look doubled.
- For map-only/fullscreen modes, avoid leaving `GlassBox` panels mounted but transparent; remove them from composition.

## Patch stale/ghost glass elements

If hidden panels leave ghost rectangles in the shader, patch the vendored `GlassScopeImpl` so each glass element unregisters on dispose:

```kotlin
import androidx.compose.ui.composed

fun removeElement(elementId: String) {
    activeElements.remove(elementId)
    if (elements.removeAll { it.id == elementId }) updateCounter++
}

override fun Modifier.glassBackground(...): Modifier = composed {
    val elementId = remember(id) { "glass_$id" }
    DisposableEffect(elementId) {
        onDispose { removeElement(elementId) }
    }
    this
        .background(color = Color.Transparent, shape = shape)
        .onGloballyPositioned { coordinates ->
            markElementAsActive(elementId)
            // existing element update logic
        }
}
```

Also remove debug `println` inside shader setup if vendoring upstream.

## Validation

Run at least:

```powershell
.\gradlew.bat :app:compileDebugKotlin
.\gradlew.bat :app:assembleDebug
```

Manual QA:
- Normal panels do not look doubled.
- Panels disappear completely when hidden/map-only mode is active.
- Android 13+ shows actual liquid blur/distortion.
- Android 12 or lower remains readable with fallback styling.
