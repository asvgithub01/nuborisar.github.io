# Skill: Agent SafeExecution

## Purpose
Run autonomous task execution safely while preserving user repos and providing complete observability.

## When to Use
- Any change to task claim/heartbeat logic.
- Any change to Codex invocation or timeout policy.
- Any change to test/build or artifact upload flow.
- Any change to git commit/push strategy.

## Input Contract
- Target behavior change in execution loop.
- Project type assumptions (Android/web/mixed).
- Failure handling expectations.
- Acceptance criteria.

## Procedure
1. Confirm preconditions (token, lease, repo path).
2. Execute bounded Codex step with full context.
3. Run checks/build as applicable.
4. Capture logs and publish task-visible messages.
5. Apply safe git workflow and summarize diff.
6. Enforce status transition consistency.
7. Update docs.

## Output Contract
- Execution summary.
- Artifact references (APK/logs).
- Status transitions observed.
- Errors and recovery actions (if any).
- Updated documentation references.

## Mandatory Rule
- **MAXIMA:** keep previous docs updated after every execution workflow change.
