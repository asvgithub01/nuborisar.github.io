#!/usr/bin/env node
"use strict";

const fs = require("node:fs");
const path = require("node:path");
const packageMetadata = require("./package.json");

function parseArgs(argv) {
  const result = { once: false, intervalMs: 750, statusPath: "", logPath: "" };
  for (let index = 0; index < argv.length; index += 1) {
    const arg = argv[index];
    if (arg === "--once") result.once = true;
    else if (arg === "--status") result.statusPath = String(argv[++index] || "");
    else if (arg === "--log") result.logPath = String(argv[++index] || "");
    else if (arg === "--interval-ms") result.intervalMs = Math.max(200, Number.parseInt(argv[++index] || "750", 10) || 750);
    else if (arg === "--help" || arg === "-h") result.help = true;
    else throw new Error(`Unknown argument: ${arg}`);
  }
  return result;
}

function formatStatus(status) {
  const timestamp = status.updatedAt ? new Date(status.updatedAt).toLocaleString() : "-";
  const agentVersion = status.agentVersion || packageMetadata.version || "-";
  const lines = [
    "============================================================",
    ` JARVIS AGENT ${agentVersion} - CONSOLA`,
    "============================================================",
    `Estado:       ${status.state || "DESCONOCIDO"}`,
    `Accion:       ${status.action || status.message || "-"}`,
    `Agente:       ${status.agentId || "-"} (v${agentVersion})`,
    `Tarea:        ${status.taskId || "-"}`,
    `Comando:      ${status.commandId || "-"}`,
    `Codex:        ${status.codex?.currentVersion || "-"}${status.codex?.latestVersion ? ` -> ${status.codex.latestVersion}` : ""}`,
    `Codex ruta:   ${status.codex?.executablePath || "-"}`,
    `Backend:      ${status.backend?.connected === true ? "conectado" : status.backend?.connected === false ? "sin conexion" : "-"}`,
    `Actualizado:  ${timestamp}`,
    "------------------------------------------------------------",
    " Cerrar esta consola no detiene el agente.",
    " Logs recientes:",
  ];
  return lines.join("\n");
}

function readStatus(statusPath, { now = Date.now(), offlineMs = 15_000 } = {}) {
  try {
    const status = JSON.parse(fs.readFileSync(statusPath, "utf8"));
    const updatedAt = Date.parse(status.updatedAt || "");
    if (Number.isFinite(updatedAt) && now - updatedAt > offlineMs) {
      return {
        ...status,
        state: "OFFLINE",
        action: `Sin cambios de estado desde ${new Date(updatedAt).toLocaleString()}`,
      };
    }
    return status;
  } catch (error) {
    return {
      state: "SIN_DATOS",
      action: fs.existsSync(statusPath)
        ? `No se pudo leer el estado: ${error.message}`
        : "El agente aun no ha publicado su estado.",
    };
  }
}

function readLogTail(logPath, maxBytes = 16_384, maxLines = 18) {
  try {
    const stat = fs.statSync(logPath);
    const start = Math.max(0, stat.size - maxBytes);
    const length = stat.size - start;
    const buffer = Buffer.alloc(length);
    const fd = fs.openSync(logPath, "r");
    try {
      fs.readSync(fd, buffer, 0, length, start);
    } finally {
      fs.closeSync(fd);
    }
    return buffer.toString("utf8").split(/\r?\n/).filter(Boolean).slice(-maxLines).join("\n");
  } catch (_error) {
    return "(sin log disponible)";
  }
}

function render({ statusPath, logPath, clear = true }) {
  const status = readStatus(statusPath);
  if (clear && process.stdout.isTTY) process.stdout.write("\x1Bc");
  process.stdout.write(`${formatStatus(status)}\n${readLogTail(logPath)}\n`);
}

async function main(argv = process.argv.slice(2)) {
  const args = parseArgs(argv);
  if (args.help) {
    console.log("Uso: node agent-console.js [--once] [--status RUTA] [--log RUTA] [--interval-ms 750]");
    return;
  }
  const logDir = path.resolve(String(process.env.JARVIS_AGENT_LOG_DIR || path.join(__dirname, "logs")).trim());
  const statusPath = path.resolve(args.statusPath || process.env.JARVIS_AGENT_STATUS_FILE || path.join(logDir, "runtime-status.json"));
  const logPath = path.resolve(args.logPath || process.env.JARVIS_AGENT_MAIN_LOG || path.join(logDir, "agent.log"));
  render({ statusPath, logPath, clear: !args.once });
  if (args.once) return;
  setInterval(() => render({ statusPath, logPath }), args.intervalMs);
}

if (require.main === module) {
  main().catch((error) => {
    console.error(`[jarvis-console] ${error.message}`);
    process.exitCode = 1;
  });
}

module.exports = { formatStatus, parseArgs, readLogTail, readStatus, render };
