const assert = require("assert/strict");

const { OllamaProvider } = require("../providers/ollamaProvider");
const { resolveOllamaContextPolicy } = require("../config/providers");

function jsonResponse(status, payload) {
  return {
    ok: status >= 200 && status < 300,
    status,
    async text() {
      return JSON.stringify(payload);
    },
    async json() {
      return payload;
    },
  };
}

function textResponse(status, text) {
  return {
    ok: status >= 200 && status < 300,
    status,
    async text() {
      return String(text || "");
    },
    async json() {
      throw new Error("invalid json response");
    },
  };
}

async function withMockedFetch(mockImpl, fn) {
  const previous = global.fetch;
  global.fetch = mockImpl;
  try {
    return await fn();
  } finally {
    global.fetch = previous;
  }
}

function createProvider(policy) {
  return new OllamaProvider({
    baseUrl: "http://localhost:11434/api",
    model: "qwen2.5-coder:32b",
    timeoutMs: 5000,
    contextPolicy: policy,
  });
}

async function caseA(policy) {
  const ctxCalls = [];
  const provider = createProvider(policy);

  const result = await withMockedFetch(async (url, options) => {
    const body = JSON.parse(options.body || "{}");
    assert.ok(String(url).endsWith("/chat"));
    ctxCalls.push(body?.options?.num_ctx);
    return jsonResponse(200, {
      model: "qwen2.5-coder:32b",
      message: { content: "ok-a" },
      done: true,
    });
  }, async () => provider.runTask({ prompt: "case-a" }));

  assert.equal(ctxCalls[0], 16384);
  assert.equal(result.numCtxInitial, 16384);
  assert.equal(result.numCtxFinal, 16384);
  return `[case A] ctx=${ctxCalls.join("->")} initial=${result.numCtxInitial} final=${result.numCtxFinal}`;
}

async function caseB(policy) {
  const ctxCalls = [];
  const provider = createProvider(policy);

  const result = await withMockedFetch(async (_url, options) => {
    const body = JSON.parse(options.body || "{}");
    ctxCalls.push(body?.options?.num_ctx);
    return jsonResponse(200, {
      model: "qwen2.5-coder:32b",
      message: { content: "ok-b" },
      done: true,
    });
  }, async () => provider.runTask({
    prompt: "case-b",
    contextOverride: 32768,
  }));

  assert.equal(ctxCalls[0], 32768);
  assert.equal(result.numCtxInitial, 32768);
  assert.equal(result.numCtxFinal, 32768);
  return `[case B] ctx=${ctxCalls.join("->")} initial=${result.numCtxInitial} final=${result.numCtxFinal}`;
}

async function caseC(policy) {
  const ctxCalls = [];
  const provider = createProvider(policy);

  const result = await withMockedFetch(async (_url, options) => {
    const body = JSON.parse(options.body || "{}");
    ctxCalls.push(body?.options?.num_ctx);
    return jsonResponse(200, {
      model: "qwen2.5-coder:32b",
      message: { content: "ok-c" },
      done: true,
    });
  }, async () => provider.runTask({
    prompt: "case-c",
    contextOverride: 65536,
  }));

  assert.equal(ctxCalls[0], 32768);
  assert.equal(result.numCtxInitial, 32768);
  assert.equal(result.numCtxFinal, 32768);
  return `[case C] ctx=${ctxCalls.join("->")} initial=${result.numCtxInitial} final=${result.numCtxFinal} (clamp)`;
}

async function caseD(policy) {
  const responses = [
    textResponse(500, "context window exceeded"),
    textResponse(504, "timeout while processing request"),
    jsonResponse(200, {
      model: "qwen2.5-coder:32b",
      message: { content: "ok-d" },
      done: true,
    }),
  ];
  const ctxCalls = [];
  const attempts = [];
  const provider = createProvider(policy);

  const result = await withMockedFetch(async (_url, options) => {
    const body = JSON.parse(options.body || "{}");
    ctxCalls.push(body?.options?.num_ctx);
    const response = responses.shift();
    if (!response) {
      throw new Error("unexpected extra request");
    }
    return response;
  }, async () => provider.runTask({
    prompt: "case-d",
    contextOverride: 32768,
    onAttempt: (attempt) => attempts.push(attempt),
  }));

  assert.deepEqual(ctxCalls, [32768, 16384, 8192]);
  assert.equal(result.numCtxInitial, 32768);
  assert.equal(result.numCtxFinal, 8192);

  const reasons = attempts.filter((entry) => !entry.ok).map((entry) => entry.reason);
  assert.deepEqual(reasons, ["context", "timeout"]);

  return `[case D] ctx=${ctxCalls.join("->")} initial=${result.numCtxInitial} final=${result.numCtxFinal} reasons=${reasons.join("->")}`;
}

async function main() {
  const policyInfo = resolveOllamaContextPolicy(process.env);
  const policy = policyInfo.policy;

  assert.equal(policy.numCtxDefault, 16384);
  assert.equal(policy.numCtxMin, 8192);
  assert.equal(policy.numCtxMax, 32768);
  assert.deepEqual(policy.fallbackPolicy, [32768, 16384, 8192]);

  const evidence = [];
  evidence.push(await caseA(policy));
  evidence.push(await caseB(policy));
  evidence.push(await caseC(policy));
  evidence.push(await caseD(policy));

  console.log("[ollama-context-policy] policy", JSON.stringify(policy));
  for (const line of evidence) {
    console.log(`[ollama-context-policy] ${line}`);
  }
  console.log("[ollama-context-policy] OK");
}

main().catch((error) => {
  console.error(`[ollama-context-policy] FAILED: ${error?.stack || error}`);
  process.exit(1);
});
