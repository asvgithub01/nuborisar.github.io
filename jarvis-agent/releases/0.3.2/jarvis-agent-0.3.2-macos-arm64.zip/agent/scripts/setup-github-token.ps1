[CmdletBinding()]
param(
    [string]$GitHubUser = "asvia81",
    [switch]$SkipGhLogin
)

$ErrorActionPreference = "Stop"

function Write-Step([string]$message) {
    Write-Host ""
    Write-Host "==> $message" -ForegroundColor Cyan
}

function Set-UserEnvIfMissing([string]$name, [string]$value) {
    $current = [Environment]::GetEnvironmentVariable($name, "User")
    if ([string]::IsNullOrWhiteSpace($current)) {
        [Environment]::SetEnvironmentVariable($name, $value, "User")
        Write-Host "Set user env $name=$value"
    } else {
        Write-Host "User env $name already set -> $current"
    }
}

Write-Host "Jarvis GitHub token setup (interactive)" -ForegroundColor Green
Write-Host "User account: $GitHubUser"
Write-Host ""
Write-Host "Paste token when prompted (it will be hidden)." -ForegroundColor Yellow

$secureToken = Read-Host "GitHub token" -AsSecureString
$tokenBstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secureToken)
try {
    $token = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($tokenBstr)
} finally {
    [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($tokenBstr)
}

if ([string]::IsNullOrWhiteSpace($token)) {
    throw "Token is empty. Setup aborted."
}

Write-Step "Saving Jarvis user env variables"
[Environment]::SetEnvironmentVariable("JARVIS_GITHUB_TOKEN", $token, "User")
Set-UserEnvIfMissing -name "JARVIS_GIT_USER_NAME" -value $GitHubUser
Set-UserEnvIfMissing -name "JARVIS_GIT_USER_EMAIL" -value "jarvis@codex.es"
Set-UserEnvIfMissing -name "JARVIS_GIT_AUTO_PR" -value "true"
Set-UserEnvIfMissing -name "JARVIS_GIT_PR_BASE" -value "main"

$repos = @(
    "C:\asv\proyectos\2026\Autonomous",
    "C:\GIGIGOECONOCOM\Proyectos\2023\pantry-mvp"
)

Write-Step "Configuring git credential helper in local repos"
foreach ($repo in $repos) {
    if (-not (Test-Path "$repo\.git")) {
        Write-Host "Skip (not git repo): $repo" -ForegroundColor DarkYellow
        continue
    }

    git -C $repo config credential.helper store | Out-Null
    git -C $repo config credential.https://github.com.helper store | Out-Null

    @(
        "protocol=https"
        "host=github.com"
        "username=$GitHubUser"
        "password=$token"
        ""
    ) | git -C $repo credential approve | Out-Null

    Write-Host "Git credentials configured for: $repo"
}

if (-not $SkipGhLogin) {
    $ghPath = "C:\Program Files\GitHub CLI\gh.exe"
    if (Test-Path $ghPath) {
        Write-Step "Trying gh auth login (token-based)"
        Remove-Item Env:GH_TOKEN -ErrorAction SilentlyContinue
        $env:GH_TOKEN = $token
        try {
            $token | & $ghPath auth login --hostname github.com --git-protocol https --with-token
            & $ghPath auth setup-git | Out-Null
            & $ghPath auth status
        } catch {
            Write-Host "gh auth login warning: $($_.Exception.Message)" -ForegroundColor Yellow
            Write-Host "Continuing: agent can still use JARVIS_GITHUB_TOKEN."
        } finally {
            Remove-Item Env:GH_TOKEN -ErrorAction SilentlyContinue
        }
    } else {
        Write-Host "gh CLI not found at '$ghPath'. Skipping gh login." -ForegroundColor Yellow
    }
}

Write-Step "Verifying repository access with token"
$headers = @{
    Authorization = "token $token"
    "User-Agent"  = "jarvis-setup-script"
}
$remoteRepos = @(
    "asvgithub01/autonomous",
    "asvgithub01/pantry-mvp"
)

foreach ($repoId in $remoteRepos) {
    try {
        $null = Invoke-RestMethod -Method Get -Uri "https://api.github.com/repos/$repoId" -Headers $headers
        Write-Host "OK access: $repoId" -ForegroundColor Green
    } catch {
        Write-Host "NO access: $repoId -> $($_.Exception.Message)" -ForegroundColor Red
    }
}

Write-Step "Done"
Write-Host "Important: open a NEW terminal before starting agent so user env vars are loaded." -ForegroundColor Yellow
