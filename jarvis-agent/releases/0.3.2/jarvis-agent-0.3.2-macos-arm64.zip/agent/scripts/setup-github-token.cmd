@echo off
setlocal

set SCRIPT_DIR=%~dp0
set PS_SCRIPT=%SCRIPT_DIR%setup-github-token.ps1

if not exist "%PS_SCRIPT%" (
  echo ERROR: Script not found: "%PS_SCRIPT%"
  exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%PS_SCRIPT%" %*
set EXIT_CODE=%ERRORLEVEL%

if not "%EXIT_CODE%"=="0" (
  echo.
  echo Setup finished with errors (code %EXIT_CODE%).
  exit /b %EXIT_CODE%
)

echo.
echo Setup finished OK. Open a NEW terminal before running the agent.
exit /b 0
