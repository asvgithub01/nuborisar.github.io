﻿const fs = require("fs");
const os = require("os");
const path = require("path");
const crypto = require("crypto");
const { spawn } = require("child_process");
const { RuntimeState, RuntimeStatusStore } = require("./runtime-status");
const { IdleUpdateManager, isCodexUpdateRequiredError } = require("./update-manager");
const packageMetadata = require("./package.json");

const IS_WINDOWS = process.platform === "win32";
const IS_MACOS = process.platform === "darwin";

loadLocalDotEnv(path.resolve(__dirname, ".env"));

const BASE_URL = String(process.env.JARVIS_BASE_URL || "http://localhost:8080").trim();
const AGENT_TOKEN = String(process.env.JARVIS_AGENT_TOKEN || "").trim();
const AGENT_ID = String(process.env.JARVIS_AGENT_ID || `${os.hostname()}-agent`).trim();
const OWNER_USER_ID = String(process.env.JARVIS_OWNER_USER_ID || "").trim();
const AGENT_PAIRING_CODE = String(process.env.JARVIS_AGENT_PAIRING_CODE || "").trim();
const AGENT_DISPLAY_NAME = String(process.env.JARVIS_AGENT_DISPLAY_NAME || os.hostname()).trim();
const AGENT_RELEASE_VERSION = String(
  packageMetadata.version || process.env.JARVIS_AGENT_RELEASE_VERSION || "dev"
).trim() || "dev";

const POLL_MS = parseInt(process.env.JARVIS_POLL_MS || "3000", 10);
const HEARTBEAT_MS = parseInt(process.env.JARVIS_HEARTBEAT_MS || "3000", 10);
const WORKSPACE_SYNC_MS = parseInt(process.env.JARVIS_WORKSPACE_SYNC_MS || "60000", 10);
const WORKSPACE_SCAN_DEPTH = Math.max(1, parseInt(process.env.JARVIS_WORKSPACE_SCAN_DEPTH || "3", 10) || 3);
const WORKSPACE_PATHS = String(process.env.JARVIS_WORKSPACE_PATHS || "").trim();
const WORKSPACE_ROOTS = String(process.env.JARVIS_WORKSPACE_ROOTS || "").trim();
const AGENT_BOOTSTRAP_MAX_ATTEMPTS = Math.max(
  1,
  parseInt(process.env.JARVIS_AGENT_BOOTSTRAP_MAX_ATTEMPTS || "8", 10) || 8
);
const AGENT_BOOTSTRAP_RETRY_MS = Math.max(
  250,
  parseInt(process.env.JARVIS_AGENT_BOOTSTRAP_RETRY_MS || "1500", 10) || 1500
);

const ENABLE_CODEX = (process.env.JARVIS_CODEX_ENABLED || "true").toLowerCase() === "true";
const CODEX_TIMEOUT_MS = parseInt(process.env.JARVIS_CODEX_TIMEOUT_MS || "1200000", 10);
const CODEX_MODEL = String(process.env.JARVIS_CODEX_MODEL || "").trim();
const CLAUDE_TIMEOUT_MS = parseInt(process.env.JARVIS_CLAUDE_TIMEOUT_MS || String(CODEX_TIMEOUT_MS), 10);
const CLAUDE_MODEL = String(process.env.JARVIS_CLAUDE_MODEL || "").trim();
const CLAUDE_MAX_TURNS = Math.max(8, parseInt(process.env.JARVIS_CLAUDE_MAX_TURNS || "64", 10) || 64);
const OPENCODE_TIMEOUT_MS = parseInt(process.env.JARVIS_OPENCODE_TIMEOUT_MS || String(CODEX_TIMEOUT_MS), 10);
const OPENCODE_MODEL = String(process.env.JARVIS_OPENCODE_MODEL || "").trim();
const LOCAL_PROMPT_MAX_CHARS = Math.max(3000, parseInt(process.env.JARVIS_LOCAL_PROMPT_MAX_CHARS || "14000", 10) || 14000);
const LOCAL_AGENT_BUILD_RETRIES = Math.max(0, parseInt(process.env.JARVIS_LOCAL_AGENT_BUILD_RETRIES || "2", 10) || 2);
const LOCAL_AGENT_INSTRUCTIONS_FILE_NAME = "local-llm-agent-instructions.md";
const LOCAL_AGENT_REASONING_EFFORT = String(process.env.JARVIS_LOCAL_AGENT_REASONING_EFFORT || "").trim().toLowerCase();
const OPENCODE_LOCAL_SAFE_PROMPT_MAX_CHARS = Math.max(
  1200,
  parseInt(process.env.JARVIS_OPENCODE_LOCAL_SAFE_PROMPT_MAX_CHARS || "3600", 10) || 3600
);
const OPENCODE_LMSTUDIO_BASE_PROMPT_TOKENS = Math.max(
  4000,
  parseInt(process.env.JARVIS_OPENCODE_LMSTUDIO_BASE_PROMPT_TOKENS || "8000", 10) || 8000
);
const OPENCODE_LMSTUDIO_CONTEXT_SAFETY_MARGIN = Math.max(
  128,
  parseInt(process.env.JARVIS_OPENCODE_LMSTUDIO_CONTEXT_SAFETY_MARGIN || "256", 10) || 256
);
const LMSTUDIO_AUTOSTART_ENABLED = (process.env.JARVIS_LMSTUDIO_AUTOSTART_ENABLED || "true").toLowerCase() === "true";
const LMSTUDIO_START_COMMAND = String(process.env.JARVIS_LMSTUDIO_START_COMMAND || "").trim();
const LMSTUDIO_START_WAIT_MS = Math.max(5_000, parseInt(process.env.JARVIS_LMSTUDIO_START_WAIT_MS || "60000", 10) || 60_000);
const LMSTUDIO_HEALTH_TIMEOUT_MS = Math.max(1_000, parseInt(process.env.JARVIS_LMSTUDIO_HEALTH_TIMEOUT_MS || "5000", 10) || 5_000);
const LMSTUDIO_MODEL_LOAD_TIMEOUT_MS = Math.max(10_000, parseInt(process.env.JARVIS_LMSTUDIO_MODEL_LOAD_TIMEOUT_MS || "120000", 10) || 120_000);
const LMSTUDIO_ALLOW_DUPLICATE_START = (process.env.JARVIS_LMSTUDIO_ALLOW_DUPLICATE_START || "false").toLowerCase() === "true";
const LMSTUDIO_MODEL_CONTEXT_OVERRIDES = Object.freeze({
  "qwen/qwen3.6-35b-a3b": 80_724
});
const CODEX_SKIP_GIT_REPO_CHECK = (process.env.JARVIS_CODEX_SKIP_GIT_REPO_CHECK || "true").toLowerCase() === "true";
const CODEX_EPHEMERAL = (process.env.JARVIS_CODEX_EPHEMERAL || "false").toLowerCase() === "true";
const CODEX_SANITIZE_DESKTOP_ENV = (process.env.JARVIS_CODEX_SANITIZE_DESKTOP_ENV || "true").toLowerCase() === "true";
const CODEX_OUTPUT_STALL_TIMEOUT_MS = parseInt(process.env.JARVIS_CODEX_OUTPUT_STALL_TIMEOUT_MS || "90000", 10);
const CODEX_SANDBOX_MODE = normalizeCodexSandboxMode(process.env.JARVIS_CODEX_SANDBOX_MODE || "workspace-write");
const CODEX_APPROVAL_POLICY = "never";
const TASK_WORKTREE_ENABLED = (process.env.JARVIS_TASK_WORKTREE_ENABLED || "true").toLowerCase() === "true";
const TASK_WORKTREE_ROOT = String(process.env.JARVIS_TASK_WORKTREE_ROOT || "").trim();
const ADB_POLICY = normalizeAdbPolicy(process.env.JARVIS_ADB_POLICY || "DISABLED");
const ADB_ALLOWED_SERIAL = String(process.env.JARVIS_ADB_ALLOWED_SERIAL || "").trim();

const RUN_TESTS = (process.env.JARVIS_RUN_TESTS || "true").toLowerCase() === "true";
const RUN_BUILD = (process.env.JARVIS_RUN_BUILD || "true").toLowerCase() === "true";
const GRADLE_TEST_TASK = process.env.JARVIS_GRADLE_TEST_TASK || "testDebugUnitTest";
const GRADLE_BUILD_TASK = process.env.JARVIS_GRADLE_BUILD_TASK || "assembleDebug";
const GRADLE_JAVA_HOME = String(process.env.JARVIS_GRADLE_JAVA_HOME || "").trim();
const GRADLE_TIMEOUT_MS = parseInt(process.env.JARVIS_GRADLE_TIMEOUT_MS || "1800000", 10);
const GIT_AUTO_COMMIT = (process.env.JARVIS_GIT_AUTO_COMMIT || "true").toLowerCase() === "true";
const GIT_AUTO_PUSH = (process.env.JARVIS_GIT_AUTO_PUSH || "true").toLowerCase() === "true";
const GIT_PUSH_REMOTE = String(process.env.JARVIS_GIT_PUSH_REMOTE || "origin").trim();
const GIT_USER_NAME = String(process.env.JARVIS_GIT_USER_NAME || "").trim();
const GIT_USER_EMAIL = String(process.env.JARVIS_GIT_USER_EMAIL || "").trim();
const GIT_AUTO_PR = (process.env.JARVIS_GIT_AUTO_PR || "false").toLowerCase() === "true";
const GIT_PR_BASE = String(process.env.JARVIS_GIT_PR_BASE || "main").trim();
const GIT_PR_DRAFT = (process.env.JARVIS_GIT_PR_DRAFT || "false").toLowerCase() === "true";
const GIT_LOCAL_EXCLUDE_PATTERNS = (process.env.JARVIS_GIT_LOCAL_EXCLUDE_PATTERNS || [
  ".codex-temp/",
  "codex-temp/",
  ".gradle-user-home/",
  "gradle-user-home/",
  "build/",
  "app/build/",
  "*.hprof",
  ".jarvis-qa/",
  "qa-*.png",
  "**/qa-*.png",
  "uiautomator*.xml",
  "**/uiautomator*.xml",
].join(","))
  .split(",")
  .map((entry) => entry.trim())
  .filter(Boolean);
const RESTORE_ORIGINAL_BRANCH = (process.env.JARVIS_RESTORE_ORIGINAL_BRANCH || "true").toLowerCase() === "true";
const ONE_SHOT = (process.env.JARVIS_ONE_SHOT || "false").toLowerCase() === "true";
const ONE_SHOT_IDLE_TIMEOUT_MS = parseInt(process.env.JARVIS_ONE_SHOT_IDLE_TIMEOUT_MS || "60000", 10);

const APK_SOURCE_PATH = String(process.env.JARVIS_APK_SOURCE_PATH || "").trim();
const LOG_DIR = path.resolve(String(process.env.JARVIS_AGENT_LOG_DIR || path.join(__dirname, "logs")).trim());
const RUNTIME_STATUS_FILE = path.resolve(
  String(process.env.JARVIS_AGENT_STATUS_FILE || path.join(LOG_DIR, "runtime-status.json")).trim()
);
const runtimeStatus = new RuntimeStatusStore({
  filePath: RUNTIME_STATUS_FILE,
  agentId: AGENT_ID,
  agentVersion: AGENT_RELEASE_VERSION,
});
const CODEX_AUTO_UPDATE_ENABLED = (
  process.env.JARVIS_CODEX_AUTO_UPDATE
  || process.env.JARVIS_CODEX_AUTO_UPDATE_ENABLED
  || "true"
).toLowerCase() === "true";
const CODEX_UPDATE_CHECK_MS = Math.max(
  60_000,
  parseInt(
    process.env.JARVIS_CODEX_UPDATE_CHECK_MS
      || String((parseFloat(process.env.JARVIS_CODEX_UPDATE_INTERVAL_HOURS || "6") || 6) * 3_600_000),
    10
  ) || 21_600_000
);
const AGENT_AUTO_UPDATE_ENABLED = (
  process.env.JARVIS_AGENT_AUTO_UPDATE
  || process.env.JARVIS_AGENT_AUTO_UPDATE_ENABLED
  || "true"
).toLowerCase() === "true";
const AGENT_UPDATE_CHECK_MS = Math.max(
  60_000,
  parseInt(
    process.env.JARVIS_AGENT_UPDATE_CHECK_MS
      || String((parseFloat(process.env.JARVIS_AGENT_UPDATE_INTERVAL_HOURS || "6") || 6) * 3_600_000),
    10
  ) || 21_600_000
);
const AGENT_UPDATE_MANIFEST_URL = String(
  process.env.JARVIS_AGENT_UPDATE_URL
  || process.env.JARVIS_AGENT_UPDATE_MANIFEST_URL
  || ""
).trim();
const AGENT_UPDATE_CHANNEL = String(process.env.JARVIS_AGENT_UPDATE_CHANNEL || "stable").trim().toLowerCase() || "stable";
const AGENT_UPDATE_ALLOW_HTTP = (process.env.JARVIS_AGENT_UPDATE_ALLOW_HTTP || "false").toLowerCase() === "true";
const AGENT_ALLOW_SOURCE_SELF_UPDATE = (
  process.env.JARVIS_AGENT_ALLOW_SOURCE_SELF_UPDATE || "false"
).toLowerCase() === "true";
const RUNNING_FROM_SOURCE_CHECKOUT = fs.existsSync(path.resolve(__dirname, "..", ".git"));
let lastRuntimeCodex = null;
let pendingCodexRecoveryTaskId = null;
const codexRecoveryAttemptedTasks = new Set();
const RUNTIME_LOG_SYNC_MS = Math.max(500, parseInt(process.env.JARVIS_RUNTIME_LOG_SYNC_MS || "1000", 10) || 1000);
const RUNTIME_LOG_SNAPSHOT_MAX_CHARS = Math.max(
  100_000,
  Math.min(1_150_000, parseInt(process.env.JARVIS_RUNTIME_LOG_SNAPSHOT_MAX_CHARS || "1100000", 10) || 1_100_000)
);
const BACKEND_AUTORESTART_ENABLED = (
  process.env.JARVIS_BACKEND_AUTORESTART_ENABLED
  || (IS_WINDOWS ? "true" : "false")
).toLowerCase() === "true";
const BACKEND_RESTART_ONLY_LOCAL = (process.env.JARVIS_BACKEND_RESTART_ONLY_LOCAL || "true").toLowerCase() === "true";
const BACKEND_HEALTH_PATH = String(process.env.JARVIS_BACKEND_HEALTH_PATH || "/actuator/health").trim();
const DEFAULT_BACKEND_RESTART_COMMAND = IS_WINDOWS
  ? path.resolve(__dirname, "..", "backend", "scripts", "start-dev-bg.cmd")
  : path.resolve(__dirname, "..", "backend", "scripts", "start-dev-bg.sh");
const BACKEND_RESTART_COMMAND = (
  process.env.JARVIS_BACKEND_RESTART_COMMAND
  || DEFAULT_BACKEND_RESTART_COMMAND
).trim();
const BACKEND_RESTART_COOLDOWN_MS = parseInt(process.env.JARVIS_BACKEND_RESTART_COOLDOWN_MS || "60000", 10);
const BACKEND_RESTART_WAIT_MS = parseInt(process.env.JARVIS_BACKEND_RESTART_WAIT_MS || "45000", 10);
const BACKEND_PROBE_TIMEOUT_MS = parseInt(process.env.JARVIS_BACKEND_PROBE_TIMEOUT_MS || "4000", 10);
const HTTP_REQUEST_TIMEOUT_MS = parseInt(process.env.JARVIS_HTTP_REQUEST_TIMEOUT_MS || "30000", 10);
const ARTIFACT_UPLOAD_TIMEOUT_MS = Math.max(
  HTTP_REQUEST_TIMEOUT_MS,
  parseInt(process.env.JARVIS_ARTIFACT_UPLOAD_TIMEOUT_MS || "120000", 10) || 120000
);
const PROCESS_FORCE_KILL_GRACE_MS = parseInt(process.env.JARVIS_PROCESS_FORCE_KILL_GRACE_MS || "7000", 10);
const TOKEN_EXPIRY_ALERT_DAYS = parseInt(process.env.JARVIS_TOKEN_EXPIRY_ALERT_DAYS || "30", 10);
const AGENT_TOKEN_POOL = parseTokenPool(process.env.JARVIS_AGENT_TOKEN_POOL || "");
const CODEX_ACCOUNT_POOL = parseTokenPool(process.env.JARVIS_CODEX_ACCOUNT_POOL || "");
const CLAUDE_ACCOUNT_POOL = parseTokenPool(process.env.JARVIS_CLAUDE_ACCOUNT_POOL || "");
const AGENT_AUTH_ACCOUNTS = buildAgentAuthAccounts();
const POOL_STARTUP_WARNINGS = [
  ...AGENT_TOKEN_POOL.errors.map((error) => `Agent token pool: ${error}`),
  ...CODEX_ACCOUNT_POOL.errors.map((error) => `Codex pool: ${error}`),
  ...CLAUDE_ACCOUNT_POOL.errors.map((error) => `Claude pool: ${error}`),
  ...buildPoolExpiryWarnings(AGENT_TOKEN_POOL.entries, "Agent token"),
  ...buildPoolExpiryWarnings(CODEX_ACCOUNT_POOL.entries, "Codex"),
  ...buildPoolExpiryWarnings(CLAUDE_ACCOUNT_POOL.entries, "Claude"),
];

let backendRestartInFlight = null;
let backendLastRestartAt = 0;
let poolWarningsNotified = false;
let activeAgentAuthIndex = 0;
let opencodeInstallAttempted = false;
let workspaceSyncInFlight = null;
let lmStudioModelCatalogCache = null;
const EXEC_PROFILE_JSON_START = "[EXECUTION_PROFILE_JSON]";
const EXEC_PROFILE_JSON_END = "[/EXECUTION_PROFILE_JSON]";
const EXEC_PROFILE_STATE_TAG = "[EXEC_PROFILE_STATE]";
const EXEC_PROFILE_RESUME_TAG = "[EXEC_PROFILE_RESUME]";

function loadLocalDotEnv(envFilePath) {
  if (!envFilePath || !fs.existsSync(envFilePath)) {
    return;
  }

  const lines = fs.readFileSync(envFilePath, "utf8").split(/\r?\n/);
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) {
      continue;
    }
    const equals = trimmed.indexOf("=");
    if (equals <= 0) {
      continue;
    }
    const key = trimmed.slice(0, equals).trim();
    const value = trimmed.slice(equals + 1);
    if (!key || process.env[key] !== undefined) {
      continue;
    }
    process.env[key] = value;
  }
}

function parseTokenPool(raw) {
  const entries = [];
  const errors = [];
  const normalizedRaw = String(raw || "").trim();
  const chunks = [];

  if (normalizedRaw.startsWith("[")) {
    try {
      const parsed = JSON.parse(normalizedRaw);
      if (!Array.isArray(parsed)) {
        errors.push("formato JSON invÃ¡lido: se esperaba array");
      } else {
        parsed.forEach((item, index) => {
          if (typeof item === "string") {
            chunks.push(item);
            return;
          }
          if (item && typeof item === "object") {
            const label = String(item.label || item.name || `account-${index + 1}`).trim();
            const token = String(item.token || item.apiKey || "").trim();
            const expires = String(item.expiresAt || item.expiresOn || item.expiry || "").trim();
            if (!token) {
              errors.push(`entrada '${label}' sin token`);
              return;
            }
            chunks.push(expires ? `${label}|${token}|${expires}` : `${label}|${token}`);
            return;
          }
          errors.push(`entrada JSON #${index + 1} invÃ¡lida`);
        });
      }
    } catch (error) {
      errors.push(`formato JSON invÃ¡lido: ${error.message}`);
    }
  } else {
    normalizedRaw
      .split(/[\n;]/)
      .map((part) => part.trim())
      .filter(Boolean)
      .forEach((chunk) => chunks.push(chunk));
  }

  chunks.forEach((chunk, index) => {
    const parts = chunk.split("|").map((part) => part.trim());
    let label = `account-${index + 1}`;
    let token = "";
    let rawDate = null;
    if (parts.length === 1) {
      token = parts[0];
    } else {
      label = parts[0] || label;
      token = parts[1] || "";
      rawDate = parts[2] || null;
    }
    if (!token) {
      errors.push(`entrada '${label}' sin token`);
      return;
    }

    let expiresAt = null;
    if (rawDate) {
      const parsed = parseIsoDate(rawDate);
      if (!parsed) {
        errors.push(`entrada '${label}' con fecha invÃ¡lida '${rawDate}' (esperado YYYY-MM-DD)`);
      } else {
        expiresAt = parsed;
      }
    }

    entries.push({ label, token, expiresAt });
  });

  return { entries, errors };
}

function buildAgentAuthAccounts() {
  const accounts = [];
  const seen = new Set();

  for (const entry of AGENT_TOKEN_POOL.entries) {
    const token = String(entry.token || "").trim();
    if (!token || seen.has(token)) {
      continue;
    }
    seen.add(token);
    accounts.push({
      label: entry.label || `agent-token-${accounts.length + 1}`,
      token,
      expiresAt: entry.expiresAt || null,
      source: "pool",
    });
  }

  const fallbackToken = String(AGENT_TOKEN || "").trim();
  if (fallbackToken && !seen.has(fallbackToken)) {
    accounts.push({
      label: "env-agent-token",
      token: fallbackToken,
      expiresAt: null,
      source: "env",
    });
  }

  return accounts;
}

function currentAgentAuthAccount() {
  return AGENT_AUTH_ACCOUNTS[activeAgentAuthIndex] || AGENT_AUTH_ACCOUNTS[0];
}

function rotateAgentAuthAccount() {
  if (AGENT_AUTH_ACCOUNTS.length <= 1) {
    return false;
  }
  if (activeAgentAuthIndex >= AGENT_AUTH_ACCOUNTS.length - 1) {
    return false;
  }
  activeAgentAuthIndex += 1;
  return true;
}

function parseIsoDate(rawDate) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(rawDate || "")) {
    return null;
  }
  const date = new Date(`${rawDate}T00:00:00Z`);
  if (Number.isNaN(date.getTime())) {
    return null;
  }
  return date;
}

function daysUntil(date) {
  const now = new Date();
  const utcToday = Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate());
  const utcTarget = Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate());
  return Math.floor((utcTarget - utcToday) / 86_400_000);
}

function buildPoolExpiryWarnings(entries, providerLabel) {
  const warnings = [];
  for (const entry of entries) {
    if (!entry.expiresAt) {
      warnings.push(`${providerLabel} '${entry.label}' sin fecha de caducidad configurada.`);
      continue;
    }
    const days = daysUntil(entry.expiresAt);
    if (days < 0) {
      warnings.push(`${providerLabel} '${entry.label}' caducada desde ${entry.expiresAt.toISOString().slice(0, 10)}.`);
    } else if (days <= TOKEN_EXPIRY_ALERT_DAYS) {
      warnings.push(`${providerLabel} '${entry.label}' caduca en ${days} dÃ­as (${entry.expiresAt.toISOString().slice(0, 10)}).`);
    }
  }
  return warnings;
}

function buildCodexExecutionAccounts() {
  const accounts = [];
  const seen = new Set();

  for (const entry of CODEX_ACCOUNT_POOL.entries) {
    const token = String(entry.token || "").trim();
    if (!token || seen.has(token)) {
      continue;
    }
    seen.add(token);
    accounts.push({
      label: entry.label || `pool-${accounts.length + 1}`,
      token,
      expiresAt: entry.expiresAt,
      source: "pool",
    });
  }

  const envToken = String(process.env.OPENAI_API_KEY || "").trim();
  if (envToken && !seen.has(envToken)) {
    accounts.push({
      label: "env-openai-api-key",
      token: envToken,
      expiresAt: null,
      source: "env",
    });
  }

  if (accounts.length === 0) {
    accounts.push({
      label: "default-env",
      token: null,
      expiresAt: null,
      source: "default",
    });
  }

  return accounts;
}

function isRetryableCodexAccountError(rawOutput) {
  const normalized = String(rawOutput || "").toLowerCase();
  return (
    normalized.includes("usage limit")
    || normalized.includes("hit your usage limit")
    || normalized.includes("insufficient credits")
    || normalized.includes("purchase more credits")
    || normalized.includes("rate limit")
    || normalized.includes("too many requests")
    || normalized.includes("quota")
    || normalized.includes("429")
    || normalized.includes("authentication_error")
    || normalized.includes("invalid x-api-key")
    || normalized.includes("invalid api key")
    || normalized.includes("unauthorized")
    || normalized.includes("401")
  );
}

function buildClaudeExecutionAccounts(claudeRuntimeConfig = null) {
  const accounts = [];
  const seen = new Set();
  const authMode = String(claudeRuntimeConfig?.authMode || "API_KEY").trim().toUpperCase();

  if (authMode === "LOCAL_AGENT") {
    return [{
      label: "runtime-local-agent",
      token: null,
      authMode: "LOCAL_AGENT",
      expiresAt: null,
      source: "runtime",
    }];
  }

  const runtimeToken = authMode === "GATEWAY"
    ? String(claudeRuntimeConfig?.authToken || "").trim()
    : String(claudeRuntimeConfig?.apiKey || "").trim();
  if (runtimeToken && !seen.has(runtimeToken)) {
    seen.add(runtimeToken);
    accounts.push({
      label: `runtime-${authMode === "GATEWAY" ? "gateway-token" : "api-key"}`,
      token: runtimeToken,
      authMode,
      expiresAt: null,
      source: "runtime",
    });
  }

  for (const entry of CLAUDE_ACCOUNT_POOL.entries) {
    const token = String(entry.token || "").trim();
    if (!token || seen.has(token)) {
      continue;
    }
    seen.add(token);
    accounts.push({
      label: entry.label || `claude-pool-${accounts.length + 1}`,
      token,
      authMode,
      expiresAt: entry.expiresAt,
      source: "pool",
    });
  }

  const envToken = String(process.env.ANTHROPIC_API_KEY || "").trim();
  if (envToken && !seen.has(envToken)) {
    accounts.push({
      label: "env-anthropic-api-key",
      token: envToken,
      authMode: "API_KEY",
      expiresAt: null,
      source: "env",
    });
  }

  if (accounts.length === 0) {
    accounts.push({
      label: "default-env",
      token: null,
      authMode,
      expiresAt: null,
      source: "default",
    });
  }

  return accounts;
}

function isRetryableClaudeAccountError(rawOutput) {
  const normalized = String(rawOutput || "").toLowerCase();
  return (
    normalized.includes("usage limit")
    || normalized.includes("credit balance")
    || normalized.includes("rate limit")
    || normalized.includes("too many requests")
    || normalized.includes("quota")
    || normalized.includes("429")
    || normalized.includes("invalid x-api-key")
    || normalized.includes("invalid api key")
    || normalized.includes("authentication")
    || normalized.includes("unauthorized")
    || normalized.includes("not logged in")
    || normalized.includes("401")
    || normalized.includes("403")
  );
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function resolveWindowsSystemExecutable(executable) {
  if (!IS_WINDOWS) return executable;
  const normalized = String(executable || "").trim();
  if (!normalized) return normalized;
  if (normalized.toLowerCase() === "cmd" || normalized.toLowerCase() === "cmd.exe") {
    const comSpec = String(process.env.ComSpec || process.env.COMSPEC || "").trim();
    if (comSpec) return comSpec;
  }
  const systemRoot = String(process.env.SystemRoot || process.env.SYSTEMROOT || "C:\\Windows").trim();
  const candidate = path.join(systemRoot, "System32", normalized.endsWith(".exe") ? normalized : `${normalized}.exe`);
  return fs.existsSync(candidate) ? candidate : normalized;
}

function prependExecutablePath(env, directory) {
  const target = env || {};
  const pathKeys = Object.keys(target).filter((key) => key.toLowerCase() === "path");
  const primaryKey = pathKeys[0] || (IS_WINDOWS ? "Path" : "PATH");
  const currentPath = String(target[primaryKey] || "");
  for (const duplicateKey of pathKeys.slice(1)) {
    delete target[duplicateKey];
  }
  target[primaryKey] = currentPath ? `${directory}${path.delimiter}${currentPath}` : directory;
  return target;
}

function setRuntimeStatus(state, details = {}) {
  try {
    if (details.codex) lastRuntimeCodex = details.codex;
    return runtimeStatus.set(state, {
      ...details,
      codex: details.codex || lastRuntimeCodex,
    });
  } catch (error) {
    console.warn(`[agent][runtime-status] unable to publish ${state}: ${error.message}`);
    return null;
  }
}

function patchRuntimeStatus(details = {}) {
  try {
    if (details.codex) lastRuntimeCodex = details.codex;
    return runtimeStatus.patch({
      ...details,
      codex: details.codex || lastRuntimeCodex,
    });
  } catch (error) {
    console.warn(`[agent][runtime-status] unable to patch current state: ${error.message}`);
    return null;
  }
}

const updateManager = new IdleUpdateManager({
  agentVersion: AGENT_RELEASE_VERSION,
  manifestUrl: AGENT_UPDATE_MANIFEST_URL,
  channel: AGENT_UPDATE_CHANNEL,
  platformKey: process.platform === "win32"
    ? `windows-${process.arch}`
    : process.platform === "darwin"
      ? `macos-${process.arch === "arm64" ? "arm64" : process.arch}`
      : `${process.platform}-${process.arch}`,
  logDir: LOG_DIR,
  installRoot: __dirname,
  codexEnabled: ENABLE_CODEX && CODEX_AUTO_UPDATE_ENABLED,
  agentEnabled: AGENT_AUTO_UPDATE_ENABLED && (!RUNNING_FROM_SOURCE_CHECKOUT || AGENT_ALLOW_SOURCE_SELF_UPDATE),
  codexCheckMs: CODEX_UPDATE_CHECK_MS,
  agentCheckMs: AGENT_UPDATE_CHECK_MS,
  allowHttp: AGENT_UPDATE_ALLOW_HTTP,
  onStatus: (state, details) => setRuntimeStatus(state, details),
});

function scheduleAgentUpdateRestart(updateResult) {
  const helper = spawn(process.execPath, [
    path.join(__dirname, "restart-agent.js"),
    String(process.pid),
    __dirname,
    path.join(LOG_DIR, "agent.log"),
    String(updateResult.currentVersion || ""),
    String(updateResult.backupRoot || ""),
    RUNTIME_STATUS_FILE,
  ], {
    cwd: __dirname,
    env: process.env,
    detached: true,
    stdio: "ignore",
    windowsHide: true,
  });
  helper.unref();
}

async function runIdleMaintenance() {
  const recoveryTaskId = pendingCodexRecoveryTaskId;
  const result = await updateManager.maintain({ forceCodex: Boolean(recoveryTaskId) });

  if (result.codex) {
    const codex = {
      currentVersion: result.codex.currentVersion || result.codex.previousVersion || null,
      latestVersion: result.codex.latestVersion || null,
      executablePath: result.codex.executablePath || null,
      managedBy: result.codex.managedBy || null,
      error: result.codex.error || null,
    };
    lastRuntimeCodex = codex;
    if (recoveryTaskId) {
      pendingCodexRecoveryTaskId = null;
      if (result.codex.updated) {
        await addMessage(
          recoveryTaskId,
          "system",
          `Codex se actualizo automaticamente a ${result.codex.currentVersion}; la tarea se reintentara una sola vez.`
        );
        await updateStatus(recoveryTaskId, "PENDING", null);
        console.log(`[agent][update] task=${recoveryTaskId} requeued after Codex update`);
      } else {
        console.warn(
          `[agent][update] task=${recoveryTaskId} remains WAITING_USER; Codex was not updated: ${result.codex.error || "no newer npm version"}`
        );
      }
    }
  }

  if (result.agent?.updated && result.agent.restartRequired) {
    setRuntimeStatus(RuntimeState.UPDATING_AGENT, {
      action: `Jarvis Agent ${result.agent.currentVersion} instalado; reiniciando`,
      update: result.agent,
    });
    console.log(
      `[agent][update] agent ${result.agent.previousVersion} -> ${result.agent.currentVersion}; backup=${result.agent.backupRoot}`
    );
    scheduleAgentUpdateRestart(result.agent);
    return { restartRequired: true, result };
  }

  setRuntimeStatus(RuntimeState.LISTENING, {
    action: "A la escucha de comandos y tareas",
  });
  return { restartRequired: false, result };
}

function buildExecutableCommand(executable, args = []) {
  if (IS_WINDOWS) {
    return { command: resolveWindowsSystemExecutable("cmd.exe"), args: ["/c", executable, ...args] };
  }
  return { command: executable, args };
}

function buildShellCommand(commandLine) {
  if (IS_WINDOWS) {
    return { command: resolveWindowsSystemExecutable("cmd.exe"), args: ["/c", commandLine] };
  }
  return { command: "/bin/bash", args: ["-lc", commandLine] };
}

function runExecutableCommand({ executable, args = [], ...options }) {
  const spec = buildExecutableCommand(executable, args);
  return runCommand({
    ...options,
    command: spec.command,
    args: spec.args,
  });
}

function headers(extra = {}) {
  const account = currentAgentAuthAccount();
  return {
    Authorization: `Bearer ${account?.token || AGENT_TOKEN}`,
    ...extra,
  };
}

function ensureDirectory(dirPath) {
  fs.mkdirSync(dirPath, { recursive: true });
}

function sanitizeFileComponent(value) {
  const normalized = String(value || "")
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-zA-Z0-9._-]+/g, "-")
    .replace(/-+/g, "-")
    .replace(/^[-.]+|[-.]+$/g, "")
    .trim();
  return normalized || "item";
}

function clipText(text, max = 12000) {
  if (!text) {
    return "";
  }
  if (text.length <= max) {
    return text;
  }
  return `${text.slice(0, max)}\n...[truncated ${text.length - max} chars]`;
}

function clipBalancedText(text, max = 12000, headRatio = 0.72) {
  const raw = String(text || "");
  if (!raw) {
    return "";
  }
  if (raw.length <= max) {
    return raw;
  }
  const safeMax = Math.max(200, max);
  const marker = `\n...[truncated ${raw.length - safeMax} chars]...\n`;
  const available = Math.max(80, safeMax - marker.length);
  const clampedHeadRatio = Math.min(0.9, Math.max(0.5, headRatio));
  const headChars = Math.max(60, Math.floor(available * clampedHeadRatio));
  const tailChars = Math.max(20, available - headChars);
  return `${raw.slice(0, headChars)}${marker}${raw.slice(raw.length - tailChars)}`;
}

function estimateTokenCountFromText(text) {
  const raw = String(text || "");
  if (!raw) return 0;
  return Math.ceil(raw.length / 4);
}

function compactSuccessfulGradleOutputForMemory(text) {
  const raw = String(text || "");
  if (!/\bBUILD SUCCESSFUL\b/i.test(raw)) return raw;
  const lines = raw.split(/\r?\n/);
  let removedTaskLines = 0;
  const compacted = lines.filter((line) => {
    const trimmed = String(line || "").trim();
    if (/^(?:>?\s*)?Task\s+:[^\r\n]+(?:\s+(?:UP-TO-DATE|NO-SOURCE|FROM-CACHE|SKIPPED))?\s*$/i.test(trimmed)) {
      removedTaskLines += 1;
      return false;
    }
    if (/^\d+\s+actionable\s+tasks?:\s+/i.test(trimmed)) {
      removedTaskLines += 1;
      return false;
    }
    return true;
  });
  if (removedTaskLines <= 0) return raw;
  return [
    ...compacted,
    "",
    `[GRADLE_OUTPUT_COMPACTED] BUILD SUCCESSFUL; se eliminaron ${removedTaskLines} lineas de tareas Gradle repetitivas/no relevantes para ahorrar contexto.`
  ].join("\n").replace(/\n{4,}/g, "\n\n\n").trim();
}

function normalizeComparableText(text) {
  return stripAnsiAndControlChars(text)
    .toLowerCase()
    .replace(/\s+/g, " ")
    .trim();
}

function dedupeParagraphs(text) {
  const raw = String(text || "").trim();
  if (!raw) return "";
  const parts = raw
    .split(/\n{2,}/)
    .map((item) => item.trim())
    .filter(Boolean);
  const seen = new Set();
  const result = [];
  for (const part of parts) {
    const key = normalizeComparableText(part);
    if (!key || seen.has(key)) continue;
    seen.add(key);
    result.push(part);
  }
  return result.join("\n\n");
}

function protectMarkdownCodeBlocks(text) {
  const blocks = [];
  const protectedText = String(text || "").replace(/```[\s\S]*?```/g, (match) => {
    const token = `__CODEBLOCK_${blocks.length}__`;
    blocks.push(match);
    return token;
  });
  return { protectedText, blocks };
}

function restoreMarkdownCodeBlocks(text, blocks) {
  let restored = String(text || "");
  (Array.isArray(blocks) ? blocks : []).forEach((block, index) => {
    restored = restored.replace(`__CODEBLOCK_${index}__`, block);
  });
  return restored;
}

const TARZAN_PHRASE_REPLACEMENTS = {
  "por favor": "",
  "podrÃ­as": "",
  "podria": "",
  "me gustarÃ­a": "",
  "serÃ­a recomendable": "",
  "es importante tener en cuenta que": "",
  "ten en cuenta que": "",
  "en este caso": "",
  "de alguna manera": "",
  "bÃ¡sicamente": "",
  "en realidad": "",
  "quiero que": "",
  "necesito que": "",
  "me puedes": "",
  "podrÃ­as ayudarme": "ayuda",
  "por lo tanto": "=>",
  "debido a": "x",
  "con el objetivo de": "para",
};

const TARZAN_WORD_REPLACEMENTS = {
  "autenticaciÃ³n": "auth",
  "autenticacion": "auth",
  "aplicaciÃ³n": "app",
  "aplicacion": "app",
  "configuraciÃ³n": "cfg",
  "configuracion": "cfg",
  "servidor": "srv",
  "usuario": "usr",
  "usuarios": "usr",
  "peticiÃ³n": "req",
  "peticiones": "req",
  "respuesta": "rsp",
  "respuestas": "rsp",
  "base de datos": "db",
  "informaciÃ³n": "info",
  "informacion": "info",
  "archivo": "file",
  "archivos": "files",
  "contraseÃ±a": "pwd",
  "javascript": "js",
  "typescript": "ts",
  "documentaciÃ³n": "docs",
  "documentacion": "docs",
  "funciÃ³n": "fn",
  "funciones": "fns",
  "ejemplo": "ej",
  "parÃ¡metro": "param",
  "parametro": "param",
};

const TARZAN_FILLER_WORDS = [
  "el",
  "la",
  "los",
  "las",
  "un",
  "una",
  "unos",
  "unas",
  "de",
  "del",
  "que",
  "muy",
  "realmente",
  "simplemente",
  "solamente",
  "entonces"
];

function escapeRegex(string) {
  return String(string || "").replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function applyTarzanSpanishCompression(text) {
  const raw = String(text || "").trim();
  if (!raw) return "";
  const { protectedText, blocks } = protectMarkdownCodeBlocks(raw);
  let compacted = protectedText;

  for (const [key, value] of Object.entries(TARZAN_PHRASE_REPLACEMENTS)) {
    compacted = compacted.replace(new RegExp(`\\b${escapeRegex(key)}\\b`, "gi"), value);
  }
  for (const [key, value] of Object.entries(TARZAN_WORD_REPLACEMENTS)) {
    compacted = compacted.replace(new RegExp(`\\b${escapeRegex(key)}\\b`, "gi"), value);
  }
  TARZAN_FILLER_WORDS.forEach((word) => {
    compacted = compacted.replace(new RegExp(`\\b${escapeRegex(word)}\\b`, "gi"), "");
  });

  compacted = compacted
    .replace(/[ \t]+\n/g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .replace(/[ \t]{2,}/g, " ")
    .replace(/\s+/g, " ")
    .trim();

  return restoreMarkdownCodeBlocks(compacted, blocks).trim();
}

function stripAnsiAndControlChars(text) {
  if (text === null || text === undefined) {
    return "";
  }
  return String(text)
    .replace(/\u001b\[[0-9;?]*[ -/]*[@-~]/g, "")
    .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, "");
}

function sanitizeTransportValue(value) {
  if (value === null || value === undefined) return value;
  if (typeof value === "string") {
    return stripAnsiAndControlChars(value);
  }
  if (Array.isArray(value)) {
    return value.map((item) => sanitizeTransportValue(item));
  }
  if (typeof value === "object") {
    const out = {};
    for (const [key, inner] of Object.entries(value)) {
      out[key] = sanitizeTransportValue(inner);
    }
    return out;
  }
  return value;
}

function extractExecutionProfileJsonBlock(text) {
  const raw = String(text || "");
  const lower = raw.toLowerCase();
  const start = lower.indexOf(EXEC_PROFILE_JSON_START.toLowerCase());
  if (start < 0) return null;
  const end = lower.indexOf(EXEC_PROFILE_JSON_END.toLowerCase(), start + EXEC_PROFILE_JSON_START.length);
  if (end < 0) return null;
  const jsonRaw = raw.slice(start + EXEC_PROFILE_JSON_START.length, end).trim();
  if (!jsonRaw) return null;
  try {
    return JSON.parse(jsonRaw);
  } catch (_error) {
    return null;
  }
}

function extractPromptOriginalFromEnvelope(text) {
  const raw = String(text || "");
  const marker = "PROMPT ORIGINAL:";
  const idx = raw.toLowerCase().indexOf(marker.toLowerCase());
  if (idx < 0) return "";
  return raw.slice(idx + marker.length).trim();
}

function readProfileValue(source, keys, fallback = "") {
  if (!source || typeof source !== "object") return fallback;
  for (const key of keys) {
    if (Object.prototype.hasOwnProperty.call(source, key)) {
      const value = source[key];
      return value === null || value === undefined ? fallback : value;
    }
  }
  return fallback;
}

function readProfileArray(source, keys) {
  const value = readProfileValue(source, keys, []);
  return Array.isArray(value) ? value : [];
}

function parseExecutionProfileFromTask(taskPayload) {
  const messages = Array.isArray(taskPayload?.messages) ? taskPayload.messages : [];
  const userMessages = messages.filter((item) => String(item?.role || "").toLowerCase() === "user");
  const primaryText = [
    ...userMessages.map((item) => String(item?.content || "")),
    String(taskPayload?.agentContextPrompt || "")
  ].find((value) => String(value || "").toLowerCase().includes(EXEC_PROFILE_JSON_START.toLowerCase()));
  if (!primaryText) return null;
  const parsed = extractExecutionProfileJsonBlock(primaryText);
  if (!parsed || !Array.isArray(parsed.steps) || !parsed.steps.length) return null;
  const steps = parsed.steps
    .map((step, index) => ({
      index: Number.isFinite(Number(readProfileValue(step, ["index"]))) ? Number(readProfileValue(step, ["index"])) : index,
      name: String(readProfileValue(step, ["name"], `Paso ${index + 1}`)).trim() || `Paso ${index + 1}`,
      description: String(readProfileValue(step, ["description"], "")).trim(),
      agentEngine: String(readProfileValue(step, ["agentEngine", "agentengine"], "CODEX")).trim().toUpperCase() || "CODEX",
      modelProvider: String(readProfileValue(step, ["modelProvider", "modelprovider"], "ALL")).trim().toUpperCase() || "ALL",
      model: String(readProfileValue(step, ["model"], "")).trim(),
      reasoningEffort: normalizeReasoningEffort(readProfileValue(step, ["reasoningEffort", "reasoningeffort"], "")),
      context: String(readProfileValue(step, ["context"], "")).trim(),
      initialPrompt: String(readProfileValue(step, ["initialPrompt", "initialprompt"], "")).trim(),
      skillTags: readProfileArray(step, ["skillTags", "skilltags"]).map((item) => String(item || "").trim()).filter(Boolean),
      requireWorktree: readProfileValue(step, ["requireWorktree", "requireworktree"], false) === true,
      finalizeWithWaitingUser: readProfileValue(step, ["finalizeWithWaitingUser", "finalizewithwaitinguser"], false) === true,
      stepContextProjectId: String(readProfileValue(step, ["stepContextProjectId", "stepcontextprojectid"], "")).trim(),
      stepContextSourceKeys: readProfileArray(step, ["stepContextSourceKeys", "stepcontextsourcekeys"])
        .map((item) => String(item || "").trim()).filter(Boolean),
      contextBudgetTokens: Number(readProfileValue(step, ["contextBudgetTokens", "contextbudgettokens", "graphBudgetTokens", "graphbudgettokens"], 0)) || 0,
      graphQuery: String(readProfileValue(step, ["graphQuery", "graphquery"], "")).trim(),
      graphSourceKeys: readProfileArray(step, ["graphSourceKeys", "graphsourcekeys"])
        .map((item) => String(item || "").trim()).filter(Boolean),
      useContextGraph: readProfileValue(step, ["useContextGraph", "usecontextgraph"], false) === true,
      usePreviousOutputGraph: readProfileValue(step, ["usePreviousOutputGraph", "usepreviousoutputgraph"], false) === true,
      previousOutputBudgetTokens: Number(readProfileValue(step, [
        "previousOutputBudgetTokens",
        "previousoutputbudgettokens",
        "stepOutputBudgetTokens",
        "stepoutputbudgettokens",
        "outputContextBudgetTokens",
        "outputcontextbudgettokens"
      ], 0)) || 0,
      previousOutputGraphQuery: String(readProfileValue(step, [
        "previousOutputGraphQuery",
        "previousoutputgraphquery",
        "stepOutputGraphQuery",
        "stepoutputgraphquery"
      ], "")).trim(),
      stepContextPromptSnapshot: String(readProfileValue(step, ["stepContextPromptSnapshot", "stepcontextpromptsnapshot"], "")).trim(),
      stepContextSourceOrigins: readProfileArray(step, ["stepContextSourceOrigins", "stepcontextsourceorigins"]).length
        ? readProfileArray(step, ["stepContextSourceOrigins", "stepcontextsourceorigins"])
          .map((entry) => ({
            key: String(entry?.key || "").trim(),
            origin: String(entry?.origin || "").trim(),
            label: String(entry?.label || "").trim()
          }))
          .filter((entry) => entry.key)
        : []
    }))
    .filter((step) => step.name);
  if (!steps.length) return null;
  const profileKey = String(readProfileValue(parsed, ["profileKey", "profilekey"], "execution-profile")).trim() || "execution-profile";
  const profileName = String(readProfileValue(parsed, ["profileName", "profilename"], profileKey)).trim() || profileKey;
  const initialUserPrompt = extractPromptOriginalFromEnvelope(primaryText)
    || String(userMessages[0]?.content || "").trim()
    || "";
  return { profileKey, profileName, steps, initialUserPrompt };
}

function parseExecProfileStateMessage(content) {
  const raw = String(content || "");
  if (!raw.includes(EXEC_PROFILE_STATE_TAG)) return null;
  const jsonPart = raw.slice(raw.indexOf(EXEC_PROFILE_STATE_TAG) + EXEC_PROFILE_STATE_TAG.length).trim();
  if (!jsonPart) return null;
  try {
    return JSON.parse(jsonPart);
  } catch (_error) {
    return null;
  }
}

function parseExecProfileResumeMessage(content) {
  const raw = String(content || "");
  if (!raw.includes(EXEC_PROFILE_RESUME_TAG)) return null;
  const jsonPart = raw.slice(raw.indexOf(EXEC_PROFILE_RESUME_TAG) + EXEC_PROFILE_RESUME_TAG.length).trim();
  if (!jsonPart) return null;
  try {
    return JSON.parse(jsonPart);
  } catch (_error) {
    return null;
  }
}

function findLatestExecProfileState(taskPayload, profileKey) {
  const messages = Array.isArray(taskPayload?.messages) ? taskPayload.messages : [];
  for (let idx = messages.length - 1; idx >= 0; idx -= 1) {
    const entry = messages[idx];
    if (String(entry?.role || "").toLowerCase() !== "system") continue;
    const parsed = parseExecProfileStateMessage(entry?.content);
    if (!parsed) continue;
    if (profileKey && String(parsed.profileKey || "").trim() !== String(profileKey || "").trim()) continue;
    return { state: parsed, messageIndex: idx };
  }
  return null;
}

function findLatestExecProfileResume(taskPayload, profileKey, minIndexExclusive = -1) {
  const messages = Array.isArray(taskPayload?.messages) ? taskPayload.messages : [];
  for (let idx = messages.length - 1; idx > minIndexExclusive; idx -= 1) {
    const entry = messages[idx];
    if (String(entry?.role || "").toLowerCase() !== "system") continue;
    const parsed = parseExecProfileResumeMessage(entry?.content);
    if (!parsed) continue;
    if (profileKey && String(parsed.profileKey || "").trim() && String(parsed.profileKey || "").trim() !== String(profileKey || "").trim()) {
      continue;
    }
    return { resume: parsed, messageIndex: idx };
  }
  return null;
}

function collectUserFeedbackAfterIndex(taskPayload, index) {
  const messages = Array.isArray(taskPayload?.messages) ? taskPayload.messages : [];
  const start = Number.isFinite(index) ? index + 1 : 0;
  return messages
    .slice(start)
    .filter((entry) => String(entry?.role || "").toLowerCase() === "user")
    .map((entry) => String(entry?.content || "").trim())
    .filter(Boolean)
    .join("\n\n");
}

function mapStepProviderToRuntime(stepProviderRaw, baseRuntimeConfig) {
  const provider = String(stepProviderRaw || "ALL").trim().toUpperCase();
  if (provider === "ALL") return { ...baseRuntimeConfig };
  if (provider === "LMSTUDIO") {
    return { ...baseRuntimeConfig, provider: "LMSTUDIO", localProvider: "lmstudio" };
  }
  if (provider === "OLLAMA") {
    return { ...baseRuntimeConfig, provider: "OLLAMA", localProvider: "ollama" };
  }
  if (provider === "OPENAI" || provider === "ANTHROPIC") {
    return { ...baseRuntimeConfig, provider };
  }
  return { ...baseRuntimeConfig };
}

function dedupeStringList(values) {
  const seen = new Set();
  const result = [];
  for (const raw of Array.isArray(values) ? values : []) {
    const value = String(raw || "").trim();
    if (!value || seen.has(value)) continue;
    seen.add(value);
    result.push(value);
  }
  return result;
}

function decodeExecProfileDraftRelativePath(sourceKey) {
  const prefix = "exec-profile-draft:";
  const raw = String(sourceKey || "").trim();
  if (!raw.startsWith(prefix)) return "";
  return raw.slice(prefix.length).trim().replace(/^[/\\]+/, "");
}

function safeJoinProjectRelativePath(projectPath, relativePath) {
  const normalizedProject = path.resolve(String(projectPath || ""));
  const candidate = path.resolve(normalizedProject, relativePath);
  if (!candidate.startsWith(normalizedProject)) {
    return "";
  }
  return candidate;
}

function loadDraftSourceFromFile(projectPath, sourceKey) {
  const relative = decodeExecProfileDraftRelativePath(sourceKey);
  if (!relative) return null;
  const absolute = safeJoinProjectRelativePath(projectPath, relative);
  if (!absolute || !fs.existsSync(absolute) || !fs.statSync(absolute).isFile()) {
    return null;
  }
  const content = fs.readFileSync(absolute, "utf8");
  return {
    key: sourceKey,
    label: path.basename(absolute),
    origin: absolute,
    content,
    estimatedTokens: Math.ceil(String(content || "").length / 4)
  };
}

function resolveStepContextProjectId(taskPayload, step) {
  const explicit = String(step?.stepContextProjectId || "").trim();
  if (explicit) return explicit;
  const nestedTask = taskPayload?.task || {};
  const candidates = [
    nestedTask?.projectId,
    nestedTask?.project?.id,
    taskPayload?.projectId,
    taskPayload?.project?.id
  ];
  return dedupeStringList(candidates)[0] || "";
}

function buildStepProjectRuntimeContextBlock(projectId, selectedSources, selectedTokenEstimate) {
  const header = [
    "[STEP_PROJECT_CONTEXT_RUNTIME]",
    `project_id=${projectId || "-"}`,
    `selected_source_count=${selectedSources.length}`,
    `selected_tokens_estimate=${selectedTokenEstimate}`
  ];
  const body = selectedSources.flatMap((source, index) => {
    const key = String(source?.key || "").trim() || `source_${index + 1}`;
    const label = String(source?.label || key).trim();
    const origin = String(source?.origin || "-").trim();
    const estimatedTokens = Number(source?.estimatedTokens || 0);
    const content = String(source?.content || "").trim();
    return [
      `[SOURCE_BEGIN index=${index + 1} key="${key}" label="${label}" origin="${origin}" estimated_tokens=${estimatedTokens}]`,
      content || "(vacÃ­o)",
      "[SOURCE_END]"
    ];
  });
  return [...header, ...body, "[/STEP_PROJECT_CONTEXT_RUNTIME]"].join("\n");
}

function dedupeRuntimeContextSources(selectedSources) {
  const seenKeys = new Set();
  const seenContent = new Set();
  const deduped = [];
  for (const source of Array.isArray(selectedSources) ? selectedSources : []) {
    const key = String(source?.key || "").trim();
    const originalContent = String(source?.content || "").trim();
    const content = dedupeParagraphs(originalContent);
    const contentKey = normalizeComparableText(content);
    if (key && seenKeys.has(key)) continue;
    if (contentKey && seenContent.has(contentKey)) continue;
    if (key) seenKeys.add(key);
    if (contentKey) seenContent.add(contentKey);
    const originalEstimatedTokens = Number(source?.estimatedTokens || estimateTokenCountFromText(originalContent));
    const effectiveEstimatedTokens = estimateTokenCountFromText(content);
    deduped.push({
      ...source,
      content,
      estimatedTokens: effectiveEstimatedTokens,
      originalEstimatedTokens
    });
  }
  return deduped;
}

function summarizeRuntimeContextReduction(selectedSources, dedupedSources) {
  const rawSources = Array.isArray(selectedSources) ? selectedSources : [];
  const effectiveSources = Array.isArray(dedupedSources) ? dedupedSources : [];
  const rawSourceCount = rawSources.length;
  const effectiveSourceCount = effectiveSources.length;
  const rawTokens = rawSources.reduce(
    (acc, source) => acc + Number(source?.estimatedTokens || estimateTokenCountFromText(String(source?.content || ""))),
    0
  );
  const effectiveTokens = effectiveSources.reduce(
    (acc, source) => acc + Number(source?.estimatedTokens || estimateTokenCountFromText(String(source?.content || ""))),
    0
  );
  const savedTokens = Math.max(0, rawTokens - effectiveTokens);
  const savedPercent = rawTokens > 0 ? Math.round((savedTokens / rawTokens) * 10000) / 100 : 0;
  return {
    rawSourceCount,
    effectiveSourceCount,
    rawTokens,
    effectiveTokens,
    savedTokens,
    savedPercent,
  };
}

function shouldUseContextGraphRelevant(step) {
  const budget = Number(step?.contextBudgetTokens || 0);
  const graphQuery = String(step?.graphQuery || "").trim();
  return step?.useContextGraph === true || graphQuery.length > 0 || (Number.isFinite(budget) && budget > 0);
}

function resolveStepContextGraphQuery(taskPayload, step, originalUserPrompt = "") {
  const explicit = String(step?.graphQuery || "").trim();
  if (explicit) return explicit;
  return [
    String(step?.name || "").trim(),
    String(step?.description || "").trim(),
    String(step?.context || "").trim(),
    String(step?.initialPrompt || "").trim(),
    String(originalUserPrompt || "").trim(),
    String(taskPayload?.task?.title || "").trim(),
  ].filter(Boolean).join("\n").slice(0, 2400);
}

async function loadStepContextGraphRelevantRuntime(taskPayload, step, stepNumber, originalUserPrompt = "") {
  const projectId = resolveStepContextProjectId(taskPayload, step);
  if (!projectId) {
    return {
      block: "",
      projectId: "",
      selectedSourceCount: 0,
      selectedTokenEstimate: 0,
      mode: "context-graph-relevant",
      warning: "No se pudo resolver projectId para ContextGraph relevant."
    };
  }
  const taskId = String(taskPayload?.task?.id || "").trim();
  const budgetTokens = Number(step?.contextBudgetTokens || 0);
  const query = resolveStepContextGraphQuery(taskPayload, step, originalUserPrompt);
  const sourceKeys = dedupeStringList([
    ...(Array.isArray(step?.graphSourceKeys) ? step.graphSourceKeys : []),
    ...(Array.isArray(step?.stepContextSourceKeys) ? step.stepContextSourceKeys : [])
      .filter((key) => !String(key || "").startsWith("exec-profile-draft:"))
  ]);
  const params = new URLSearchParams();
  if (taskId) params.set("taskId", taskId);
  if (stepNumber) params.set("stepIndex", String(stepNumber));
  if (Number.isFinite(budgetTokens) && budgetTokens > 0) params.set("budgetTokens", String(Math.round(budgetTokens)));
  if (query) params.set("q", query);
  if (sourceKeys.length) params.set("sourceKeys", sourceKeys.join(","));
  if (!sourceKeys.length) params.set("excludeSourceKeyPrefixes", "execution-step-output:");
  const result = await request("GET", `/projects/${encodeURIComponent(projectId)}/context-graph/relevant?${params.toString()}`);
  const rawTokens = Number(result?.rawCandidateTokens || 0);
  const selectedTokens = Number(result?.selectedTokens || 0);
  const savedTokens = Number(result?.savedTokens || Math.max(0, rawTokens - selectedTokens));
  const savedPercent = Number(result?.savedPercent || (rawTokens > 0 ? Math.round((savedTokens / rawTokens) * 10000) / 100 : 0));
  return {
    block: String(result?.prompt || "").trim(),
    projectId,
    selectedSourceCount: Number(result?.selectedChunkCount || 0),
    selectedTokenEstimate: selectedTokens,
    mode: "context-graph-relevant",
    contextUnitLabel: "chunk(s)",
    budgetTokens: Number(result?.budgetTokens || budgetTokens || 0),
    selectedSourceKeys: Array.isArray(result?.selectedSourceKeys) ? result.selectedSourceKeys : [],
    graphRelevant: result,
    reduction: {
      rawSourceCount: Number(result?.candidateChunkCount || 0),
      effectiveSourceCount: Number(result?.selectedChunkCount || 0),
      rawTokens,
      effectiveTokens: selectedTokens,
      savedTokens,
      savedPercent,
      mode: "context-graph-relevant",
    },
    warning: selectedTokens > 0 ? "" : "ContextGraph relevant no devolvió chunks seleccionados."
  };
}

function buildExecutionStepOutputSourceKey(taskId, stepIndex) {
  const normalizedTaskId = String(taskId || "").trim();
  const normalizedStepIndex = Number(stepIndex || 0);
  if (!normalizedTaskId || !Number.isFinite(normalizedStepIndex) || normalizedStepIndex < 0) return "";
  return `execution-step-output:${normalizedTaskId}:${Math.floor(normalizedStepIndex)}`;
}

function shouldUsePreviousOutputGraphForStep(step, previousOutput) {
  const rawTokens = estimateTokenCountFromText(previousOutput || "");
  const explicitBudget = Number(step?.previousOutputBudgetTokens || 0);
  if (step?.usePreviousOutputGraph === true) return rawTokens > 0;
  if (Number.isFinite(explicitBudget) && explicitBudget > 0) return rawTokens > 0;
  if (step?.useContextGraph === true && rawTokens >= 1000) return true;
  return false;
}

function resolvePreviousOutputGraphQuery(taskPayload, step, previousOutput, originalUserPrompt = "") {
  const explicit = String(step?.previousOutputGraphQuery || "").trim();
  if (explicit) return explicit;
  return [
    String(step?.name || "").trim(),
    String(step?.description || "").trim(),
    String(step?.context || "").trim(),
    String(step?.initialPrompt || "").trim(),
    String(step?.graphQuery || "").trim(),
    String(originalUserPrompt || "").trim(),
    String(taskPayload?.task?.title || "").trim(),
    String(previousOutput || "").slice(0, 1200)
  ].filter(Boolean).join("\n").slice(0, 3000);
}

async function loadPreviousStepOutputGraphRelevantRuntime({
  taskPayload,
  step,
  stepIndex,
  previousOutput,
  originalUserPrompt
}) {
  const rawPreviousOutput = String(previousOutput || "").trim();
  const rawTokens = estimateTokenCountFromText(rawPreviousOutput);
  const taskId = String(taskPayload?.task?.id || "").trim();
  const projectId = resolveStepContextProjectId(taskPayload, step);
  const previousStepIndex = Number(stepIndex) - 1;
  const sourceKey = buildExecutionStepOutputSourceKey(taskId, previousStepIndex);
  if (!rawPreviousOutput || !taskId || !projectId || !sourceKey) {
    return {
      outputForPrompt: rawPreviousOutput,
      reduced: false,
      warning: ""
    };
  }
  const configuredBudget = Number(step?.previousOutputBudgetTokens || 0);
  const budgetTokens = Number.isFinite(configuredBudget) && configuredBudget > 0
    ? Math.round(configuredBudget)
    : 900;
  if (rawTokens > 0 && rawTokens <= Math.max(200, Math.round(budgetTokens * 1.15)) && step?.usePreviousOutputGraph !== true) {
    return {
      outputForPrompt: rawPreviousOutput,
      reduced: false,
      warning: ""
    };
  }
  const query = resolvePreviousOutputGraphQuery(taskPayload, step, rawPreviousOutput, originalUserPrompt);
  const params = new URLSearchParams();
  params.set("taskId", taskId);
  params.set("stepIndex", String(Number(stepIndex) + 1));
  params.set("budgetTokens", String(budgetTokens));
  params.set("sourceKeys", sourceKey);
  if (query) params.set("q", query);
  const result = await request("GET", `/projects/${encodeURIComponent(projectId)}/context-graph/relevant?${params.toString()}`);
  const prompt = String(result?.prompt || "").trim();
  const selectedTokens = Number(result?.selectedTokens || 0);
  if (!prompt || selectedTokens <= 0) {
    return {
      outputForPrompt: rawPreviousOutput,
      reduced: false,
      warning: `ContextGraph previous output no devolvió chunks para ${sourceKey}; se usa OUTPUT_STEP_ANTERIOR bruto.`
    };
  }
  const rawCandidateTokens = Number(result?.rawCandidateTokens || rawTokens);
  const effectiveTokens = selectedTokens;
  const savedTokens = Math.max(0, rawTokens - effectiveTokens);
  const savedPercent = rawTokens > 0 ? Math.round((savedTokens / rawTokens) * 10000) / 100 : 0;
  const outputForPrompt = [
    "[OUTPUT_STEP_ANTERIOR_RELEVANTE]",
    `source_key=${sourceKey}`,
    `raw_previous_output_tokens=${rawTokens}`,
    `raw_candidate_tokens=${rawCandidateTokens}`,
    `selected_tokens=${effectiveTokens}`,
    `saved_tokens=${savedTokens}`,
    `saved_percent=${savedPercent}`,
    prompt,
    "[/OUTPUT_STEP_ANTERIOR_RELEVANTE]"
  ].join("\n");
  return {
    outputForPrompt,
    reduced: true,
    sourceKey,
    budgetTokens,
    rawTokens,
    rawCandidateTokens,
    effectiveTokens,
    savedTokens,
    savedPercent,
    selectedSourceKeys: Array.isArray(result?.selectedSourceKeys) ? result.selectedSourceKeys : [],
    selectedChunkCount: Number(result?.selectedChunkCount || 0),
    candidateChunkCount: Number(result?.candidateChunkCount || 0),
    result
  };
}

async function storeExecutionProfileStepOutputInContextGraph({
  taskPayload,
  profileConfig,
  step,
  stepIndex,
  stepNumber,
  outputText,
  engine
}) {
  const taskId = String(taskPayload?.task?.id || "").trim();
  const projectId = resolveStepContextProjectId(taskPayload, step);
  const output = String(outputText || "").trim();
  if (!taskId || !projectId || !output) return null;
  const memoryOutput = compactSuccessfulGradleOutputForMemory(output);
  return request("POST", `/projects/${encodeURIComponent(projectId)}/context-graph/sources/execution-step-output`, {
    body: {
      taskId,
      profileKey: profileConfig?.profileKey || "execution-profile",
      profileName: profileConfig?.profileName || profileConfig?.profileKey || "execution-profile",
      stepIndex,
      stepNumber,
      stepName: step?.name || `Step ${stepNumber}`,
      engine: engine || step?.agentEngine || null,
      provider: step?.modelProvider || null,
      model: step?.model || null,
      output: memoryOutput
    }
  });
}

async function loadStepProjectContextRuntime(taskPayload, step, stepNumber = 0, originalUserPrompt = "") {
  if (shouldUseContextGraphRelevant(step)) {
    try {
      const graphRuntime = await loadStepContextGraphRelevantRuntime(taskPayload, step, stepNumber, originalUserPrompt);
      const selectedKeys = dedupeStringList(step?.stepContextSourceKeys || []);
      if (graphRuntime.selectedTokenEstimate > 0 || !selectedKeys.length) {
        return graphRuntime;
      }
      console.warn("[agent] ContextGraph relevant returned no chunks; falling back to stepContextSourceKeys");
    } catch (error) {
      const selectedKeys = dedupeStringList(step?.stepContextSourceKeys || []);
      if (!selectedKeys.length) {
        return {
          block: "",
          projectId: resolveStepContextProjectId(taskPayload, step),
          selectedSourceCount: 0,
          selectedTokenEstimate: 0,
          mode: "context-graph-relevant",
          warning: `Error cargando ContextGraph relevant: ${String(error?.message || error)}`
        };
      }
      console.warn(`[agent] ContextGraph relevant failed; falling back to stepContextSourceKeys: ${String(error?.message || error)}`);
    }
  }
  const selectedKeys = dedupeStringList(step?.stepContextSourceKeys || []);
  if (!selectedKeys.length) {
    return { block: "", projectId: "", selectedSourceCount: 0, selectedTokenEstimate: 0, warning: "" };
  }
  const projectPath = requireProjectPath(taskPayload);
  const projectId = resolveStepContextProjectId(taskPayload, step);
  if (!projectId && !selectedKeys.some((key) => key.startsWith("exec-profile-draft:"))) {
    return {
      block: "",
      projectId: "",
      selectedSourceCount: 0,
      selectedTokenEstimate: 0,
      warning: "No se pudo resolver projectId para contexto runtime del step."
    };
  }
  const draftSources = selectedKeys
    .filter((key) => key.startsWith("exec-profile-draft:"))
    .map((key) => loadDraftSourceFromFile(projectPath, key))
    .filter(Boolean);
  const nonDraftKeys = selectedKeys.filter((key) => !key.startsWith("exec-profile-draft:"));
  try {
    const selectedSources = [];
    if (nonDraftKeys.length) {
      if (!projectId) {
        return {
          block: "",
          projectId: "",
          selectedSourceCount: 0,
          selectedTokenEstimate: 0,
          warning: "Hay fuentes no-draft pero no se pudo resolver projectId del step."
        };
      }
      const payload = await request("GET", `/projects/${encodeURIComponent(projectId)}/agent-context?forNewTask=true&maxMessages=120`);
      const sources = Array.isArray(payload?.sources) ? payload.sources : [];
      const sourceByKey = new Map(sources.map((source) => [String(source?.key || "").trim(), source]));
      selectedSources.push(...nonDraftKeys.map((key) => sourceByKey.get(key)).filter(Boolean));
    }
    selectedSources.push(...draftSources);
    const dedupedSources = dedupeRuntimeContextSources(selectedSources);
    const reduction = summarizeRuntimeContextReduction(selectedSources, dedupedSources);
    if (!dedupedSources.length) {
      return {
        block: "",
        projectId,
        selectedSourceCount: 0,
        selectedTokenEstimate: 0,
        reduction,
        warning: `No se encontraron fuentes para stepContextSourceKeys (${selectedKeys.join(", ")}).`
      };
    }
    const selectedTokenEstimate = dedupedSources.reduce(
      (acc, source) => acc + Number(source?.estimatedTokens || Math.ceil(String(source?.content || "").length / 4)),
      0
    );
    return {
      block: buildStepProjectRuntimeContextBlock(projectId, dedupedSources, selectedTokenEstimate),
      projectId,
      selectedSourceCount: dedupedSources.length,
      selectedTokenEstimate,
      reduction,
      warning: ""
    };
  } catch (error) {
    return {
      block: "",
      projectId,
      selectedSourceCount: 0,
      selectedTokenEstimate: 0,
      reduction: null,
      warning: `Error cargando contexto runtime: ${String(error?.message || error)}`
    };
  }
}

function buildExecutionProfileStepPrompt({
  basePrompt,
  profileConfig,
  step,
  stepNumber,
  totalSteps,
  originalUserPrompt,
  previousOutput,
  hitlFeedback,
  runtimeProjectContextBlock,
  llmRuntimeConfig
}) {
  const provider = String(llmRuntimeConfig?.provider || "").trim().toUpperCase();
  const shouldCompactForLocal = isLocalOssProvider(provider);
  const replacedContext = String(step.context || "")
    .replaceAll("{{INPUT_USUARIO_ORIGINAL}}", originalUserPrompt || "")
    .replaceAll("{{OUTPUT_STEP_ANTERIOR}}", previousOutput || "");
  const compactedOriginalPrompt = shouldCompactForLocal
    ? dedupeParagraphs(applyTarzanSpanishCompression(originalUserPrompt || ""))
    : String(originalUserPrompt || "").trim();
  const isPreviousOutputGraphBlock = String(previousOutput || "").includes("[OUTPUT_STEP_ANTERIOR_RELEVANTE]")
    || String(previousOutput || "").includes("[CONTEXT_GRAPH_RELEVANT]");
  const compactedPreviousOutput = shouldCompactForLocal
    ? clipText(
      isPreviousOutputGraphBlock
        ? dedupeParagraphs(String(previousOutput || "").trim())
        : dedupeParagraphs(String(previousOutput || "").trim()),
      isPreviousOutputGraphBlock ? 6000 : 1800
    )
    : String(previousOutput || "").trim();
  const compactedFeedback = shouldCompactForLocal
    ? clipText(dedupeParagraphs(applyTarzanSpanishCompression(hitlFeedback || "")), 1200)
    : String(hitlFeedback || "").trim();
  const compactedStepContext = shouldCompactForLocal
    ? dedupeParagraphs(applyTarzanSpanishCompression(replacedContext || ""))
    : String(replacedContext || "").trim();
  const isContextGraphRelevantBlock = String(runtimeProjectContextBlock || "").includes("[CONTEXT_GRAPH_RELEVANT]");
  const compactedRuntimeProjectContext = shouldCompactForLocal
    ? clipText(
      isContextGraphRelevantBlock
        ? dedupeParagraphs(String(runtimeProjectContextBlock || "").trim())
        : dedupeParagraphs(applyTarzanSpanishCompression(runtimeProjectContextBlock || "")),
      isContextGraphRelevantBlock ? 6000 : 1800
    )
    : String(runtimeProjectContextBlock || "").trim();
  const executionGuardrails = [
    "Reglas de ejecución del step:",
    "- Evita bucles de herramientas/comandos.",
    "- Ejecuta como máximo una ronda de test/build por step, salvo tareas Android Compose/Kotlin/Room donde debes aplicar la regla especial de assembleDebug/APK con hasta 2 reintentos de correccion.",
    "- Si un comando falla o bloquea, resume el error y termina con salida accionable.",
    "- Entrega SIEMPRE un resultado final claro para el siguiente step."
  ];
  const instructions = [
    basePrompt,
    "",
    "[EXECUTION_PROFILE_RUNTIME]",
    `Perfil: ${profileConfig.profileName} (${profileConfig.profileKey})`,
    `Step ${stepNumber}/${totalSteps}: ${step.name}`,
    `Engine: ${step.agentEngine}`,
    `Model provider: ${step.modelProvider || "ALL"}`,
    `Model: ${step.model || "-"}`,
    `Reasoning effort: ${step.reasoningEffort || "runtime-default"}`,
    "",
    "Variables runtime:",
    `INPUT_USUARIO_ORIGINAL:\n${compactedOriginalPrompt || "(vacío)"}`,
    "",
    `OUTPUT_STEP_ANTERIOR:\n${compactedPreviousOutput || "(sin output previo)"}`,
    "",
    `FEEDBACK_HITL_USUARIO:\n${compactedFeedback || "(sin feedback adicional)"}`,
    "",
    `CONTEXTO_STEP:\n${compactedStepContext || "(sin contexto step)"}`,
    "",
    `CONTEXTO_PROYECTO_STEP_RUNTIME:\n${compactedRuntimeProjectContext || "(sin fuentes de proyecto seleccionadas para este step)"}`,
    "",
    `INSTRUCCION_INICIAL_STEP:\n${step.initialPrompt || "(seguir objetivo general)"}`,
    "",
    executionGuardrails.join("\n"),
    "",
    "Debes ejecutar SOLO este step y devolver resultado accionable para el siguiente step."
  ];
  return instructions.join("\n");
}
async function terminateChildProcessTree(child, options = {}) {
  if (!child) return { verified: true, reason: "no-child" };
  const pid = Number(child.pid || 0);
  if (!pid) return { verified: true, reason: "no-pid" };
  const platform = options.platform || process.platform;
  const spawnProcess = options.spawnProcess || spawn;

  if (platform === "win32") {
    const result = await new Promise((resolve) => {
      let settled = false;
      let timer = null;
      const finish = (payload) => {
        if (settled) return;
        settled = true;
        if (timer) clearTimeout(timer);
        resolve(payload);
      };
      let killer;
      try {
        // Kill the Windows tree before touching the cmd.exe wrapper. Killing the wrapper first
        // makes taskkill lose the parent it needs to discover Codex descendants.
        killer = spawnProcess(resolveWindowsSystemExecutable("taskkill.exe"), ["/PID", String(pid), "/T", "/F"], {
          windowsHide: true,
          stdio: ["ignore", "pipe", "pipe"],
        });
      } catch (error) {
        resolve({ verified: false, reason: error.message || String(error) });
        return;
      }
      let stdout = "";
      let stderr = "";
      killer.stdout?.on("data", (chunk) => { stdout += chunk.toString(); });
      killer.stderr?.on("data", (chunk) => { stderr += chunk.toString(); });
      killer.on("error", (error) => finish({ verified: false, reason: error.message || String(error) }));
      killer.on("close", (code) => finish({
        verified: code === 0,
        code,
        reason: code === 0 ? "taskkill-tree" : clipText(`${stderr}\n${stdout}`.trim(), 800) || `taskkill exited ${code}`,
      }));
      timer = setTimeout(() => {
        try { killer.kill("SIGKILL"); } catch (_ignored) {}
        finish({ verified: false, reason: "taskkill verification timed out" });
      }, Math.max(5_000, PROCESS_FORCE_KILL_GRACE_MS));
    });
    try {
      child.kill("SIGKILL");
    } catch (_ignored) {}
    return result;
  }

  let verified = false;
  let reason = "";
  try {
    process.kill(-pid, "SIGKILL");
    verified = true;
    reason = "process-group-killed";
  } catch (error) {
    reason = error.message || String(error);
  }
  if (!verified) {
    try {
      child.kill("SIGKILL");
      verified = true;
      reason = "child-killed";
    } catch (error) {
      reason = `${reason}; ${error.message || String(error)}`;
    }
  }
  return { verified, reason };
}

async function request(method, endpoint, options = {}) {
  const url = `${BASE_URL}${endpoint}`;
  const maxAttempts = Math.max(2, AGENT_AUTH_ACCOUNTS.length + 1);

  for (let attempt = 1; attempt <= maxAttempts; attempt += 1) {
    const init = {
      method,
      headers: options.headers || headers(),
    };

    if (options.body !== undefined) {
      const sanitizedBody = sanitizeTransportValue(options.body);
      init.body = JSON.stringify(sanitizedBody);
      init.headers = {
        "Content-Type": "application/json",
        ...init.headers,
      };
    }

    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), HTTP_REQUEST_TIMEOUT_MS);
      const response = await fetch(url, { ...init, signal: controller.signal }).finally(() => clearTimeout(timeout));
      if (response.status === 204) {
        return null;
      }

      if (!response.ok) {
        const text = await response.text();
        const authRetry = (response.status === 401 || response.status === 403) && rotateAgentAuthAccount();
        if (authRetry) {
          const account = currentAgentAuthAccount();
          console.warn(
            `[agent] auth token rotated after ${method} ${endpoint} returned ${response.status}. now using ${account?.label || "unknown"}`
          );
          continue;
        }
        throw new Error(`${method} ${endpoint} failed (${response.status}): ${text}`);
      }

      const contentType = response.headers.get("content-type") || "";
      if (!contentType.includes("application/json")) {
        return null;
      }
      return response.json();
    } catch (error) {
      if (error?.name === "AbortError") {
        const timeoutError = new Error(`${method} ${endpoint} timed out after ${HTTP_REQUEST_TIMEOUT_MS}ms`);
        timeoutError.cause = { code: "ETIMEDOUT" };
        throw timeoutError;
      }
      const canRecover = attempt < maxAttempts && isLikelyBackendNetworkError(error);
      if (canRecover) {
        const recovered = await maybeRecoverBackend(`${method} ${endpoint}`, error);
        if (recovered) {
          continue;
        }
      }
      throw error;
    }
  }

  return null;
}

async function uploadMultipartFile(endpoint, fieldName, sourcePath, contentType) {
  const resolvedPath = path.resolve(String(sourcePath || "").trim());
  if (!fs.existsSync(resolvedPath) || !fs.statSync(resolvedPath).isFile()) {
    throw new Error(`Artifact source does not exist or is not a file: ${resolvedPath}`);
  }

  const bytes = fs.readFileSync(resolvedPath);
  const form = new FormData();
  form.append(
    fieldName,
    new Blob([bytes], { type: contentType || "application/octet-stream" }),
    path.basename(resolvedPath)
  );

  const endpointUrl = `${BASE_URL}${endpoint}`;
  const maxAttempts = Math.max(2, AGENT_AUTH_ACCOUNTS.length + 1);
  for (let attempt = 1; attempt <= maxAttempts; attempt += 1) {
    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), ARTIFACT_UPLOAD_TIMEOUT_MS);
      const response = await fetch(endpointUrl, {
        method: "POST",
        headers: headers(),
        body: form,
        signal: controller.signal,
      }).finally(() => clearTimeout(timeout));

      if (!response.ok) {
        const text = await response.text();
        const authRetry = (response.status === 401 || response.status === 403) && rotateAgentAuthAccount();
        if (authRetry) {
          const account = currentAgentAuthAccount();
          console.warn(
            `[agent] auth token rotated after artifact upload returned ${response.status}. now using ${account?.label || "unknown"}`
          );
          continue;
        }
        throw new Error(`POST ${endpoint} failed (${response.status}): ${text}`);
      }

      const responseContentType = response.headers.get("content-type") || "";
      return responseContentType.includes("application/json") ? response.json() : null;
    } catch (error) {
      if (error?.name === "AbortError") {
        const timeoutError = new Error(`POST ${endpoint} timed out after ${ARTIFACT_UPLOAD_TIMEOUT_MS}ms`);
        timeoutError.cause = { code: "ETIMEDOUT" };
        throw timeoutError;
      }
      const canRecover = attempt < maxAttempts && isLikelyBackendNetworkError(error);
      if (canRecover && await maybeRecoverBackend(`POST ${endpoint}`, error)) {
        continue;
      }
      throw error;
    }
  }
  return null;
}

function isLikelyBackendNetworkError(error) {
  if (!error) {
    return false;
  }

  const raw = String(error.message || error).toLowerCase();
  if (
    raw.includes("fetch failed")
    || raw.includes("econnrefused")
    || raw.includes("econnreset")
    || raw.includes("socket hang up")
    || raw.includes("etimedout")
    || raw.includes("enotfound")
    || raw.includes("eai_again")
    || raw.includes("network")
  ) {
    return true;
  }

  const causeCode = String(error.cause?.code || "").toLowerCase();
  return [
    "econnrefused",
    "econnreset",
    "etimedout",
    "enotfound",
    "eai_again",
  ].includes(causeCode);
}

function isLocalBackendUrl() {
  try {
    const hostname = new URL(BASE_URL).hostname.toLowerCase();
    return hostname === "localhost" || hostname === "127.0.0.1" || hostname === "::1";
  } catch (_ignored) {
    return false;
  }
}

function buildBackendProbeUrl() {
  const trimmedPath = BACKEND_HEALTH_PATH.trim();
  if (/^https?:\/\//i.test(trimmedPath)) {
    return trimmedPath;
  }
  const base = BASE_URL.endsWith("/") ? BASE_URL : `${BASE_URL}/`;
  const relative = trimmedPath.replace(/^\//, "");
  return new URL(relative, base).toString();
}

async function isBackendReachable() {
  const controller = new AbortController();
  const timeoutHandle = setTimeout(() => controller.abort(), BACKEND_PROBE_TIMEOUT_MS);

  try {
    await fetch(buildBackendProbeUrl(), {
      method: "GET",
      signal: controller.signal,
      headers: headers(),
    });
    return true;
  } catch (_error) {
    return false;
  } finally {
    clearTimeout(timeoutHandle);
  }
}

async function waitUntilBackendReachable(waitMs) {
  const deadline = Date.now() + waitMs;
  while (Date.now() < deadline) {
    if (await isBackendReachable()) {
      return true;
    }
    await sleep(1500);
  }
  return false;
}

async function restartBackendIfNeeded(contextLabel) {
  if (!BACKEND_AUTORESTART_ENABLED) {
    return false;
  }
  if (BACKEND_RESTART_ONLY_LOCAL && !isLocalBackendUrl()) {
    return false;
  }
  if (!BACKEND_RESTART_COMMAND) {
    console.warn("[agent][backend-watchdog] restart skipped: JARVIS_BACKEND_RESTART_COMMAND is empty");
    return false;
  }

  const now = Date.now();
  if (backendRestartInFlight) {
    return backendRestartInFlight;
  }
  if (now - backendLastRestartAt < BACKEND_RESTART_COOLDOWN_MS) {
    return false;
  }

  const alreadyUp = await isBackendReachable();
  if (alreadyUp) {
    return false;
  }

  backendLastRestartAt = now;
  backendRestartInFlight = (async () => {
    console.warn(
      `[agent][backend-watchdog] backend down during ${contextLabel}. launching restart command: ${BACKEND_RESTART_COMMAND}`
    );
    try {
      const restartCommand = buildShellCommand(BACKEND_RESTART_COMMAND);
      const launcher = spawn(restartCommand.command, restartCommand.args, {
        cwd: __dirname,
        detached: true,
        stdio: "ignore",
      });
      launcher.unref();

      const recovered = await waitUntilBackendReachable(BACKEND_RESTART_WAIT_MS);
      if (recovered) {
        console.warn("[agent][backend-watchdog] backend reachable again.");
      } else {
        console.warn("[agent][backend-watchdog] backend still unreachable after restart attempt.");
      }
      return recovered;
    } catch (error) {
      console.warn(`[agent][backend-watchdog] restart attempt failed: ${error.message}`);
      return false;
    } finally {
      backendRestartInFlight = null;
    }
  })();

  return backendRestartInFlight;
}

async function maybeRecoverBackend(contextLabel, error) {
  if (!isLikelyBackendNetworkError(error)) {
    return false;
  }
  return restartBackendIfNeeded(contextLabel);
}

async function claimNextTask() {
  return request("POST", "/tasks/next", {
    headers: headers({ "X-Agent-Id": AGENT_ID }),
  });
}

function parseWorkspaceEnvList(raw) {
  return String(raw || "")
    .split(/[;,]/)
    .map((value) => value.trim())
    .filter(Boolean)
    .map((value) => path.resolve(value));
}

function looksLikeProjectDirectory(dirPath) {
  try {
    if (!fs.existsSync(dirPath)) return false;
    const stats = fs.statSync(dirPath);
    if (!stats.isDirectory()) return false;
    return fs.existsSync(path.join(dirPath, ".git"))
      || fs.existsSync(path.join(dirPath, "agent.md"))
      || fs.existsSync(path.join(dirPath, "package.json"))
      || fs.existsSync(path.join(dirPath, "build.gradle"))
      || fs.existsSync(path.join(dirPath, "build.gradle.kts"))
      || fs.existsSync(path.join(dirPath, "pom.xml"));
  } catch (_error) {
    return false;
  }
}

function discoverWorkspaceCandidates() {
  const directPaths = parseWorkspaceEnvList(WORKSPACE_PATHS);
  const rootPaths = parseWorkspaceEnvList(WORKSPACE_ROOTS);
  const discovered = new Set();

  for (const directPath of directPaths) {
    discovered.add(path.resolve(directPath));
  }

  function scanRoot(rootPath, depth = 0) {
    if (depth > WORKSPACE_SCAN_DEPTH) return;
    let entries;
    try {
      entries = fs.readdirSync(rootPath, { withFileTypes: true });
    } catch (_error) {
      return;
    }

    for (const entry of entries) {
      if (!entry.isDirectory()) continue;
      if (entry.name === ".git" || entry.name === "node_modules" || entry.name === "build" || entry.name.startsWith(".")) {
        continue;
      }
      const fullPath = path.join(rootPath, entry.name);
      if (looksLikeProjectDirectory(fullPath)) {
        discovered.add(path.resolve(fullPath));
      }
      scanRoot(fullPath, depth + 1);
    }
  }

  for (const root of rootPaths) {
    scanRoot(path.resolve(root), 0);
  }

  if (discovered.size === 0 && looksLikeProjectDirectory(path.resolve(__dirname, ".."))) {
    discovered.add(path.resolve(__dirname, ".."));
  }

  return Array.from(discovered);
}

async function resolveWorkspaceGitInfo(workspacePath) {
  const remoteResult = await runExecutableCommand({
    executable: "git",
    args: ["-C", workspacePath, "remote", "get-url", "origin"],
    timeoutMs: 10_000,
  });
  const branchResult = await runExecutableCommand({
    executable: "git",
    args: ["-C", workspacePath, "rev-parse", "--abbrev-ref", "HEAD"],
    timeoutMs: 10_000,
  });

  const worktreeResult = await runExecutableCommand({
    executable: "git",
    args: ["-C", workspacePath, "worktree", "list", "--porcelain"],
    timeoutMs: 10_000,
  });
  const expectedWorktreePath = path.resolve(
    path.dirname(workspacePath),
    path.basename(workspacePath).toLowerCase().endsWith("-jarvis")
      ? path.basename(workspacePath)
      : `${path.basename(workspacePath)}-jarvis`
  );
  const reportedWorktrees = worktreeResult.code === 0
    ? String(worktreeResult.stdout || "")
        .split(/\r?\n/)
        .filter((line) => line.startsWith("worktree "))
        .map((line) => path.resolve(line.slice("worktree ".length).trim()))
    : [];
  const worktreePath = reportedWorktrees.find((candidate) =>
    process.platform === "win32"
      ? candidate.toLowerCase() === expectedWorktreePath.toLowerCase()
      : candidate === expectedWorktreePath
  ) || null;

  return {
    gitRemoteUrl: remoteResult.code === 0 ? String(remoteResult.stdout || "").trim() || null : null,
    gitBranch: branchResult.code === 0 ? String(branchResult.stdout || "").trim() || null : null,
    worktreePath,
  };
}

async function collectWorkspacePayload() {
  const candidates = discoverWorkspaceCandidates();
  const workspaces = [];

  for (const workspacePath of candidates) {
    const absolutePath = path.resolve(workspacePath);
    const exists = fs.existsSync(absolutePath);
    if (!exists) {
      workspaces.push({
        name: path.basename(absolutePath) || absolutePath,
        absolutePath,
        os: process.platform,
        exists: false,
        worktreePath: null,
        gitRemoteUrl: null,
        gitBranch: null,
      });
      continue;
    }

    const gitInfo = await resolveWorkspaceGitInfo(absolutePath);
    workspaces.push({
      name: path.basename(absolutePath) || absolutePath,
      absolutePath,
      os: process.platform,
      exists: true,
      worktreePath: gitInfo.worktreePath,
      gitRemoteUrl: gitInfo.gitRemoteUrl,
      gitBranch: gitInfo.gitBranch,
    });
  }

  return workspaces;
}

async function syncAgentWorkspaces() {
  if (workspaceSyncInFlight) return workspaceSyncInFlight;
  workspaceSyncInFlight = (async () => {
    try {
      const workspaces = await collectWorkspacePayload();
      await reportAgentWorkspaces(workspaces);
      return workspaces.length;
    } finally {
      workspaceSyncInFlight = null;
    }
  })();
  return workspaceSyncInFlight;
}

async function bootstrapAgentDevice() {
  return request("POST", "/agents/bootstrap", {
    body: {
      ownerUserId: OWNER_USER_ID || null,
      pairingCode: AGENT_PAIRING_CODE || null,
      agentId: AGENT_ID,
      displayName: AGENT_DISPLAY_NAME || AGENT_ID,
      hostname: os.hostname(),
      os: process.platform,
      arch: process.arch,
      version: `${AGENT_RELEASE_VERSION} (node ${process.version})`,
      fingerprint: `${os.hostname()}::${process.platform}::${process.arch}`,
    },
  });
}

async function getRegisteredAgentConfig() {
  return request("GET", "/agents/me/config", {
    headers: headers({ "X-Agent-Id": AGENT_ID }),
  });
}

async function bootstrapAgentDeviceWithRetry() {
  let lastError = null;
  for (let attempt = 1; attempt <= AGENT_BOOTSTRAP_MAX_ATTEMPTS; attempt += 1) {
    try {
      const bootstrap = await bootstrapAgentDevice();
      const returnedAgentId = String(bootstrap?.agent?.agentId || "").trim();
      const returnedDeviceId = String(bootstrap?.agent?.id || "").trim();
      if (returnedAgentId !== AGENT_ID) {
        throw new Error(`Bootstrap agent id mismatch: requested=${AGENT_ID} returned=${returnedAgentId || "missing"}`);
      }
      if (!returnedDeviceId) {
        throw new Error("Bootstrap response missing internal agent device id");
      }

      const config = await getRegisteredAgentConfig();
      const configuredAgentId = String(config?.agent?.agentId || "").trim();
      const configuredDeviceId = String(config?.agent?.id || "").trim();
      if (configuredAgentId !== AGENT_ID || configuredDeviceId !== returnedDeviceId) {
        throw new Error(
          `Backend registration verification mismatch: requested=${AGENT_ID} configured=${configuredAgentId || "missing"} device=${configuredDeviceId || "missing"}`
        );
      }
      return bootstrap;
    } catch (error) {
      lastError = error;
      console.warn(`[agent] bootstrap attempt ${attempt}/${AGENT_BOOTSTRAP_MAX_ATTEMPTS} failed: ${error.message}`);
      if (attempt < AGENT_BOOTSTRAP_MAX_ATTEMPTS) {
        await sleep(AGENT_BOOTSTRAP_RETRY_MS * attempt);
      }
    }
  }
  throw new Error(
    `Agent registration failed after ${AGENT_BOOTSTRAP_MAX_ATTEMPTS} attempts; workspace sync was not started: ${lastError?.message || "unknown error"}`
  );
}

async function sendAgentHeartbeat(taskId = null) {
  return request("POST", "/agents/heartbeat", {
    body: {
      agentId: AGENT_ID,
      taskId: taskId || null,
    },
  });
}

async function reportAgentWorkspaces(workspaces) {
  return request("POST", "/agents/me/workspaces", {
    body: {
      ownerUserId: OWNER_USER_ID || null,
      agentId: AGENT_ID,
      workspaces,
    },
  });
}

async function claimHeartbeat(taskId) {
  return request("POST", `/tasks/${taskId}/claim-heartbeat`, {
    headers: headers({ "X-Agent-Id": AGENT_ID }),
  });
}

async function addMessage(taskId, role, content) {
  return request("POST", `/tasks/${taskId}/messages`, {
    body: { role, content },
  });
}

async function recordUsageEvent(taskId, event) {
  if (!taskId || !event) return null;
  return request("POST", `/tasks/${encodeURIComponent(taskId)}/usage-events`, {
    body: event,
  });
}

async function updateStatus(taskId, status, lastError = null) {
  return request("POST", `/tasks/${taskId}/status`, {
    body: { status, lastError },
  });
}

async function uploadApk(taskId, sourcePath) {
  return uploadMultipartFile(
    `/tasks/${encodeURIComponent(taskId)}/artifacts/apk/upload`,
    "file",
    sourcePath,
    "application/vnd.android.package-archive"
  );
}

async function uploadAgentLog(taskId, sourcePath) {
  return request("POST", `/tasks/${taskId}/artifacts/agent-log`, {
    body: { sourcePath },
  });
}

async function uploadRuntimeLogSnapshot(taskId, content) {
  return request("PUT", `/tasks/${encodeURIComponent(taskId)}/runtime-log`, {
    headers: headers({ "X-Agent-Id": AGENT_ID }),
    body: {
      content: String(content || ""),
      capturedAt: new Date().toISOString(),
    },
  });
}

async function claimNextAgentCommand() {
  return request("POST", "/agent-commands/next", {
    headers: headers({ "X-Agent-Id": AGENT_ID }),
  });
}

async function completeAgentCommand(commandId, success, summary = null, lastError = null) {
  return request("POST", `/agent-commands/${commandId}/complete`, {
    headers: headers({ "X-Agent-Id": AGENT_ID }),
    body: { success, summary, lastError },
  });
}

async function getLlmRuntimeConfigForAgent() {
  return request("GET", "/runtime/llm/runtime");
}

async function getClaudeRuntimeConfigForAgent() {
  return request("GET", "/runtime/integrations/claude/runtime");
}

function normalizeLlmRuntimeConfig(rawConfig) {
  const provider = String(rawConfig?.provider || "OPENAI").trim().toUpperCase();
  const model = String(rawConfig?.model || "").trim();
  const localProvider = String(rawConfig?.localProvider || "").trim().toLowerCase() || null;
  const modelContextWindowRaw = parseInt(rawConfig?.modelContextWindow, 10);
  const ollamaContextMinRaw = parseInt(rawConfig?.ollamaContextMin, 10);
  const ollamaContextMaxRaw = parseInt(rawConfig?.ollamaContextMax, 10);
  const min = Number.isFinite(ollamaContextMinRaw) ? Math.max(1024, ollamaContextMinRaw) : 8192;
  const max = Number.isFinite(ollamaContextMaxRaw) ? Math.max(min, ollamaContextMaxRaw) : 32768;
  const modelContextWindow = Number.isFinite(modelContextWindowRaw)
    ? Math.max(min, Math.min(modelContextWindowRaw, max))
    : null;

  return {
    provider,
    model,
    reasoningEffort: normalizeReasoningEffort(rawConfig?.reasoningEffort),
    localProvider,
    modelContextWindow,
    ollamaContextMin: min,
    ollamaContextMax: max,
  };
}

function normalizeReasoningEffort(raw) {
  const value = String(raw || "").trim().toLowerCase();
  return ["none", "minimal", "low", "medium", "high", "xhigh", "max", "ultra"].includes(value) ? value : "";
}

function isLocalOssProvider(provider) {
  const normalized = String(provider || "").trim().toUpperCase();
  return ["OLLAMA", "LMSTUDIO", "LLAMA_CPP"].includes(normalized);
}

function resolveLocalOssProvider(provider, explicitLocalProvider = null) {
  const explicit = String(explicitLocalProvider || "").trim().toLowerCase();
  if (explicit) {
    return explicit;
  }

  const normalized = String(provider || "").trim().toUpperCase();
  if (normalized === "LMSTUDIO") {
    return "lmstudio";
  }
  if (normalized === "LLAMA_CPP") {
    return "llama_cpp";
  }
  return "ollama";
}

function normalizeOllamaBaseUrl(rawBase) {
  const base = String(rawBase || "").trim();
  if (!base) return "http://localhost:11434/v1";
  if (base.match(/\/v1\/?$/i)) return base.replace(/\/+$/, "");
  if (base.match(/\/api\/?$/i)) return `${base.replace(/\/api\/?$/i, "")}/v1`;
  return `${base.replace(/\/+$/, "")}/v1`;
}

function normalizeLmStudioBaseUrl(rawBase) {
  const base = String(rawBase || "").trim();
  if (!base) return "http://localhost:1234/v1";
  if (base.match(/\/v1\/?$/i)) return base.replace(/\/+$/, "");
  if (base.match(/\/v1\/models\/?$/i)) return base.replace(/\/models\/?$/i, "");
  return `${base.replace(/\/+$/, "")}/v1`;
}

function buildLmStudioApiV0ModelsUrl(rawBase) {
  const normalized = normalizeLmStudioBaseUrl(rawBase);
  return normalized.replace(/\/v1\/?$/i, "/api/v0/models");
}

function buildLmStudioV1ModelsUrl(rawBase) {
  const normalized = normalizeLmStudioBaseUrl(rawBase);
  return `${normalized.replace(/\/+$/, "")}/models`;
}

function buildLmStudioApiV1ModelLoadUrl(rawBase) {
  const normalized = normalizeLmStudioBaseUrl(rawBase);
  return normalized.replace(/\/v1\/?$/i, "/api/v1/models/load");
}

function buildLmStudioHeaders(extra = {}) {
  const headers = {
    Accept: "application/json",
    ...extra,
  };
  const token = String(process.env.LM_API_TOKEN || "").trim();
  if (token) {
    headers.Authorization = `Bearer ${token}`;
  }
  return headers;
}

function appendLmStudioRuntimeLog(taskLogDir, liveLogFile, message) {
  const line = `[lmstudio] ${new Date().toISOString()} ${message}\n`;
  if (taskLogDir) {
    appendFileSafe(path.join(taskLogDir, "lmstudio-autostart.log"), line);
  }
  if (liveLogFile) {
    appendFileSafe(liveLogFile, line);
  }
  console.warn(line.trim());
}

async function probeLmStudioUrl(url, timeoutMs = LMSTUDIO_HEALTH_TIMEOUT_MS) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, {
      method: "GET",
      headers: buildLmStudioHeaders(),
      signal: controller.signal,
    });
    return {
      ok: response.ok,
      status: response.status,
      statusText: response.statusText,
      error: response.ok ? "" : `${response.status} ${response.statusText}`,
    };
  } catch (error) {
    return {
      ok: false,
      status: 0,
      statusText: "",
      error: clipText(String(error?.message || error), 500),
    };
  } finally {
    clearTimeout(timeout);
  }
}

async function probeLmStudioServer(rawBase) {
  const apiV0Probe = await probeLmStudioUrl(buildLmStudioApiV0ModelsUrl(rawBase));
  if (apiV0Probe.ok) {
    return { ...apiV0Probe, url: buildLmStudioApiV0ModelsUrl(rawBase) };
  }
  const v1Probe = await probeLmStudioUrl(buildLmStudioV1ModelsUrl(rawBase));
  return { ...v1Probe, url: buildLmStudioV1ModelsUrl(rawBase), fallbackFrom: apiV0Probe };
}

function buildLmStudioLaunchSpec() {
  if (LMSTUDIO_START_COMMAND) {
    return {
      ...buildShellCommand(LMSTUDIO_START_COMMAND),
      cwd: __dirname,
      label: LMSTUDIO_START_COMMAND,
      custom: true,
    };
  }

  const candidates = [];
  if (IS_WINDOWS) {
    const localAppData = process.env.LOCALAPPDATA || path.join(os.homedir(), "AppData", "Local");
    const programFiles = process.env.ProgramFiles || "C:\\Program Files";
    const programFilesX86 = process.env["ProgramFiles(x86)"] || "C:\\Program Files (x86)";
    candidates.push(
      path.join(localAppData, "Programs", "LM Studio", "LM Studio.exe"),
      path.join(localAppData, "Programs", "LM-Studio", "LM Studio.exe"),
      path.join(localAppData, "LM Studio", "LM Studio.exe"),
      path.join(localAppData, "LM-Studio", "LM Studio.exe"),
      path.join(programFiles, "LM Studio", "LM Studio.exe"),
      path.join(programFiles, "LM-Studio", "LM Studio.exe"),
      path.join(programFilesX86, "LM Studio", "LM Studio.exe"),
      path.join(programFilesX86, "LM-Studio", "LM Studio.exe")
    );
  } else if (IS_MACOS) {
    candidates.push(
      "/Applications/LM Studio.app/Contents/MacOS/LM Studio",
      path.join(os.homedir(), "Applications", "LM Studio.app", "Contents", "MacOS", "LM Studio")
    );
  } else {
    candidates.push(
      "/usr/bin/lmstudio",
      "/usr/local/bin/lmstudio",
      path.join(os.homedir(), ".local", "bin", "lmstudio")
    );
  }

  const executable = candidates.find((candidate) => {
    try {
      return fs.existsSync(candidate);
    } catch (_ignored) {
      return false;
    }
  });
  if (!executable) {
    return null;
  }
  return {
    command: executable,
    args: [],
    cwd: path.dirname(executable),
    label: executable,
    custom: false,
  };
}

async function countRunningLmStudioProcesses() {
  try {
    if (IS_WINDOWS) {
      const result = await runExecutableCommand({
        executable: "tasklist",
        args: ["/FI", "IMAGENAME eq LM Studio.exe", "/FO", "CSV", "/NH"],
        cwd: __dirname,
        timeoutMs: 5000,
      });
      const output = [result.stdout, result.stderr].filter(Boolean).join("\n");
      if (/no tasks are running|no hay tareas en ejecuci/i.test(output)) return 0;
      return output
        .split(/\r?\n/)
        .filter((line) => line.toLowerCase().includes("lm studio.exe"))
        .length;
    }
    if (IS_MACOS) {
      const result = await runExecutableCommand({
        executable: "pgrep",
        args: ["-f", "LM Studio"],
        cwd: __dirname,
        timeoutMs: 5000,
      });
      return result.stdout.split(/\r?\n/).filter((line) => line.trim()).length;
    }
    const result = await runExecutableCommand({
      executable: "pgrep",
      args: ["-f", "lmstudio|LM Studio"],
      cwd: __dirname,
      timeoutMs: 5000,
    });
    return result.stdout.split(/\r?\n/).filter((line) => line.trim()).length;
  } catch (_error) {
    return 0;
  }
}

async function waitUntilLmStudioReachable(rawBase, waitMs, taskLogDir, liveLogFile) {
  const deadline = Date.now() + waitMs;
  let lastProbe = null;
  while (Date.now() < deadline) {
    lastProbe = await probeLmStudioServer(rawBase);
    if (lastProbe.ok) {
      return { ok: true, probe: lastProbe };
    }
    await sleep(1500);
  }
  appendLmStudioRuntimeLog(
    taskLogDir,
    liveLogFile,
    `LM Studio sigue sin responder tras ${waitMs}ms (${lastProbe?.error || "sin respuesta"}).`
  );
  return { ok: false, probe: lastProbe };
}

function isLmStudioModelLoaded(modelInfo) {
  if (!modelInfo) {
    return false;
  }
  const loadedContextLength = Number(modelInfo?.loaded_context_length || 0);
  if (Number.isFinite(loadedContextLength) && loadedContextLength > 0) {
    return true;
  }
  if (modelInfo?.loaded === true || modelInfo?.is_loaded === true) {
    return true;
  }
  const state = String(modelInfo?.state || modelInfo?.status || "").toLowerCase();
  return state.includes("loaded") || state.includes("running");
}

function isLmStudioModelIdVariant(candidateId, targetModelId) {
  const candidate = String(candidateId || "").trim();
  const target = String(targetModelId || "").trim();
  return Boolean(candidate && target && (candidate === target || candidate.startsWith(`${target}:`)));
}

function pickBestLmStudioModelInfo(items, modelId) {
  const target = String(modelId || "").trim();
  if (!target || !Array.isArray(items)) {
    return null;
  }
  const candidates = items.filter((item) => isLmStudioModelIdVariant(item?.id, target));
  if (candidates.length === 0) {
    return null;
  }
  candidates.sort((a, b) => {
    const aLoaded = isLmStudioModelLoaded(a) ? 1 : 0;
    const bLoaded = isLmStudioModelLoaded(b) ? 1 : 0;
    if (aLoaded !== bLoaded) return bLoaded - aLoaded;
    const aCtx = Number(a?.loaded_context_length || 0);
    const bCtx = Number(b?.loaded_context_length || 0);
    if (aCtx !== bCtx) return bCtx - aCtx;
    const aExact = String(a?.id || "") === target ? 1 : 0;
    const bExact = String(b?.id || "") === target ? 1 : 0;
    return bExact - aExact;
  });
  return candidates[0] || null;
}

function resolveLmStudioPreferredContextLength(modelId) {
  const key = String(modelId || "").trim();
  if (!key) return 0;
  return Number(LMSTUDIO_MODEL_CONTEXT_OVERRIDES[key] || 0) || 0;
}

async function fetchLmStudioModelCatalog(rawBase, options = {}) {
  const modelsUrl = buildLmStudioApiV0ModelsUrl(rawBase);
  const cacheKey = modelsUrl;
  const forceRefresh = options?.forceRefresh === true;
  if (!forceRefresh && lmStudioModelCatalogCache?.url === cacheKey && Array.isArray(lmStudioModelCatalogCache?.items)) {
    return lmStudioModelCatalogCache.items;
  }

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 5000);
  try {
    const response = await fetch(modelsUrl, { method: "GET", headers: buildLmStudioHeaders(), signal: controller.signal });
    if (!response.ok) {
      return [];
    }
    const payload = await response.json().catch(() => null);
    const items = Array.isArray(payload?.data) ? payload.data : [];
    lmStudioModelCatalogCache = { url: cacheKey, items };
    return items;
  } catch (_error) {
    return [];
  } finally {
    clearTimeout(timeout);
  }
}

async function fetchLmStudioModelInfo(rawBase, modelId, options = {}) {
  const target = String(modelId || "").trim();
  if (!target) return null;
  const items = await fetchLmStudioModelCatalog(rawBase, options);
  return pickBestLmStudioModelInfo(items, target);
}

async function requestLmStudioModelLoad(rawBase, modelId, contextLength) {
  const target = String(modelId || "").trim();
  const desiredContext = Number(contextLength || 0);
  if (!target) {
    return { ok: false, error: "invalid-load-request" };
  }
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), LMSTUDIO_MODEL_LOAD_TIMEOUT_MS);
  try {
    const body = {
      model: target,
      echo_load_config: true,
    };
    if (Number.isFinite(desiredContext) && desiredContext > 0) {
      body.context_length = desiredContext;
    }
    const response = await fetch(buildLmStudioApiV1ModelLoadUrl(rawBase), {
      method: "POST",
      headers: buildLmStudioHeaders({ "Content-Type": "application/json" }),
      body: JSON.stringify(body),
      signal: controller.signal,
    });
    const payload = await response.json().catch(() => null);
    if (!response.ok) {
      return {
        ok: false,
        error: clipText(String(payload?.error || payload?.message || `${response.status} ${response.statusText}`), 500),
      };
    }
    lmStudioModelCatalogCache = null;
    return {
      ok: true,
      payload,
      appliedContextLength: Number(payload?.load_config?.context_length || desiredContext) || desiredContext || 0,
    };
  } catch (error) {
    return {
      ok: false,
      error: clipText(String(error?.message || error), 500),
    };
  } finally {
    clearTimeout(timeout);
  }
}

async function ensureLmStudioPreferredModelContext(rawBase, modelId) {
  const target = String(modelId || "").trim();
  const preferredContextLength = resolveLmStudioPreferredContextLength(target);
  if (!target) {
    return { modelInfo: null, warning: null, autoLoadApplied: false, effectiveModelId: "" };
  }

  let modelInfo = await fetchLmStudioModelInfo(rawBase, target, { forceRefresh: true });
  const loadedContextLength = Number(modelInfo?.loaded_context_length || 0);
  if (preferredContextLength > 0 && Number.isFinite(loadedContextLength) && loadedContextLength >= preferredContextLength) {
    return { modelInfo, warning: null, autoLoadApplied: false, effectiveModelId: String(modelInfo?.id || target).trim() || target };
  }
  if (preferredContextLength <= 0 && isLmStudioModelLoaded(modelInfo)) {
    return { modelInfo, warning: null, autoLoadApplied: false, effectiveModelId: String(modelInfo?.id || target).trim() || target };
  }

  const loadResult = await requestLmStudioModelLoad(rawBase, target, preferredContextLength);
  modelInfo = await fetchLmStudioModelInfo(rawBase, target, { forceRefresh: true });
  const refreshedLoadedContext = Number(modelInfo?.loaded_context_length || 0);
  const hasRequiredContext = preferredContextLength > 0
    ? Number.isFinite(refreshedLoadedContext) && refreshedLoadedContext >= preferredContextLength
    : isLmStudioModelLoaded(modelInfo);
  if (
    loadResult.ok
    && hasRequiredContext
  ) {
    const effectiveModelId = String(modelInfo?.id || target).trim() || target;
    return {
      modelInfo,
      warning: preferredContextLength > 0
        ? `LM Studio autoload aplicado: ${target}${effectiveModelId !== target ? ` -> ${effectiveModelId}` : ""} ctx=${refreshedLoadedContext || loadResult.appliedContextLength || "?"}.`
        : `LM Studio model load solicitado: ${target}${effectiveModelId !== target ? ` -> ${effectiveModelId}` : ""}.`,
      autoLoadApplied: true,
      effectiveModelId
    };
  }

  const detail = loadResult.ok
    ? `ctx real tras recarga=${refreshedLoadedContext || loadResult.appliedContextLength || "?"}`
    : `recarga fallida: ${loadResult.error || "error desconocido"}`;
  return {
    modelInfo,
    warning: preferredContextLength > 0
      ? `LM Studio autoload pendiente para ${target} (objetivo ${preferredContextLength}): ${detail}.`
      : `LM Studio model load pendiente para ${target}: ${detail}.`,
    autoLoadApplied: false,
    effectiveModelId: String(modelInfo?.id || target).trim() || target
  };
}

async function ensureLmStudioReady(rawBase, modelId, taskLogDir, liveLogFile = null) {
  const base = normalizeLmStudioBaseUrl(rawBase);
  const target = String(modelId || "").trim();
  const initialProbe = await probeLmStudioServer(base);
  let autostartWarning = null;

  if (!initialProbe.ok) {
    if (!LMSTUDIO_AUTOSTART_ENABLED) {
      const message = [
        "LM Studio preflight failed:",
        `server=${base}`,
        `error=${initialProbe.error || "unreachable"}`,
        "JARVIS_LMSTUDIO_AUTOSTART_ENABLED=false."
      ].join(" ");
      appendLmStudioRuntimeLog(taskLogDir, liveLogFile, message);
      throw new Error(message);
    }

    const runningLmStudioProcesses = await countRunningLmStudioProcesses();
    if (runningLmStudioProcesses > 0) {
      appendLmStudioRuntimeLog(
        taskLogDir,
        liveLogFile,
        `LM Studio API no responde en ${base}, pero ya hay ${runningLmStudioProcesses} proceso(s) de LM Studio. Espero a que levanten API antes de lanzar otra instancia.`
      );
      const recoveredExisting = await waitUntilLmStudioReachable(base, LMSTUDIO_START_WAIT_MS, taskLogDir, liveLogFile);
      if (recoveredExisting.ok) {
        autostartWarning = `LM Studio ya estaba en proceso de arranque (${runningLmStudioProcesses} proceso(s)); no se lanzó otra instancia.`;
        appendLmStudioRuntimeLog(taskLogDir, liveLogFile, `LM Studio disponible en ${base}.`);
      } else if (!LMSTUDIO_ALLOW_DUPLICATE_START) {
        const message = [
          "LM Studio preflight failed:",
          `server=${base}`,
          `hay ${runningLmStudioProcesses} proceso(s) de LM Studio pero la API no respondió tras ${LMSTUDIO_START_WAIT_MS}ms.`,
          "No lanzo otra instancia para evitar procesos duplicados.",
          "Cierra LM Studio o habilita el servidor local; si quieres permitir duplicados configura JARVIS_LMSTUDIO_ALLOW_DUPLICATE_START=true."
        ].join(" ");
        appendLmStudioRuntimeLog(taskLogDir, liveLogFile, message);
        throw new Error(message);
      } else {
        appendLmStudioRuntimeLog(
          taskLogDir,
          liveLogFile,
          "JARVIS_LMSTUDIO_ALLOW_DUPLICATE_START=true; se permite lanzar otra instancia de LM Studio."
        );
      }
    }

    const launchSpec = buildLmStudioLaunchSpec();
    if (!initialProbe.ok && autostartWarning && !LMSTUDIO_ALLOW_DUPLICATE_START) {
      // Existing LM Studio process became reachable; skip launching a duplicate.
    } else if (!launchSpec) {
      const message = [
        "LM Studio preflight failed:",
        `server=${base}`,
        "no está levantado y no encontré el ejecutable de LM Studio en rutas comunes.",
        "Configura JARVIS_LMSTUDIO_START_COMMAND con el comando de arranque."
      ].join(" ");
      appendLmStudioRuntimeLog(taskLogDir, liveLogFile, message);
      throw new Error(message);
    } else if (!autostartWarning || LMSTUDIO_ALLOW_DUPLICATE_START) {
      appendLmStudioRuntimeLog(
        taskLogDir,
        liveLogFile,
        `LM Studio no responde en ${base}; lanzando ${launchSpec.custom ? "comando configurado" : "aplicación"}: ${launchSpec.label}`
      );
      try {
        const launcher = spawn(launchSpec.command, launchSpec.args || [], {
          cwd: launchSpec.cwd || __dirname,
          detached: true,
          stdio: "ignore",
          windowsHide: true,
        });
        launcher.unref();
      } catch (error) {
        const message = `LM Studio preflight failed: no pude lanzar ${launchSpec.label}: ${error.message}`;
        appendLmStudioRuntimeLog(taskLogDir, liveLogFile, message);
        throw new Error(message);
      }

      const recovered = await waitUntilLmStudioReachable(base, LMSTUDIO_START_WAIT_MS, taskLogDir, liveLogFile);
      if (!recovered.ok) {
        const message = [
          "LM Studio preflight failed:",
          `server=${base}`,
          `no respondió tras ${LMSTUDIO_START_WAIT_MS}ms`,
          `último_error=${recovered.probe?.error || "sin respuesta"}.`
        ].join(" ");
        appendLmStudioRuntimeLog(taskLogDir, liveLogFile, message);
        throw new Error(message);
      }
      autostartWarning = `LM Studio autostart aplicado (${launchSpec.custom ? "custom command" : "default launcher"}).`;
      appendLmStudioRuntimeLog(taskLogDir, liveLogFile, `LM Studio disponible en ${base}.`);
    }
  } else {
    appendLmStudioRuntimeLog(taskLogDir, liveLogFile, `LM Studio ya estaba disponible en ${base}.`);
  }

  const contextPrep = await ensureLmStudioPreferredModelContext(base, target);
  if (contextPrep?.warning) {
    appendLmStudioRuntimeLog(taskLogDir, liveLogFile, contextPrep.warning);
  }
  if (target && contextPrep?.warning && !contextPrep.autoLoadApplied) {
    throw new Error(`LM Studio model load failed: ${contextPrep.warning}`);
  }

  return {
    ...(contextPrep || { modelInfo: null, warning: null, autoLoadApplied: false, effectiveModelId: target }),
    effectiveModelId: String(contextPrep?.effectiveModelId || target).trim() || target,
    warning: [autostartWarning, contextPrep?.warning || null].filter(Boolean).join(" | ") || null,
  };
}

function detectContextOverflowMessage(text) {
  const plain = stripAnsiAndControlChars(text).trim();
  if (!plain) return "";
  const match = plain.match(/Error:\s*"?([^"\n]*context length[^"\n]*|[^"\n]*n_keep[^"\n]*n_ctx[^"\n]*)"?/i);
  return match ? clipText(match[1].trim(), 500) : "";
}

function detectOpenCodeFatalOutput(text) {
  const plain = stripAnsiAndControlChars(text).trim();
  if (!plain) return "";
  const overflow = detectContextOverflowMessage(plain);
  if (overflow) {
    return `OpenCode context overflow: ${overflow}`;
  }
  const fatalError = plain.match(/(^|\n)Error:\s+(.+)/i);
  if (fatalError) {
    return `OpenCode runtime error: ${clipText(fatalError[2].trim(), 500)}`;
  }
  return "";
}

function resolveOpenCodeModelSpecifier(llmRuntimeConfig) {
  const runtimeModel = String(llmRuntimeConfig?.model || "").trim();
  if (!runtimeModel) return OPENCODE_MODEL || "";

  const provider = String(llmRuntimeConfig?.provider || "OPENAI").trim().toUpperCase();
  if (isLocalOssProvider(provider)) {
    const localProvider = resolveLocalOssProvider(provider, llmRuntimeConfig?.localProvider);
    return `${localProvider}/${runtimeModel}`;
  }
  if (provider === "ANTHROPIC") {
    return `anthropic/${runtimeModel}`;
  }
  if (provider === "OPENAI") {
    return `openai/${runtimeModel}`;
  }
  return runtimeModel;
}

function normalizeClaudeRuntimeConfig(rawConfig) {
  const authMode = String(rawConfig?.authMode || "API_KEY").trim().toUpperCase();
  const normalizedAuthMode = authMode === "GATEWAY"
    ? "GATEWAY"
    : authMode === "LOCAL_AGENT"
      ? "LOCAL_AGENT"
      : "API_KEY";
  return {
    enabled: Boolean(rawConfig?.enabled),
    accountLabel: String(rawConfig?.accountLabel || "").trim(),
    authMode: normalizedAuthMode,
    apiKey: String(rawConfig?.apiKey || "").trim(),
    authToken: String(rawConfig?.authToken || "").trim(),
    baseUrl: String(rawConfig?.baseUrl || "").trim(),
    model: String(rawConfig?.model || "").trim(),
    apiKeyConfigured: Boolean(rawConfig?.apiKeyConfigured),
    authTokenConfigured: Boolean(rawConfig?.authTokenConfigured),
  };
}

function runCommand({
  command,
  args,
  cwd,
  timeoutMs,
  stdinText = null,
  env = process.env,
  liveLogFile = null,
}) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, {
      cwd,
      env,
      stdio: ["pipe", "pipe", "pipe"],
    });

    let stdout = "";
    let stderr = "";
    let timedOut = false;
    let settled = false;
    let forceKillTimer = null;
    let timer = null;
    let terminationPromise = null;
    const timeoutEnabled = Number.isFinite(timeoutMs) && timeoutMs > 0;

    const finish = (payload) => {
      if (settled) return;
      settled = true;
      if (timer) {
        clearTimeout(timer);
        timer = null;
      }
      if (forceKillTimer) {
        clearTimeout(forceKillTimer);
        forceKillTimer = null;
      }
      resolve(payload);
    };

    const scheduleForcedResolve = (termination) => {
      if (forceKillTimer || settled) return;
      forceKillTimer = setTimeout(() => {
        finish({
          code: null,
          stdout,
          stderr: `${stderr}\nProcess tree was terminated but the wrapper did not emit close.`.trim(),
          timedOut: true,
          forcedExit: true,
          processTreeTerminated: termination.verified,
          terminationReason: termination.reason,
        });
      }, PROCESS_FORCE_KILL_GRACE_MS);
    };

    const beginTimeoutTermination = () => {
      if (terminationPromise) return terminationPromise;
      terminationPromise = terminateChildProcessTree(child).then((termination) => {
        if (!termination.verified) {
          finish({
            code: null,
            stdout,
            stderr: `${stderr}\nUnable to verify process-tree termination: ${termination.reason}`.trim(),
            timedOut: true,
            forcedExit: true,
            processTreeTerminated: false,
            terminationReason: termination.reason,
          });
        } else {
          scheduleForcedResolve(termination);
        }
        return termination;
      });
      return terminationPromise;
    };

    if (timeoutEnabled) {
      timer = setTimeout(() => {
        timedOut = true;
        void beginTimeoutTermination();
      }, timeoutMs);
    }

    child.stdout.on("data", (chunk) => {
      const text = chunk.toString();
      stdout += text;
      if (liveLogFile) {
        appendFileSafe(liveLogFile, text);
      }
    });

    child.stderr.on("data", (chunk) => {
      const text = chunk.toString();
      stderr += text;
      if (liveLogFile) {
        appendFileSafe(liveLogFile, text);
      }
    });

    child.on("error", (error) => {
      finish({
        code: typeof error.errno === "number" ? error.errno : 127,
        stdout,
        stderr: error.message || String(error),
        timedOut,
        spawnError: error,
      });
    });

    child.on("close", async (code) => {
      const termination = terminationPromise ? await terminationPromise : null;
      finish({
        code,
        stdout,
        stderr,
        timedOut,
        processTreeTerminated: termination?.verified ?? !timedOut,
        terminationReason: termination?.reason || null,
      });
    });

    if (stdinText !== null) {
      child.stdin.write(stdinText);
    }
    child.stdin.end();
  });
}

function requireProjectPath(taskPayload) {
  const projectPath = taskPayload?.project?.absolutePath;
  if (!projectPath || typeof projectPath !== "string") {
    throw new Error("Task payload missing project.absolutePath");
  }
  const resolved = path.resolve(projectPath);
  if (!fs.existsSync(resolved)) {
    throw new Error(`Project path does not exist: ${resolved}`);
  }
  return resolved;
}

async function prepareTaskWorktree(taskPayload, options = {}) {
  const sourcePath = path.resolve(options.sourcePath || requireProjectPath(taskPayload));
  const enabled = options.enabled ?? TASK_WORKTREE_ENABLED;
  const taskId = String(taskPayload?.task?.id || "").trim();
  const branchName = String(taskPayload?.task?.branchName || "").trim();
  if (!enabled) {
    return { sourcePath, projectPath: sourcePath, managed: false, created: false };
  }
  if (!taskId || !branchName) {
    throw new Error("Task worktree requires task.id and task.branchName");
  }

  const gitCheck = await runExecutableCommand({
    executable: "git",
    args: ["rev-parse", "--is-inside-work-tree"],
    cwd: sourcePath,
    timeoutMs: 20_000,
  });
  if (gitCheck.code !== 0) {
    throw new Error(`Task worktree isolation requires a git repository: ${sourcePath}`);
  }

  const projectPath = resolveTaskWorktreePath(sourcePath, taskId, options.root);
  const root = path.dirname(projectPath);
  ensureDirectory(root);

  if (fs.existsSync(projectPath)) {
    const existingCheck = await runExecutableCommand({
      executable: "git",
      args: ["rev-parse", "--is-inside-work-tree"],
      cwd: projectPath,
      timeoutMs: 20_000,
    });
    if (existingCheck.code !== 0) {
      throw new Error(`Task worktree path exists but is not a git worktree: ${projectPath}`);
    }
    const currentBranch = await getCurrentBranch(projectPath);
    if (currentBranch !== branchName) {
      throw new Error(`Task worktree ${projectPath} is on ${currentBranch}, expected ${branchName}; refusing to switch it.`);
    }
    return { sourcePath, projectPath, managed: true, created: false };
  }

  const branchExists = await runExecutableCommand({
    executable: "git",
    args: ["show-ref", "--verify", "--quiet", `refs/heads/${branchName}`],
    cwd: sourcePath,
    timeoutMs: 20_000,
  });
  const requestedBaseRef = String(
    taskPayload?.task?.targetBaseBranch ||
    taskPayload?.task?.baseBranch ||
    taskPayload?.project?.defaultBranch ||
    "HEAD"
  ).trim() || "HEAD";
  const baseExists = await runExecutableCommand({
    executable: "git",
    args: ["rev-parse", "--verify", "--quiet", `${requestedBaseRef}^{commit}`],
    cwd: sourcePath,
    timeoutMs: 20_000,
  });
  const baseRef = baseExists.code === 0 ? requestedBaseRef : "HEAD";
  const addArgs = branchExists.code === 0
    ? ["worktree", "add", projectPath, branchName]
    : ["worktree", "add", "-b", branchName, projectPath, baseRef];
  const added = await runExecutableCommand({
    executable: "git",
    args: addArgs,
    cwd: sourcePath,
    timeoutMs: 90_000,
  });
  if (added.code !== 0) {
    const details = clipText(`${added.stderr}\n${added.stdout}`.trim(), 1200);
    throw new Error(`Unable to create isolated task worktree for ${branchName}: ${details}`);
  }

  const localProperties = path.join(sourcePath, "local.properties");
  if (fs.existsSync(localProperties)) {
    fs.copyFileSync(localProperties, path.join(projectPath, "local.properties"));
  }
  return { sourcePath, projectPath, managed: true, created: true };
}

function resolveTaskWorktreePath(sourcePath, taskId, root = "") {
  const resolvedSource = path.resolve(sourcePath);
  const resolvedRoot = path.resolve(
    root || TASK_WORKTREE_ROOT || path.join(path.dirname(resolvedSource), `${path.basename(resolvedSource)}-jarvis-tasks`)
  );
  return path.join(resolvedRoot, sanitizeFileComponent(taskId));
}

async function releaseManagedTaskWorktree(sourcePath, taskId, options = {}) {
  const projectPath = resolveTaskWorktreePath(sourcePath, taskId, options.root);
  if (!fs.existsSync(projectPath)) {
    return { released: false, projectPath, summary: "No managed task worktree found." };
  }
  const status = await gitStatusPorcelain(projectPath);
  if (status) {
    return {
      released: false,
      projectPath,
      summary: `Managed task worktree kept because it is dirty: ${clipText(status, 800)}`,
    };
  }
  const removed = await runExecutableCommand({
    executable: "git",
    args: ["worktree", "remove", projectPath],
    cwd: sourcePath,
    timeoutMs: 60_000,
  });
  if (removed.code !== 0) {
    return {
      released: false,
      projectPath,
      summary: `Managed task worktree removal failed: ${clipText(removed.stderr || removed.stdout, 800)}`,
    };
  }
  await runExecutableCommand({
    executable: "git",
    args: ["worktree", "prune"],
    cwd: sourcePath,
    timeoutMs: 20_000,
  });
  return { released: true, projectPath, summary: `Released managed task worktree ${projectPath}.` };
}

async function ensureBranch(projectPath, branchName) {
  const check = await runExecutableCommand({
    executable: "git",
    args: ["rev-parse", "--is-inside-work-tree"],
    cwd: projectPath,
    timeoutMs: 20_000,
  });
  if (check.code !== 0) {
    throw new Error(`Not a git repository: ${clipText(check.stderr || check.stdout, 400)}`);
  }

  const checkout = await runExecutableCommand({
    executable: "git",
    args: ["checkout", branchName],
    cwd: projectPath,
    timeoutMs: 20_000,
  });
  if (checkout.code === 0) {
    return;
  }

  const create = await runExecutableCommand({
    executable: "git",
    args: ["checkout", "-b", branchName],
    cwd: projectPath,
    timeoutMs: 20_000,
  });
  if (create.code === 0) {
    return;
  }

  if (create.code !== 0) {
    throw new Error(
      `Failed to checkout branch ${branchName} without overwriting local work: ` +
      clipText(`${checkout.stderr}\n${checkout.stdout}\n${create.stderr}\n${create.stdout}`.trim(), 900)
    );
  }
}

async function getCurrentBranch(projectPath) {
  const symbolic = await runExecutableCommand({
    executable: "git",
    args: ["symbolic-ref", "--short", "HEAD"],
    cwd: projectPath,
    timeoutMs: 20_000,
  });
  if (symbolic.code === 0) {
    const branch = String(symbolic.stdout || "").trim();
    if (branch) {
      return branch;
    }
  }

  const current = await runExecutableCommand({
    executable: "git",
    args: ["rev-parse", "--abbrev-ref", "HEAD"],
    cwd: projectPath,
    timeoutMs: 20_000,
  });
  if (current.code !== 0) {
    const raw = `${current.stderr || ""}\n${current.stdout || ""}`.toLowerCase();
    const unbornHead =
      raw.includes("ambiguous argument 'head'") ||
      raw.includes("unknown revision or path not in the working tree") ||
      raw.includes("does not have any commits yet");
    if (unbornHead) {
      return "HEAD";
    }
    throw new Error(`Failed to read current branch: ${clipText(current.stderr || current.stdout, 400)}`);
  }
  const branch = String(current.stdout || "").trim();
  return branch || "HEAD";
}

function parseCommandPayload(payloadJson) {
  if (typeof payloadJson !== "string") {
    return payloadJson && typeof payloadJson === "object" ? payloadJson : {};
  }
  try {
    return JSON.parse(payloadJson);
  } catch (error) {
    throw new Error(`Invalid command payload JSON: ${error.message}`);
  }
}

async function runGitCommand(projectPath, gitArgs, timeoutMs = 90_000, allowFailure = false) {
  const result = await runExecutableCommand({
    executable: "git",
    args: gitArgs,
    cwd: projectPath,
    timeoutMs,
  });
  const combined = clipText([result.stdout, result.stderr].filter(Boolean).join("\n"), 3000);
  if (result.timedOut) {
    throw new Error(`git ${gitArgs.join(" ")} timed out after ${timeoutMs}ms`);
  }
  if (result.code !== 0 && !allowFailure) {
    throw new Error(`git ${gitArgs.join(" ")} failed: ${combined || `exit=${result.code}`}`);
  }
  return {
    success: result.code === 0,
    output: combined || "ok",
    stdout: String(result.stdout || "").trim(),
    stderr: String(result.stderr || "").trim(),
  };
}

function normalizeGitRemoteForHandoff(raw) {
  const value = String(raw || "").trim().replace(/\\/g, "/").replace(/\/$/, "").replace(/\.git$/i, "");
  const scpLike = value.match(/^[^@/]+@([^:]+):(.+)$/);
  if (scpLike) return `${scpLike[1].toLowerCase()}/${scpLike[2].replace(/^\/+/, "")}`.toLowerCase();
  try {
    const parsed = new URL(value);
    return `${parsed.hostname.toLowerCase()}/${parsed.pathname.replace(/^\/+|\/+$/g, "").replace(/\.git$/i, "")}`.toLowerCase();
  } catch (_error) {
    return value.toLowerCase();
  }
}

function parseAheadBehind(raw, label) {
  const values = String(raw || "").trim().split(/\s+/).map((value) => Number(value));
  if (values.length < 2 || values.some((value) => !Number.isFinite(value))) {
    throw new Error(`Cannot read Git divergence for ${label}: ${raw || "empty output"}`);
  }
  return { ahead: values[0], behind: values[1] };
}

async function executeRemoteProjectHandoff(commandPayload, commandLogDir) {
  const payload = parseCommandPayload(commandPayload?.payloadJson);
  const phase = String(payload.phase || "").trim().toUpperCase();
  const projectPathRaw = String(payload.projectPath || "").trim();
  const expectedOrigin = String(payload.originUrl || "").trim();
  const remoteName = String(payload.remoteName || "origin").trim() || "origin";
  if (!phase) throw new Error("Project handoff payload missing phase");
  if (!projectPathRaw) throw new Error("Project handoff payload missing projectPath");
  if (!expectedOrigin) throw new Error("Project handoff requires an origin URL");
  const projectPath = path.resolve(projectPathRaw);
  if (!fs.existsSync(projectPath) || !fs.statSync(projectPath).isDirectory()) {
    throw new Error(`Project path does not exist: ${projectPath}`);
  }

  const logs = [];
  const appendLog = (line) => logs.push(`[${new Date().toISOString()}] ${line}`);
  const persistLogs = () => fs.writeFileSync(path.join(commandLogDir, "agent-command.log"), `${logs.join("\n")}\n`, "utf8");

  try {
    await runGitCommand(projectPath, ["rev-parse", "--is-inside-work-tree"]);
    const remote = await runGitCommand(projectPath, ["remote", "get-url", remoteName], 20_000, true);
    if (!remote.success || !remote.stdout) throw new Error(`Remote ${remoteName} is not configured`);
    if (normalizeGitRemoteForHandoff(remote.stdout) !== normalizeGitRemoteForHandoff(expectedOrigin)) {
      throw new Error(`Remote ${remoteName} does not match the project origin (${remote.stdout})`);
    }
    const status = await runGitCommand(projectPath, ["status", "--porcelain", "--untracked-files=all"], 20_000, true);
    if (!status.success) throw new Error(`Cannot read Git status: ${status.output}`);
    if (status.stdout) {
      throw new Error(`Workspace has uncommitted or untracked changes; handoff cancelled:\n${clipText(status.stdout, 1200)}`);
    }
    appendLog(`Verified clean repository and ${remoteName}=${remote.stdout}.`);

    if (phase === "PREPARE_SOURCE") {
      const branchResult = await runGitCommand(projectPath, ["rev-parse", "--abbrev-ref", "HEAD"], 20_000);
      const branch = branchResult.stdout;
      if (!branch || branch === "HEAD") throw new Error("Cannot hand off a detached HEAD");
      await runGitCommand(projectPath, ["fetch", "--prune", remoteName], 120_000);
      const remoteRef = `refs/remotes/${remoteName}/${branch}`;
      const remoteExists = await runGitCommand(projectPath, ["rev-parse", "--verify", "--quiet", remoteRef], 20_000, true);
      if (remoteExists.success) {
        const divergence = await runGitCommand(projectPath, ["rev-list", "--left-right", "--count", `HEAD...${remoteName}/${branch}`], 20_000);
        const { ahead, behind } = parseAheadBehind(divergence.stdout, branch);
        if (ahead > 0 && behind > 0) {
          throw new Error(`Local ${branch} and ${remoteName}/${branch} have diverged (ahead ${ahead}, behind ${behind})`);
        }
        if (behind > 0) {
          await runGitCommand(projectPath, ["pull", "--ff-only", remoteName, branch], 120_000);
          appendLog(`Fast-forwarded ${branch} from ${remoteName}/${branch}.`);
        }
      }
      await runGitCommand(projectPath, ["push", "--set-upstream", remoteName, branch], 180_000);
      await runGitCommand(projectPath, ["fetch", remoteName, branch], 120_000);
      const localCommit = (await runGitCommand(projectPath, ["rev-parse", "HEAD"], 20_000)).stdout;
      const remoteCommit = (await runGitCommand(projectPath, ["rev-parse", `${remoteName}/${branch}`], 20_000)).stdout;
      if (!localCommit || localCommit !== remoteCommit) {
        throw new Error(`Push verification failed: local=${localCommit || "?"}, remote=${remoteCommit || "?"}`);
      }
      const summary = `Source published ${branch}@${localCommit.slice(0, 12)} to ${remoteName}.`;
      appendLog(summary);
      persistLogs();
      return { phase, originUrl: remote.stdout, branch, commit: localCommit, summary };
    }

    if (phase === "RECEIVE_TARGET") {
      const branch = String(payload.branch || "").trim();
      const expectedCommit = String(payload.expectedCommit || "").trim();
      if (!branch || !expectedCommit) throw new Error("Target handoff requires branch and expectedCommit");
      await runGitCommand(projectPath, ["fetch", "--prune", remoteName, branch], 120_000);
      const remoteCommit = (await runGitCommand(projectPath, ["rev-parse", `${remoteName}/${branch}`], 20_000)).stdout;
      if (remoteCommit !== expectedCommit) {
        throw new Error(`${remoteName}/${branch} is ${remoteCommit || "missing"}, expected ${expectedCommit}`);
      }
      const localExists = await runGitCommand(projectPath, ["show-ref", "--verify", "--quiet", `refs/heads/${branch}`], 20_000, true);
      const currentBranch = (await runGitCommand(projectPath, ["rev-parse", "--abbrev-ref", "HEAD"], 20_000)).stdout;
      if (currentBranch !== branch) {
        if (localExists.success) await runGitCommand(projectPath, ["checkout", branch], 30_000);
        else await runGitCommand(projectPath, ["checkout", "-b", branch, "--track", `${remoteName}/${branch}`], 30_000);
      }
      if (localExists.success) {
        const divergence = await runGitCommand(projectPath, ["rev-list", "--left-right", "--count", `${branch}...${remoteName}/${branch}`], 20_000);
        const { ahead, behind } = parseAheadBehind(divergence.stdout, branch);
        if (ahead > 0) {
          throw new Error(`Target ${branch} contains ${ahead} local commit(s) not present in origin; refusing to overwrite them`);
        }
        if (behind > 0) await runGitCommand(projectPath, ["merge", "--ff-only", `${remoteName}/${branch}`], 60_000);
      }
      const commit = (await runGitCommand(projectPath, ["rev-parse", "HEAD"], 20_000)).stdout;
      if (commit !== expectedCommit) throw new Error(`Target checkout verification failed: ${commit || "?"} != ${expectedCommit}`);
      const summary = `Target received ${branch}@${commit.slice(0, 12)} from ${remoteName}.`;
      appendLog(summary);
      persistLogs();
      return { phase, originUrl: remote.stdout, branch, commit, summary };
    }

    throw new Error(`Unsupported project handoff phase: ${phase}`);
  } catch (error) {
    appendLog(`Project handoff ${phase} failed: ${error?.message || String(error)}`);
    persistLogs();
    throw error;
  }
}

function persistDirectWorkspacePath(projectPath) {
  const normalizedPath = path.resolve(projectPath);
  if (normalizedPath.includes(";") || normalizedPath.includes(",") || /[\r\n]/.test(normalizedPath)) {
    throw new Error(`Project path contains an unsupported workspace separator: ${normalizedPath}`);
  }
  const envFile = path.resolve(__dirname, ".env");
  if (!fs.existsSync(envFile)) {
    return;
  }
  const lines = fs.readFileSync(envFile, "utf8").split(/\r?\n/);
  const configured = parseWorkspaceEnvList(
    lines.find((line) => line.startsWith("JARVIS_WORKSPACE_PATHS="))?.slice("JARVIS_WORKSPACE_PATHS=".length) || ""
  );
  const paths = Array.from(new Set([...configured, normalizedPath].map((item) => path.resolve(item))));
  const replacement = `JARVIS_WORKSPACE_PATHS=${paths.join(";")}`;
  let replaced = false;
  const updated = lines.map((line) => {
    if (line.startsWith("JARVIS_WORKSPACE_PATHS=")) {
      replaced = true;
      return replacement;
    }
    return line;
  });
  if (!replaced) updated.push(replacement);
  fs.writeFileSync(envFile, `${updated.join("\n").replace(/\n+$/, "")}\n`, "utf8");
  try { fs.chmodSync(envFile, 0o600); } catch (_error) {}
}

function writeRemoteProjectScaffold(projectPath, payload) {
  const projectName = String(payload.projectName || path.basename(projectPath) || "Jarvis project").trim();
  const userPrompt = String(payload.userPrompt || "").trim();
  const templateKey = String(payload.templateKey || "blank-app").trim() || "blank-app";
  const cleanupContext = payload.cleanupGeneratedContextFiles === true;
  const writeRelative = (relativePath, content) => {
    const target = path.resolve(projectPath, relativePath);
    const rootPrefix = `${path.resolve(projectPath)}${path.sep}`;
    if (!target.startsWith(rootPrefix)) {
      throw new Error(`Unsafe scaffold target: ${relativePath}`);
    }
    ensureDirectory(path.dirname(target));
    fs.writeFileSync(target, `${String(content).replace(/\s+$/, "")}\n`, "utf8");
  };

  writeRelative(".gitignore", ".idea/\n.gradle/\nbuild/\nnode_modules/\n.DS_Store\nlocal.properties\n*.iml");
  writeRelative("README.md", `# ${projectName}\n\nProyecto inicial generado por Jarvis en el agente remoto.\n\n## Prompt original\n${userPrompt}\n\n## Plantilla aplicada\n- ${templateKey}`);
  writeRelative("docs/product-prompt.md", `# Product Prompt\n\n${userPrompt}\n\nEste archivo es la fuente de verdad funcional para nuevas tareas.`);
  writeRelative("app/template-context.md", `# Template context\n\nTemplate key: ${templateKey}\nProject: ${projectName}`);

  if (!cleanupContext) {
    writeRelative("agent.md", `# Agent profile - ${projectName}\n\n1. Respeta docs/product-prompt.md.\n2. Entrega cambios incrementales y verificables.\n3. No rompas el build.\n4. Usa la plantilla ${templateKey}.`);
    writeRelative("Agents.md", `# Sub-agents - ${projectName}\n\n- agents/product-discovery-agent.md\n- agents/implementation-agent.md\n- agents/qa-release-agent.md`);
    writeRelative("CLAUDE.md", `# Claude profile - ${projectName}\n\nTrabaja con el mismo contexto funcional de agent.md y docs/product-prompt.md.`);
    writeRelative("agents/product-discovery-agent.md", "# Product Discovery Agent\n\nRefina requerimientos y propone un backlog priorizado.");
    writeRelative("agents/implementation-agent.md", "# Implementation Agent\n\nImplementa features en iteraciones pequenas y verificables.");
    writeRelative("agents/qa-release-agent.md", "# QA / Release Agent\n\nVerifica build, tests y checklist de release.");
    writeRelative("skills/intake-sdk-rollout/SKILL.md", "# Intake SDK Rollout\n\nIntegra el SDK de intake apropiado para Android o web y valida POST /tasks/intake.");
  }
}

async function executeRemoteCreateProject(commandPayload, commandLogDir) {
  const payload = parseCommandPayload(commandPayload?.payloadJson);
  const projectPathRaw = String(payload.projectPath || "").trim();
  if (!projectPathRaw) throw new Error("Command payload missing projectPath");
  if (!path.isAbsolute(projectPathRaw)) throw new Error(`Project path must be absolute: ${projectPathRaw}`);
  const normalizedProjectPath = path.resolve(projectPathRaw);
  if (fs.existsSync(normalizedProjectPath)) {
    throw new Error(`Target project path already exists: ${normalizedProjectPath}`);
  }

  const logs = [];
  const appendLog = (line) => logs.push(`[${new Date().toISOString()}] ${line}`);
  ensureDirectory(normalizedProjectPath);
  appendLog(`Created project directory ${normalizedProjectPath}`);
  try {
    const initMain = await runGitCommand(normalizedProjectPath, ["init", "-b", "main"], 30_000, true);
    if (!initMain.success) {
      await runGitCommand(normalizedProjectPath, ["init"], 30_000);
      await runGitCommand(normalizedProjectPath, ["checkout", "-b", "main"], 30_000, true);
    }
    appendLog("Initialized git repository on main branch.");
    writeRemoteProjectScaffold(normalizedProjectPath, payload);
    appendLog(`Wrote Jarvis scaffold template=${String(payload.templateKey || "blank-app")}.`);
    persistDirectWorkspacePath(normalizedProjectPath);
    appendLog("Persisted project in JARVIS_WORKSPACE_PATHS.");

    const workspaces = await collectWorkspacePayload();
    if (!workspaces.some((item) => path.resolve(item.absolutePath) === normalizedProjectPath)) {
      const gitInfo = await resolveWorkspaceGitInfo(normalizedProjectPath);
      workspaces.push({
        name: path.basename(normalizedProjectPath),
        absolutePath: normalizedProjectPath,
        os: process.platform,
        exists: true,
        worktreePath: gitInfo.worktreePath,
        gitRemoteUrl: gitInfo.gitRemoteUrl,
        gitBranch: gitInfo.gitBranch || "main",
      });
    }
    await reportAgentWorkspaces(workspaces);
    appendLog("Synchronized new workspace with Jarvis backend.");
  } catch (error) {
    appendLog(`Remote project creation failed: ${error?.message || String(error)}`);
    fs.writeFileSync(path.join(commandLogDir, "agent-command.log"), `${logs.join("\n")}\n`, "utf8");
    throw error;
  }

  const summary = `Remote project created at ${normalizedProjectPath}.`;
  appendLog(summary);
  fs.writeFileSync(path.join(commandLogDir, "agent-command.log"), `${logs.join("\n")}\n`, "utf8");
  return { summary, projectPath: normalizedProjectPath };
}

async function executeRemoteMergeTaskBranch(commandPayload, commandLogDir) {
  const payload = parseCommandPayload(commandPayload?.payloadJson);
  const projectPath = String(payload.projectPath || "").trim();
  const taskBranch = String(payload.taskBranch || "").trim();
  const baseBranch = String(payload.baseBranch || "main").trim() || "main";
  const remoteName = String(payload.remoteName || "origin").trim() || "origin";
  const deleteTaskBranch = payload.deleteTaskBranch !== false;

  if (!projectPath) {
    throw new Error("Command payload missing projectPath");
  }
  if (!taskBranch) {
    throw new Error("Command payload missing taskBranch");
  }

  const normalizedProjectPath = path.resolve(projectPath);
  if (!fs.existsSync(normalizedProjectPath)) {
    throw new Error(`Project path does not exist: ${normalizedProjectPath}`);
  }

  const logs = [];
  const appendLog = (line) => {
    logs.push(`[${new Date().toISOString()}] ${line}`);
  };

  await runGitCommand(normalizedProjectPath, ["rev-parse", "--is-inside-work-tree"]);
  appendLog(`Verified git repository at ${normalizedProjectPath}`);

  await runGitCommand(normalizedProjectPath, ["checkout", baseBranch]);
  appendLog(`Checked out base branch ${baseBranch}`);

  const remoteResult = await runGitCommand(
    normalizedProjectPath,
    ["remote", "get-url", remoteName],
    30_000,
    true
  );
  const hasRemote = remoteResult.success;
  if (hasRemote) {
    appendLog(`Remote ${remoteName} detected.`);
    const pullResult = await runGitCommand(
      normalizedProjectPath,
      ["pull", "--ff-only", remoteName, baseBranch],
      120_000,
      true
    );
    appendLog(
      pullResult.success
        ? `Pulled ${remoteName}/${baseBranch} successfully.`
        : `Pull failed/skipped for ${remoteName}/${baseBranch}: ${pullResult.output}`
    );
  } else {
    appendLog(`Remote ${remoteName} not configured. Merge will run locally only.`);
  }

  const mergeResult = await runGitCommand(
    normalizedProjectPath,
    ["merge", "--no-ff", "--no-edit", taskBranch],
    120_000,
    true
  );
  if (!mergeResult.success) {
    await runGitCommand(normalizedProjectPath, ["merge", "--abort"], 30_000, true);
    appendLog(`Merge failed and abort attempted: ${mergeResult.output}`);
    fs.writeFileSync(path.join(commandLogDir, "agent-command.log"), logs.join("\n") + "\n", "utf8");
    throw new Error(`Cannot merge '${taskBranch}' into '${baseBranch}': ${mergeResult.output}`);
  }
  appendLog(`Merged ${taskBranch} into ${baseBranch}`);

  if (hasRemote) {
    const pushResult = await runGitCommand(
      normalizedProjectPath,
      ["push", remoteName, baseBranch],
      180_000,
      true
    );
    if (!pushResult.success) {
      appendLog(`Push failed for ${remoteName}/${baseBranch}: ${pushResult.output}`);
      fs.writeFileSync(path.join(commandLogDir, "agent-command.log"), logs.join("\n") + "\n", "utf8");
      throw new Error(`Push failed for ${remoteName}/${baseBranch}: ${pushResult.output}`);
    }
    appendLog(`Pushed ${remoteName}/${baseBranch}`);
  }

  const taskId = String(commandPayload?.taskId || "").trim();
  if (taskId && TASK_WORKTREE_ENABLED) {
    const release = await releaseManagedTaskWorktree(normalizedProjectPath, taskId);
    appendLog(release.summary);
  }

  if (deleteTaskBranch) {
    const deleteResult = await runGitCommand(
      normalizedProjectPath,
      ["branch", "-d", taskBranch],
      30_000,
      true
    );
    appendLog(
      deleteResult.success
        ? `Deleted local branch ${taskBranch}`
        : `Local branch delete skipped/failed (${taskBranch}): ${deleteResult.output}`
    );
  }

  const summary = `Remote merge completed: ${taskBranch} -> ${baseBranch}${hasRemote ? ` (pushed to ${remoteName})` : " (local only)"}.`;
  appendLog(summary);
  fs.writeFileSync(path.join(commandLogDir, "agent-command.log"), logs.join("\n") + "\n", "utf8");
  return {
    summary,
    projectPath: normalizedProjectPath,
  };
}

function findDirectChildIgnoreCase(root, name, directory) {
  return fs.readdirSync(root, { withFileTypes: true }).find((entry) =>
    entry.name.toLowerCase() === name.toLowerCase() && (directory ? entry.isDirectory() : entry.isFile())
  ) || null;
}

async function executeRemoteProjectWorktreeCreate(payload) {
  const sourcePath = path.resolve(String(payload.projectPath || "").trim());
  const preferredBase = String(payload.preferredBaseBranch || "develop").trim() || "develop";
  const sourceName = path.basename(sourcePath);
  const targetPath = sourceName.toLowerCase().endsWith("-jarvis")
    ? sourcePath
    : path.resolve(path.dirname(sourcePath), `${sourceName}-jarvis`);

  const gitCheck = await runGitCommand(sourcePath, ["rev-parse", "--is-inside-work-tree"], 15_000, true);
  if (!gitCheck.success || gitCheck.output.trim().toLowerCase() !== "true") {
    throw new Error(`Source project is not a git repository: ${sourcePath}`);
  }

  await runGitCommand(sourcePath, ["fetch", "--prune", "origin", preferredBase], 60_000, true);
  const currentResult = await runGitCommand(sourcePath, ["rev-parse", "--abbrev-ref", "HEAD"], 15_000, true);
  const currentBranch = currentResult.success && currentResult.output.trim() !== "HEAD"
    ? currentResult.output.trim()
    : "";
  const branchCandidates = [preferredBase, currentBranch, "develop", "main", "master"]
    .map((value) => String(value || "").trim())
    .filter((value, index, values) => value && values.indexOf(value) === index);
  let selectedRef = "";
  let selectedBranch = preferredBase;
  let selectedSource = "";
  for (const branch of branchCandidates) {
    const local = await runGitCommand(sourcePath, ["show-ref", "--verify", "--quiet", `refs/heads/${branch}`], 10_000, true);
    if (local.success) {
      selectedRef = branch;
      selectedBranch = branch;
      selectedSource = "local branch";
      break;
    }
    const remote = await runGitCommand(sourcePath, ["show-ref", "--verify", "--quiet", `refs/remotes/origin/${branch}`], 10_000, true);
    if (remote.success) {
      selectedRef = `origin/${branch}`;
      selectedBranch = branch;
      selectedSource = "remote branch";
      break;
    }
  }
  if (!selectedRef) {
    const head = await runGitCommand(sourcePath, ["rev-parse", "--verify", "HEAD"], 10_000, true);
    if (!head.success) {
      throw new Error(`Cannot create worktree: repository has no commit/base branch (requested '${preferredBase}').`);
    }
    selectedRef = "HEAD";
    selectedBranch = currentBranch || preferredBase;
    selectedSource = "current HEAD";
  }

  const alreadyExists = fs.existsSync(targetPath);
  if (alreadyExists) {
    if (!fs.statSync(targetPath).isDirectory()) {
      throw new Error(`Target worktree path exists but is not a directory: ${targetPath}`);
    }
    const targetGitCheck = await runGitCommand(targetPath, ["rev-parse", "--is-inside-work-tree"], 15_000, true);
    if (!targetGitCheck.success) {
      throw new Error(`Target worktree path exists but is not a git repository: ${targetPath}`);
    }
  } else {
    const add = await runGitCommand(sourcePath, ["worktree", "add", "--detach", targetPath, selectedRef], 90_000, true);
    if (!add.success) {
      throw new Error(`Cannot create worktree from '${selectedRef}' (${selectedSource}): ${add.output}`);
    }
  }

  const localPropertiesSource = path.join(sourcePath, "local.properties");
  let localPropertiesSynced = false;
  if (fs.existsSync(localPropertiesSource)) {
    fs.copyFileSync(localPropertiesSource, path.join(targetPath, "local.properties"));
    localPropertiesSynced = true;
  }

  const restBranch = "rama_reposo_jarvis";
  const currentTarget = await runGitCommand(targetPath, ["rev-parse", "--abbrev-ref", "HEAD"], 15_000, true);
  let restReady = currentTarget.success && currentTarget.output.trim() === restBranch;
  let restOutput = restReady ? `Already on ${restBranch}` : "";
  if (!restReady) {
    const restExists = await runGitCommand(targetPath, ["show-ref", "--verify", "--quiet", `refs/heads/${restBranch}`], 10_000, true);
    if (restExists.success) {
      const checkout = await runGitCommand(targetPath, ["checkout", restBranch], 30_000, true);
      restReady = checkout.success;
      restOutput = checkout.output;
    }
  }
  if (!restReady) {
    for (const base of [selectedBranch, preferredBase, "develop", "main"].filter((value, index, values) => value && values.indexOf(value) === index)) {
      await runGitCommand(targetPath, ["fetch", "--prune", "origin", base], 60_000, true);
      const fromRemote = await runGitCommand(targetPath, ["checkout", "-b", restBranch, `origin/${base}`], 30_000, true);
      if (fromRemote.success) {
        restReady = true;
        restOutput = fromRemote.output;
        break;
      }
      const fromLocal = await runGitCommand(targetPath, ["checkout", "-b", restBranch, base], 30_000, true);
      if (fromLocal.success) {
        restReady = true;
        restOutput = fromLocal.output;
        break;
      }
    }
  }
  if (!restReady) {
    const fallback = await runGitCommand(targetPath, ["checkout", "-b", restBranch], 30_000, true);
    restReady = fallback.success;
    restOutput = fallback.output;
  }
  if (!restReady && !alreadyExists) {
    throw new Error(`Worktree created at ${targetPath}, but rest branch '${restBranch}' could not be prepared: ${restOutput}`);
  }

  const baseMessage = alreadyExists
    ? `Worktree already exists at ${targetPath}`
    : `Worktree created at ${targetPath}`;
  const fallbackMessage = selectedBranch !== preferredBase || selectedRef === "HEAD"
    ? ` | base '${preferredBase}' not found; used ${selectedSource} '${selectedBranch}'`
    : "";
  const propertiesMessage = localPropertiesSynced ? " | local.properties synced" : "";
  const restMessage = restReady
    ? ` | rest branch '${restBranch}' ready`
    : ` | warning: could not prepare rest branch '${restBranch}' (${restOutput})`;
  return {
    projectId: String(payload.projectId || ""),
    created: !alreadyExists,
    worktreePath: targetPath,
    message: `${baseMessage}${fallbackMessage}${propertiesMessage}${restMessage}`,
  };
}

async function executeRemoteProjectInspect(commandPayload, commandLogDir) {
  const payload = parseCommandPayload(commandPayload?.payloadJson);
  const operation = String(payload.operation || "").trim().toLowerCase();
  const projectPathRaw = String(payload.projectPath || "").trim();
  if (!operation) throw new Error("Inspection payload missing operation");
  if (!projectPathRaw) throw new Error("Inspection payload missing projectPath");
  const projectPath = path.resolve(projectPathRaw);
  if (!fs.existsSync(projectPath) || !fs.statSync(projectPath).isDirectory()) {
    throw new Error(`Project path does not exist: ${projectPath}`);
  }

  const contextFiles = ["agent.md", "Agents.md", "CLAUDE.md"];
  const contextDirectories = ["agents", "skills"];
  let result;

  if (operation === "worktree_create") {
    result = await executeRemoteProjectWorktreeCreate(payload);
    await syncAgentWorkspaces();
  } else if (operation === "context_cleanup_status") {
    const candidates = [
      ...contextFiles.map((name) => {
        const entry = findDirectChildIgnoreCase(projectPath, name, false);
        return { relativePath: entry?.name || name, kind: "file", exists: Boolean(entry) };
      }),
      ...contextDirectories.map((name) => {
        const entry = findDirectChildIgnoreCase(projectPath, name, true);
        return { relativePath: entry?.name || name, kind: "directory", exists: Boolean(entry) };
      }),
    ];
    const existingCount = candidates.filter((item) => item.exists).length;
    result = {
      projectId: String(payload.projectId || ""),
      hasContextFiles: existingCount > 0,
      candidates,
      message: existingCount === 0
        ? "No se detectaron ficheros de contexto copiado."
        : `Se detectaron ${existingCount} elemento(s) de contexto limpiable(s) en el agente remoto.`,
    };
  } else if (operation === "context_cleanup_delete") {
    const deleted = [];
    const skipped = [];
    const failed = [];
    for (const name of contextFiles) {
      const entry = findDirectChildIgnoreCase(projectPath, name, false);
      if (!entry) { skipped.push(name); continue; }
      try {
        fs.unlinkSync(path.join(projectPath, entry.name));
        deleted.push(entry.name);
      } catch (error) { failed.push(`${entry.name}: ${error.message}`); }
    }
    for (const name of contextDirectories) {
      const entry = findDirectChildIgnoreCase(projectPath, name, true);
      if (!entry) { skipped.push(name); continue; }
      try {
        const target = path.join(projectPath, entry.name);
        if (path.dirname(target) !== projectPath) throw new Error(`Unsafe cleanup target: ${target}`);
        fs.rmSync(target, { recursive: true, force: false });
        deleted.push(`${entry.name}/`);
      } catch (error) { failed.push(`${entry.name}/: ${error.message}`); }
    }
    result = {
      projectId: String(payload.projectId || ""), deleted, skipped, failed,
      message: failed.length === 0
        ? `Contexto copiado eliminado en agente remoto: ${deleted.length} elemento(s).`
        : `Limpieza remota parcial: ${deleted.length} eliminado(s), ${failed.length} fallo(s).`,
    };
  } else if (operation === "git_overview") {
    await runGitCommand(projectPath, ["rev-parse", "--is-inside-work-tree"]);
    const current = await runGitCommand(projectPath, ["rev-parse", "--abbrev-ref", "HEAD"], 15_000, true);
    const originHead = await runGitCommand(projectPath, ["symbolic-ref", "--quiet", "--short", "refs/remotes/origin/HEAD"], 15_000, true);
    const defaultBranch = originHead.success
      ? originHead.output.trim().replace(/^origin\//, "")
      : ["main", "master", "develop"].find((candidate) =>
          fs.existsSync(path.join(projectPath, ".git", "refs", "heads", candidate))) || current.output.trim();
    const refs = await runGitCommand(projectPath, [
      "for-each-ref",
      "--format=%(refname:short)%00%(upstream:short)%00%(upstream:track)%00%(committerdate:iso-strict)%00%(objectname:short)%00%(subject)",
      "refs/heads/",
    ], 20_000, true);
    const branches = refs.success ? refs.output.split(/\r?\n/).filter(Boolean).map((line) => {
      const [name = "", upstream = "", upstreamTrack = "", lastCommitAt = "", lastCommitHashShort = "", subject = ""] = line.split("\0");
      return {
        name, upstream, upstreamTrack, lastCommitAt, lastCommitHashShort, subject,
        staleDays: -1, mergedToHead: name === current.output.trim(), mergedToDefault: name === defaultBranch,
        aheadOfDefault: null, behindDefault: null,
      };
    }) : [];
    result = {
      projectId: String(payload.projectId || ""), repositoryPath: projectPath, executionPath: projectPath,
      currentBranch: current.success ? current.output.trim() : null,
      defaultBranch: defaultBranch || null, generatedAt: new Date().toISOString(),
      cleanupConfirmationPhrase: `CLEAN ${path.basename(projectPath).toUpperCase()}`,
      branches, worktrees: [], cleanupSuggestions: [], warning: refs.success ? null : refs.output,
    };
  } else if (operation === "code_changes") {
    await runGitCommand(projectPath, ["rev-parse", "--is-inside-work-tree"]);
    const branchName = String(payload.branchName || "HEAD").trim() || "HEAD";
    const preferredBase = String(payload.targetBaseBranch || "").trim();
    const candidates = [preferredBase, preferredBase ? `origin/${preferredBase}` : "", "origin/main", "main", "origin/master", "master", "origin/develop", "develop"].filter(Boolean);
    let baseRef = "";
    for (const candidate of candidates) {
      const exists = await runGitCommand(projectPath, ["rev-parse", "--verify", "--quiet", `${candidate}^{commit}`], 10_000, true);
      if (exists.success) { baseRef = candidate; break; }
    }
    const contextLines = Math.max(0, Math.min(20, Number(payload.contextLines) || 3));
    let compareRef = branchName;
    let diffText = "";
    if (baseRef) {
      const branchDiff = await runGitCommand(projectPath, ["diff", `--unified=${contextLines}`, "--find-renames", "--no-ext-diff", "--no-color", `${baseRef}...${branchName}`, "--", "."], 30_000, true);
      if (branchDiff.success) diffText = branchDiff.output;
    }
    if (!diffText.trim()) {
      const taskId = String(payload.taskId || "").trim();
      const commits = taskId ? await runGitCommand(projectPath, ["log", "--reverse", "--fixed-strings", `--grep=${taskId}`, "--format=%H", branchName, "--"], 20_000, true) : null;
      const hashes = commits?.success ? commits.output.split(/\s+/).filter((value) => /^[0-9a-f]{40}$/i.test(value)) : [];
      if (hashes.length) {
        const first = hashes[0];
        const last = hashes[hashes.length - 1];
        const parent = await runGitCommand(projectPath, ["rev-parse", "--verify", "--quiet", `${first}^`], 10_000, true);
        baseRef = parent.success ? `${first}^` : first;
        compareRef = last;
        const commitDiff = await runGitCommand(projectPath, ["diff", `--unified=${contextLines}`, "--find-renames", "--no-ext-diff", "--no-color", `${baseRef}..${last}`, "--", "."], 30_000, true);
        if (commitDiff.success) diffText = commitDiff.output;
      }
    }
    if (!diffText.trim()) {
      const working = await runGitCommand(projectPath, ["diff", `--unified=${contextLines}`, "--find-renames", "--no-ext-diff", "--no-color", "HEAD", "--", "."], 30_000, true);
      if (working.success) diffText = working.output;
    }
    result = {
      taskId: String(payload.taskId || ""), projectId: String(payload.projectId || ""), branchName,
      baseRef: baseRef || null, compareRef, available: true,
      summary: diffText.trim() ? "Cambios Git leidos en el agente remoto." : "No se encontraron cambios Git en el agente remoto.",
      diffText,
    };
  } else {
    throw new Error(`Unsupported remote inspection operation: ${operation}`);
  }

  fs.writeFileSync(path.join(commandLogDir, "agent-command.log"), `${JSON.stringify(result, null, 2)}\n`, "utf8");
  return result;
}

async function processAgentCommand(commandPayload) {
  const command = commandPayload || {};
  const commandId = String(command.id || "").trim();
  const commandType = String(command.commandType || "").trim().toUpperCase();
  if (!commandId) {
    throw new Error("Invalid command payload: missing command id");
  }
  if (!commandType) {
    throw new Error(`Invalid command payload ${commandId}: missing commandType`);
  }

  const commandLogDir = path.join(LOG_DIR, "commands", sanitizeFileComponent(commandId));
  ensureDirectory(commandLogDir);

  setRuntimeStatus(RuntimeState.WORKING, {
    commandId,
    action: `Ejecutando comando ${commandType}`,
  });
  console.log(`[agent] processing command=${commandId} type=${commandType}`);

  try {
    let summary = "";
    if (commandType === "REMOTE_MERGE_TASK_BRANCH") {
      const result = await executeRemoteMergeTaskBranch(command, commandLogDir);
      summary = result.summary;
    } else if (commandType === "REMOTE_CREATE_PROJECT") {
      const result = await executeRemoteCreateProject(command, commandLogDir);
      summary = result.summary;
    } else if (commandType === "REMOTE_PROJECT_INSPECT") {
      const result = await executeRemoteProjectInspect(command, commandLogDir);
      summary = JSON.stringify(result);
    } else if (commandType === "REMOTE_PROJECT_HANDOFF") {
      const result = await executeRemoteProjectHandoff(command, commandLogDir);
      summary = JSON.stringify(result);
    } else {
      throw new Error(`Unsupported command type: ${commandType}`);
    }

    await completeAgentCommand(commandId, true, summary, null);
    console.log(`[agent] command=${commandId} completed successfully`);
  } catch (error) {
    const errText = clipText(error?.message || String(error), 2000);
    const fallbackSummary = `Command ${commandType} failed: ${errText}`;
    try {
      await completeAgentCommand(commandId, false, fallbackSummary, errText);
    } catch (completeError) {
      console.error(`[agent] command=${commandId} completion callback failed: ${completeError.message}`);
    }
    console.error(`[agent] command=${commandId} failed: ${errText}`);
  }
}

function readOutputFileSignature(filePath) {
  if (!filePath) return null;
  try {
    const stat = fs.statSync(filePath);
    return stat.isFile() ? { mtimeMs: stat.mtimeMs, size: stat.size } : null;
  } catch (_ignored) {
    return null;
  }
}

function sameOutputFileSignature(left, right) {
  return Boolean(left && right && left.mtimeMs === right.mtimeMs && left.size === right.size);
}

function runCodexCommand({
  executable = "codex",
  args,
  cwd,
  timeoutMs,
  stdinText,
  env,
  outputFile,
  outputStallTimeoutMs,
  liveLogFile,
  spawnProcess = spawn,
}) {
  return new Promise((resolve, reject) => {
    const initialOutput = readOutputFileSignature(outputFile);
    const commandSpec = buildExecutableCommand(executable, args);
    const child = spawnProcess(commandSpec.command, commandSpec.args, {
      cwd,
      env,
      stdio: ["pipe", "pipe", "pipe"],
      detached: !IS_WINDOWS,
    });
    appendFileSafe(liveLogFile, `[jarvis-runtime] Codex process started pid=${child.pid} @ ${new Date().toISOString()}\n`);

    let stdout = "";
    let stderr = "";
    let timedOut = false;
    let stalledAfterOutput = false;
    let lastOutputMtime = 0;
    let lastOutputMutationAt = 0;
    let outputSeen = false;
    let settled = false;
    let forceKillTimer = null;
    let terminationPromise = null;
    const timeoutEnabled = Number.isFinite(timeoutMs) && timeoutMs > 0;
    const stallEnabled = Number.isFinite(outputStallTimeoutMs) && outputStallTimeoutMs > 0;

    const finish = (payload) => {
      if (settled) return;
      settled = true;
      if (hardTimer) clearTimeout(hardTimer);
      if (stallTimer) clearInterval(stallTimer);
      if (forceKillTimer) {
        clearTimeout(forceKillTimer);
        forceKillTimer = null;
      }
      resolve(payload);
    };

    const scheduleForcedResolve = (termination) => {
      if (forceKillTimer || settled) return;
      forceKillTimer = setTimeout(() => {
        finish({
          code: null,
          stdout,
          stderr: `${stderr}\nCodex tree was terminated but the wrapper did not emit close.`.trim(),
          timedOut,
          stalledAfterOutput,
          forcedExit: true,
          processTreeTerminated: termination.verified,
          terminationReason: termination.reason,
        });
      }, PROCESS_FORCE_KILL_GRACE_MS);
    };

    const beginTermination = (reason) => {
      if (terminationPromise) return terminationPromise;
      appendFileSafe(liveLogFile, `\n[jarvis-watchdog] ${reason}; terminating complete process tree pid=${child.pid}.\n`);
      terminationPromise = terminateChildProcessTree(child).then((termination) => {
        if (!termination.verified) {
          finish({
            code: null,
            stdout,
            stderr: `${stderr}\nUnable to verify Codex process-tree termination: ${termination.reason}`.trim(),
            timedOut,
            stalledAfterOutput,
            forcedExit: true,
            processTreeTerminated: false,
            terminationReason: termination.reason,
          });
        } else {
          scheduleForcedResolve(termination);
        }
        return termination;
      });
      return terminationPromise;
    };

    const hardTimer = timeoutEnabled ? setTimeout(() => {
      timedOut = true;
      void beginTermination(`hard timeout after ${timeoutMs}ms`);
    }, timeoutMs) : null;

    const stallPollMs = Math.min(5_000, Math.max(25, Math.floor(outputStallTimeoutMs / 4) || 5_000));
    const stallTimer = stallEnabled ? setInterval(() => {
      if (!outputFile) {
        return;
      }
      try {
        const stat = fs.statSync(outputFile);
        if (!stat.isFile()) {
          return;
        }
        if (!outputSeen) {
          const signature = { mtimeMs: stat.mtimeMs, size: stat.size };
          if (sameOutputFileSignature(initialOutput, signature)) {
            return;
          }
          outputSeen = true;
          lastOutputMtime = stat.mtimeMs;
          lastOutputMutationAt = Date.now();
          return;
        }
        if (stat.mtimeMs !== lastOutputMtime) {
          lastOutputMtime = stat.mtimeMs;
          lastOutputMutationAt = Date.now();
          return;
        }
        if (lastOutputMutationAt > 0 && (Date.now() - lastOutputMutationAt) >= outputStallTimeoutMs) {
          stalledAfterOutput = true;
          void beginTermination(`final output unchanged for ${outputStallTimeoutMs}ms`);
        }
      } catch (_ignored) {
        // output file still not present or not readable yet
      }
    }, stallPollMs) : null;

    child.stdout.on("data", (chunk) => {
      const text = chunk.toString();
      stdout += text;
      if (liveLogFile) {
        appendFileSafe(liveLogFile, text);
      }
    });

    child.stderr.on("data", (chunk) => {
      const text = chunk.toString();
      stderr += text;
      if (liveLogFile) {
        appendFileSafe(liveLogFile, text);
      }
    });

    child.on("error", (error) => {
      finish({
        code: typeof error.errno === "number" ? error.errno : 127,
        stdout,
        stderr: error.message || String(error),
        timedOut,
        stalledAfterOutput,
        spawnError: error,
      });
    });

    child.on("close", async (code) => {
      const termination = terminationPromise ? await terminationPromise : null;
      appendFileSafe(
        liveLogFile,
        `[jarvis-runtime] Codex process closed pid=${child.pid} code=${code} treeVerified=${termination?.verified ?? true} @ ${new Date().toISOString()}\n`
      );
      finish({
        code,
        stdout,
        stderr,
        timedOut,
        stalledAfterOutput,
        processTreeTerminated: termination?.verified ?? !(timedOut || stalledAfterOutput),
        terminationReason: termination?.reason || null,
      });
    });

    if (stdinText !== null && stdinText !== undefined) {
      child.stdin.write(stdinText);
    }
    child.stdin.end();
  });
}

function appendFileSafe(filePath, text) {
  if (!filePath || !text) return;
  try {
    fs.appendFileSync(filePath, text, "utf8");
  } catch (_ignored) {
    // best effort only
  }
}

function runtimeLogFilePriority(fileName) {
  const name = String(fileName || "").toLowerCase();
  if (name === "runtime.log") return 0;
  if (name.includes("stdout") || name.includes("attempts") || name.includes("opencode-live")) return 1;
  if (name.includes("lmstudio")) return 2;
  if (name.includes("gradle")) return 3;
  if (name === "agent-summary.log") return 4;
  return 9;
}

function listLiveRuntimeLogFiles(taskLogDir) {
  const files = [];
  const queue = [taskLogDir];
  while (queue.length > 0) {
    const current = queue.shift();
    let entries = [];
    try {
      entries = fs.readdirSync(current, { withFileTypes: true });
    } catch (_ignored) {
      continue;
    }
    for (const entry of entries) {
      const fullPath = path.join(current, entry.name);
      if (entry.isDirectory()) {
        queue.push(fullPath);
        continue;
      }
      if (!entry.isFile()) continue;
      const priority = runtimeLogFilePriority(entry.name);
      if (priority < 9) files.push({ fullPath, priority });
    }
  }
  return files.sort((a, b) => {
    if (a.priority !== b.priority) return a.priority - b.priority;
    return a.fullPath.localeCompare(b.fullPath);
  });
}

function readUtf8FileTail(filePath, maxBytes) {
  try {
    const stat = fs.statSync(filePath);
    const size = Math.max(0, Number(stat.size || 0));
    const length = Math.min(size, maxBytes);
    if (length <= 0) return { text: "", size, truncated: false, mtime: stat.mtime.toISOString() };
    const buffer = Buffer.alloc(length);
    const fd = fs.openSync(filePath, "r");
    try {
      fs.readSync(fd, buffer, 0, length, size - length);
    } finally {
      fs.closeSync(fd);
    }
    return {
      text: buffer.toString("utf8"),
      size,
      truncated: size > length,
      mtime: stat.mtime.toISOString(),
    };
  } catch (_ignored) {
    return null;
  }
}

function buildRuntimeLogSnapshot(taskId, taskLogDir) {
  const files = listLiveRuntimeLogFiles(taskLogDir);
  const perFileMax = Math.max(32_000, Math.floor(RUNTIME_LOG_SNAPSHOT_MAX_CHARS / Math.max(1, files.length)));
  let content = [
    "=== Jarvis · actividad del agente en directo ===",
    `Task: ${taskId}`,
    `Agente: ${AGENT_DISPLAY_NAME} (${AGENT_ID})`,
    ""
  ].join("\n");
  for (const file of files) {
    const snapshot = readUtf8FileTail(file.fullPath, perFileMax);
    if (!snapshot) continue;
    const relative = path.relative(taskLogDir, file.fullPath) || path.basename(file.fullPath);
    content += `\n===== ${relative} · ${snapshot.size} bytes · ${snapshot.mtime}${snapshot.truncated ? " · tail" : ""} =====\n`;
    content += `${snapshot.text.trimEnd()}\n`;
  }
  if (content.length > RUNTIME_LOG_SNAPSHOT_MAX_CHARS) {
    content = `[Jarvis] Snapshot truncado; mostrando la actividad más reciente.\n\n${content.slice(-RUNTIME_LOG_SNAPSHOT_MAX_CHARS)}`;
  }
  return content;
}

function normalizeAdbPolicy(value) {
  const normalized = String(value || "").trim().toUpperCase().replace(/[-\s]+/g, "_");
  return ["DISABLED", "EMULATOR_ONLY", "ALLOWLIST"].includes(normalized) ? normalized : "DISABLED";
}

function resolvePathValue(env) {
  const key = Object.keys(env || {}).find((candidate) => candidate.toLowerCase() === "path");
  return { key: key || "PATH", value: String((env || {})[key || "PATH"] || "") };
}

function resolveRealAdbExecutable(env = process.env) {
  const candidates = [];
  const sdkRoot = String(env.ANDROID_SDK_ROOT || env.ANDROID_HOME || "").trim();
  if (sdkRoot) candidates.push(path.join(sdkRoot, "platform-tools", IS_WINDOWS ? "adb.exe" : "adb"));
  const { value: pathValue } = resolvePathValue(env);
  for (const entry of pathValue.split(path.delimiter).filter(Boolean)) {
    candidates.push(path.join(entry, IS_WINDOWS ? "adb.exe" : "adb"));
  }
  return candidates.find((candidate) => {
    try { return fs.statSync(candidate).isFile(); } catch (_ignored) { return false; }
  }) || "";
}

function powershellSingleQuoted(value) {
  return `'${String(value || "").replace(/'/g, "''")}'`;
}

function createAdbPolicyShim(taskLogDir, options = {}) {
  const policy = normalizeAdbPolicy(options.policy || ADB_POLICY);
  const allowedSerial = String(options.allowedSerial ?? ADB_ALLOWED_SERIAL).trim();
  const realAdb = String(options.realAdb || "").trim();
  const shimDir = path.join(taskLogDir, "device-policy-bin");
  ensureDirectory(shimDir);

  if (IS_WINDOWS) {
    const ps1Path = path.join(shimDir, "adb-policy.ps1");
    const cmdPath = path.join(shimDir, "adb.cmd");
    const script = [
      "$ErrorActionPreference = 'Stop'",
      `$policy = ${powershellSingleQuoted(policy)}`,
      `$allowedSerial = ${powershellSingleQuoted(allowedSerial)}`,
      `$realAdb = ${powershellSingleQuoted(realAdb)}`,
      "if ($policy -eq 'DISABLED') { Write-Error 'ADB blocked by Jarvis policy (DISABLED).'; exit 126 }",
      "if (-not $realAdb -or -not (Test-Path -LiteralPath $realAdb)) { Write-Error 'ADB executable not found before Jarvis installed its policy shim.'; exit 127 }",
      "if ($args -contains '-s' -or $args -contains '--serial') { Write-Error 'Bare device selection is blocked; Jarvis injects the audited serial.'; exit 126 }",
      "$serial = $allowedSerial",
      "if ($policy -eq 'EMULATOR_ONLY') {",
      "  if ($serial -and -not $serial.StartsWith('emulator-')) { Write-Error 'Configured ADB serial is not an emulator.'; exit 126 }",
      "  if (-not $serial) {",
      "    $deviceLines = @(& $realAdb devices | Select-String -Pattern '^emulator-[^\\s]+\\s+device$' | ForEach-Object { $_.Line })",
      "    if ($deviceLines.Count -ne 1) { Write-Error \"EMULATOR_ONLY requires exactly one online emulator; found $($deviceLines.Count).\"; exit 126 }",
      "    $serial = ($deviceLines[0] -split '\\s+')[0]",
      "  }",
      "}",
      "if ($policy -eq 'ALLOWLIST' -and -not $serial) { Write-Error 'ALLOWLIST requires JARVIS_ADB_ALLOWED_SERIAL.'; exit 126 }",
      "& $realAdb -s $serial @args",
      "exit $LASTEXITCODE",
      "",
    ].join("\r\n");
    fs.writeFileSync(ps1Path, script, "utf8");
    fs.writeFileSync(cmdPath, `@echo off\r\npowershell.exe -NoProfile -ExecutionPolicy Bypass -File "${ps1Path}" %*\r\nexit /b %ERRORLEVEL%\r\n`, "utf8");
    return { policy, allowedSerial, shimDir, executable: cmdPath, realAdb };
  }

  const shimPath = path.join(shimDir, "adb");
  const shell = policy === "DISABLED"
    ? "#!/bin/sh\necho 'ADB blocked by Jarvis policy (DISABLED).' >&2\nexit 126\n"
    : `#!/bin/sh\necho 'Jarvis ${policy} ADB shim is not configured on this platform.' >&2\nexit 126\n`;
  fs.writeFileSync(shimPath, shell, { encoding: "utf8", mode: 0o755 });
  return { policy, allowedSerial, shimDir, executable: shimPath, realAdb };
}

function applyAdbPolicyToCodexEnv(env, taskLogDir, options = {}) {
  const realAdb = options.realAdb ?? resolveRealAdbExecutable(env);
  const shim = createAdbPolicyShim(taskLogDir, { ...options, realAdb });
  prependExecutablePath(env, shim.shimDir);
  env.JARVIS_ADB_POLICY = shim.policy;
  env.JARVIS_ADB_ALLOWED_SERIAL = shim.allowedSerial;
  if (shim.allowedSerial) env.ANDROID_SERIAL = shim.allowedSerial;
  else if (shim.policy === "EMULATOR_ONLY") env.ANDROID_SERIAL = "__JARVIS_EMULATOR_REQUIRED__";
  else env.ANDROID_SERIAL = "__JARVIS_ADB_DISABLED__";
  return shim;
}

function buildAdbPolicyPrompt(policy = ADB_POLICY, allowedSerial = ADB_ALLOWED_SERIAL) {
  const normalized = normalizeAdbPolicy(policy);
  if (normalized === "DISABLED") {
    return "Jarvis device policy: ADB is disabled. Do not invoke adb, interact with connected devices, change device settings, or perform physical-device QA.";
  }
  if (normalized === "EMULATOR_ONLY") {
    return `Jarvis device policy: ADB may target only the audited emulator${allowedSerial ? ` ${allowedSerial}` : " selected by Jarvis"}. Never target a physical device or pass -s/--serial yourself.`;
  }
  return `Jarvis device policy: ADB may target only explicitly allowed serial ${allowedSerial || "(missing: do not use ADB)"}. Never select another device or pass -s/--serial yourself.`;
}

function normalizeCodexSandboxMode(value) {
  const normalized = String(value || "").trim().toLowerCase();
  return ["read-only", "workspace-write"].includes(normalized) ? normalized : "workspace-write";
}

function buildCodexSecurityArgs(options = {}) {
  const sandboxMode = normalizeCodexSandboxMode(options.sandboxMode || CODEX_SANDBOX_MODE);
  return ["--sandbox", sandboxMode, "--config", `approval_policy=${toTomlBasicString(CODEX_APPROVAL_POLICY)}`];
}

function startRuntimeLogSync(taskId, taskLogDir) {
  let lastUploaded = null;
  let inFlight = null;
  const sync = (force = false) => {
    if (inFlight) {
      return force ? inFlight.then(() => sync(true)) : inFlight;
    }
    inFlight = (async () => {
      const content = buildRuntimeLogSnapshot(taskId, taskLogDir);
      if (!force && content === lastUploaded) return;
      await uploadRuntimeLogSnapshot(taskId, content);
      lastUploaded = content;
    })().catch((error) => {
      console.warn(`[agent] runtime log sync failed task=${taskId}: ${error.message}`);
    }).finally(() => {
      inFlight = null;
    });
    return inFlight;
  };
  const timer = setInterval(() => { void sync(false); }, RUNTIME_LOG_SYNC_MS);
  void sync(true);
  return {
    flush: () => sync(true),
    stop: async () => {
      clearInterval(timer);
      await sync(true);
    }
  };
}

function buildCodexChildEnv(apiKey, llmRuntimeConfig = null) {
  const env = { ...process.env };
  if (CODEX_SANITIZE_DESKTOP_ENV) {
    Object.keys(env).forEach((key) => {
      if (key.startsWith("CODEX_")) {
        delete env[key];
      }
    });
  }
  const provider = String(llmRuntimeConfig?.provider || "OPENAI").toUpperCase();
  if (isLocalOssProvider(provider)) {
    delete env.OPENAI_API_KEY;
    delete env.OPENAI_BASE_URL;
    delete env.OPENAI_API_BASE;
    delete env.OPENAI_ORG_ID;
    delete env.OPENAI_PROJECT;
    env.CODEX_OSS = "true";
    env.CODEX_LOCAL_PROVIDER = resolveLocalOssProvider(provider, llmRuntimeConfig?.localProvider);
  } else if (apiKey) {
    env.OPENAI_API_KEY = apiKey;
  }
  return env;
}

function buildClaudeChildEnv(claudeRuntimeConfig, account = null) {
  const env = { ...process.env };
  const runtime = normalizeClaudeRuntimeConfig(claudeRuntimeConfig || {});
  const authMode = account?.authMode || runtime.authMode;
  const tokenFromAccount = String(account?.token || "").trim();
  const runtimeApiKey = String(runtime.apiKey || "").trim();
  const runtimeAuthToken = String(runtime.authToken || "").trim();

  delete env.OPENAI_API_KEY;
  delete env.CODEX_OSS;
  delete env.CODEX_LOCAL_PROVIDER;
  delete env.ANTHROPIC_API_KEY;
  delete env.ANTHROPIC_AUTH_TOKEN;
  delete env.ANTHROPIC_MODEL;

  if (runtime.baseUrl) {
    env.ANTHROPIC_BASE_URL = runtime.baseUrl;
  }

  const finalModel = runtime.model || CLAUDE_MODEL;
  if (finalModel) {
    env.ANTHROPIC_MODEL = finalModel;
  }

  if (authMode === "GATEWAY") {
    const authToken = tokenFromAccount || runtimeAuthToken;
    if (authToken) {
      env.ANTHROPIC_AUTH_TOKEN = authToken;
    }
  } else if (authMode === "LOCAL_AGENT") {
    // Intentionally leave auth env empty so Claude CLI uses local logged-in session credentials.
  } else {
    const apiKey = tokenFromAccount || runtimeApiKey;
    if (apiKey) {
      env.ANTHROPIC_API_KEY = apiKey;
    }
  }

  return env;
}

function parseClaudeJsonOutput(rawStdout, rawStderr) {
  const combined = [String(rawStdout || ""), String(rawStderr || "")]
    .filter(Boolean)
    .join("\n");
  const lines = combined.split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
  for (let index = lines.length - 1; index >= 0; index -= 1) {
    const line = lines[index];
    if (!line.startsWith("{") || !line.endsWith("}")) {
      continue;
    }
    try {
      const parsed = JSON.parse(line);
      if (parsed && typeof parsed === "object") {
        return parsed;
      }
    } catch (_ignored) {
      // ignore and continue with previous lines
    }
  }
  return null;
}

function isClaudeMaxTurnsResult(parsed) {
  const subtype = String(parsed?.subtype || "").toLowerCase();
  const terminalReason = String(parsed?.terminal_reason || "").toLowerCase();
  const stopReason = String(parsed?.stop_reason || "").toLowerCase();
  const errors = Array.isArray(parsed?.errors) ? parsed.errors.map((item) => String(item || "").toLowerCase()) : [];
  return (
    subtype === "error_max_turns"
    || terminalReason === "max_turns"
    || stopReason === "max_turns"
    || errors.some((item) => item.includes("reached maximum number of turns"))
  );
}

function formatClaudeMaxTurnsError(parsed) {
  const turns = parsed?.num_turns ?? parsed?.turnCount ?? CLAUDE_MAX_TURNS;
  const durationSeconds = Number.isFinite(Number(parsed?.duration_ms))
    ? Math.round(Number(parsed.duration_ms) / 1000)
    : null;
  const cost = Number.isFinite(Number(parsed?.total_cost_usd))
    ? Number(parsed.total_cost_usd).toFixed(4)
    : null;
  return [
    `AGENT_TURN_LIMIT: Claude reached Jarvis' safety limit of ${CLAUDE_MAX_TURNS} steps/turns before finishing.`,
    `Observed turns: ${turns}.`,
    durationSeconds != null ? `Duration: ${durationSeconds}s.` : null,
    cost != null ? `Cost: $${cost}.` : null,
    "This means Claude was working, but the bootstrap was too large for one run. Resume the task, split the execution profile into smaller steps, or increase JARVIS_CLAUDE_MAX_TURNS.",
  ].filter(Boolean).join(" ");
}

async function gitStatusPorcelain(projectPath) {
  const result = await runExecutableCommand({
    executable: "git",
    args: ["status", "--porcelain"],
    cwd: projectPath,
    timeoutMs: 20_000,
  });
  if (result.code !== 0) {
    throw new Error(`git status failed: ${clipText(result.stderr || result.stdout, 800)}`);
  }
  return (result.stdout || "").trim();
}

async function ensureLocalGitExclude(projectPath) {
  if (GIT_LOCAL_EXCLUDE_PATTERNS.length === 0) {
    return;
  }

  const gitPathResult = await runExecutableCommand({
    executable: "git",
    args: ["rev-parse", "--git-path", "info/exclude"],
    cwd: projectPath,
    timeoutMs: 20_000,
  });
  if (gitPathResult.code !== 0) {
    return;
  }

  const rawPath = (gitPathResult.stdout || "").trim();
  if (!rawPath) {
    return;
  }
  const excludePath = path.isAbsolute(rawPath) ? rawPath : path.join(projectPath, rawPath);
  ensureDirectory(path.dirname(excludePath));

  const existing = fs.existsSync(excludePath)
    ? fs.readFileSync(excludePath, "utf8")
    : "";
  const normalized = existing.replace(/\r\n/g, "\n");
  const lines = normalized.split("\n").map((line) => line.trim());
  const missing = GIT_LOCAL_EXCLUDE_PATTERNS.filter((pattern) => !lines.includes(pattern));

  if (missing.length === 0) {
    return;
  }

  const prefix = normalized.length > 0 && !normalized.endsWith("\n") ? "\n" : "";
  const block = [
    "# jarvis-agent local excludes",
    ...missing,
  ].join("\n");
  fs.writeFileSync(excludePath, `${normalized}${prefix}${block}\n`, "utf8");
}

async function configureGitIdentity(projectPath) {
  if (!GIT_USER_NAME && !GIT_USER_EMAIL) {
    return;
  }
  if (GIT_USER_NAME) {
    await runExecutableCommand({
      executable: "git",
      args: ["config", "user.name", GIT_USER_NAME],
      cwd: projectPath,
      timeoutMs: 20_000,
    });
  }
  if (GIT_USER_EMAIL) {
    await runExecutableCommand({
      executable: "git",
      args: ["config", "user.email", GIT_USER_EMAIL],
      cwd: projectPath,
      timeoutMs: 20_000,
    });
  }
}

function looksLikeMissingGhAuth(text) {
  const raw = (text || "").toLowerCase();
  return raw.includes("not logged into any github hosts") || raw.includes("authentication required");
}

async function createOrGetPullRequest(projectPath, task, taskId) {
  if (!GIT_AUTO_PR) {
    return "PR auto-create skipped (JARVIS_GIT_AUTO_PR=false).";
  }

  const ghVersion = await runExecutableCommand({
    executable: "gh",
    args: ["--version"],
    cwd: projectPath,
    timeoutMs: 20_000,
  });
  if (ghVersion.code !== 0) {
    return "PR auto-create skipped (`gh` not installed in PATH).";
  }

  const ghToken = process.env.GH_TOKEN || process.env.JARVIS_GITHUB_TOKEN || "";
  const ghEnv = ghToken
    ? { ...process.env, GH_TOKEN: ghToken }
    : { ...process.env };

  const listPr = await runExecutableCommand({
    executable: "gh",
    args: ["pr", "list", "--head", task.branchName, "--base", GIT_PR_BASE, "--state", "open", "--json", "url", "--limit", "1"],
    cwd: projectPath,
    timeoutMs: 60_000,
    env: ghEnv,
  });
  if (listPr.code !== 0) {
    const details = clipText(listPr.stderr || listPr.stdout, 800);
    if (looksLikeMissingGhAuth(details)) {
      return "PR auto-create skipped (GH auth missing; set GH_TOKEN or JARVIS_GITHUB_TOKEN).";
    }
    return `PR auto-create skipped (cannot list PRs): ${details}`;
  }

  try {
    const parsed = JSON.parse(listPr.stdout || "[]");
    if (Array.isArray(parsed) && parsed.length > 0 && parsed[0]?.url) {
      return `PR already open: ${parsed[0].url}`;
    }
  } catch (_ignored) {
    // continue to creation
  }

  const title = `[Jarvis] ${task.title}`;
  const body = [
    "Automated PR created by Jarvis agent.",
    "",
    `- Task: ${taskId}`,
    `- Iteration: ${task.iteration}`,
    `- Branch: ${task.branchName}`,
    "",
    "Post-PR policy: Claude review/refactor gate runs before manual merge to main.",
  ].join("\n");

  const createArgs = ["pr", "create", "--base", GIT_PR_BASE, "--head", task.branchName, "--title", title, "--body", body];
  if (GIT_PR_DRAFT) {
    createArgs.push("--draft");
  }

  const createPr = await runExecutableCommand({
    executable: "gh",
    args: createArgs,
    cwd: projectPath,
    timeoutMs: 90_000,
    env: ghEnv,
  });
  if (createPr.code !== 0) {
    const details = clipText(createPr.stderr || createPr.stdout, 1000);
    if (looksLikeMissingGhAuth(details)) {
      return "PR auto-create failed (GH auth missing; set GH_TOKEN or JARVIS_GITHUB_TOKEN).";
    }
    return `PR auto-create failed: ${details}`;
  }

  const prUrl = clipText((createPr.stdout || "").trim(), 500);
  return prUrl ? `PR created: ${prUrl}` : "PR created.";
}

function isQaArtifactPath(filePath) {
  const normalized = String(filePath || "").replace(/\\/g, "/").toLowerCase();
  const name = path.posix.basename(normalized);
  return normalized.includes("/.jarvis-qa/") || normalized.startsWith(".jarvis-qa/") ||
    /^qa-.*\.(png|jpe?g|webp|xml|txt)$/.test(name) ||
    /^uiautomator.*\.xml$/.test(name) ||
    /^window[_-]?dump.*\.xml$/.test(name);
}

async function getGitHead(projectPath) {
  const result = await runExecutableCommand({
    executable: "git",
    args: ["rev-parse", "HEAD"],
    cwd: projectPath,
    timeoutMs: 20_000,
  });
  if (result.code !== 0) {
    throw new Error(`Unable to resolve git HEAD: ${clipText(result.stderr || result.stdout, 800)}`);
  }
  return String(result.stdout || "").trim();
}

async function assertTrackedWorktreeClean(projectPath) {
  const result = await runExecutableCommand({
    executable: "git",
    args: ["status", "--porcelain", "--untracked-files=no"],
    cwd: projectPath,
    timeoutMs: 20_000,
  });
  if (result.code !== 0) {
    throw new Error(`Unable to verify final worktree: ${clipText(result.stderr || result.stdout, 800)}`);
  }
  const dirty = String(result.stdout || "").trim();
  if (dirty) {
    throw new Error(`Final tracked worktree is not clean after commit:\n${clipText(dirty, 1200)}`);
  }
}

async function computeSourceStateFingerprint(projectPath) {
  const diff = await runExecutableCommand({
    executable: "git",
    args: ["diff", "--binary", "HEAD", "--", "."],
    cwd: projectPath,
    timeoutMs: 30_000,
  });
  if (diff.code !== 0) {
    throw new Error(`Unable to fingerprint source diff: ${clipText(diff.stderr || diff.stdout, 800)}`);
  }
  const untracked = await runExecutableCommand({
    executable: "git",
    args: ["ls-files", "--others", "--exclude-standard", "-z"],
    cwd: projectPath,
    timeoutMs: 20_000,
  });
  if (untracked.code !== 0) {
    throw new Error(`Unable to fingerprint untracked sources: ${clipText(untracked.stderr || untracked.stdout, 800)}`);
  }
  const hash = crypto.createHash("sha256");
  hash.update(String(diff.stdout || ""), "utf8");
  const paths = String(untracked.stdout || "").split("\0").filter(Boolean).sort();
  for (const relativePath of paths) {
    hash.update(`\0${relativePath}\0`, "utf8");
    const fullPath = path.join(projectPath, relativePath);
    try {
      if (fs.statSync(fullPath).isFile()) hash.update(fs.readFileSync(fullPath));
    } catch (_ignored) {
      hash.update("<missing>", "utf8");
    }
  }
  return hash.digest("hex");
}

async function unstageQaArtifacts(projectPath) {
  const staged = await runExecutableCommand({
    executable: "git",
    args: ["diff", "--cached", "--name-only", "--diff-filter=ACMRD", "-z"],
    cwd: projectPath,
    timeoutMs: 20_000,
  });
  if (staged.code !== 0) return [];
  const qaPaths = String(staged.stdout || "").split("\0").filter(Boolean).filter(isQaArtifactPath);
  if (qaPaths.length === 0) return [];
  const reset = await runExecutableCommand({
    executable: "git",
    args: ["reset", "-q", "HEAD", "--", ...qaPaths],
    cwd: projectPath,
    timeoutMs: 30_000,
  });
  if (reset.code !== 0) {
    throw new Error(`Unable to remove QA artifacts from commit: ${clipText(reset.stderr || reset.stdout, 800)}`);
  }
  return qaPaths;
}

async function gitAutoCommitAndPush(projectPath, task, taskId) {
  if (!GIT_AUTO_COMMIT) {
    return { summary: "Git auto-commit disabled.", committed: false, commitHash: null };
  }

  await ensureLocalGitExclude(projectPath);
  await configureGitIdentity(projectPath);

  const porcelain = await gitStatusPorcelain(projectPath);
  if (!porcelain) {
    return { summary: "No file changes detected; skipping commit.", committed: false, commitHash: null };
  }

  const addResult = await runExecutableCommand({
    executable: "git",
    args: ["add", "-A", "--", "."],
    cwd: projectPath,
    timeoutMs: 120_000,
  });
  if (addResult.code !== 0) {
    throw new Error(`git add failed: ${clipText(addResult.stderr || addResult.stdout, 1000)}`);
  }
  const excludedQaArtifacts = await unstageQaArtifacts(projectPath);
  const stagedCheck = await runExecutableCommand({
    executable: "git",
    args: ["diff", "--cached", "--quiet", "--exit-code"],
    cwd: projectPath,
    timeoutMs: 20_000,
  });
  if (stagedCheck.code === 0) {
    const suffix = excludedQaArtifacts.length > 0 ? ` Excluded ${excludedQaArtifacts.length} QA artifact(s).` : "";
    return { summary: `No source changes detected; skipping commit.${suffix}`, committed: false, commitHash: null };
  }
  if (stagedCheck.code !== 1) {
    throw new Error(`Unable to verify staged changes: ${clipText(stagedCheck.stderr || stagedCheck.stdout, 800)}`);
  }

  const commitMessage = `chore(jarvis): task ${taskId} iteration ${task.iteration}`;
  const commitResult = await runExecutableCommand({
    executable: "git",
    args: ["commit", "-m", commitMessage],
    cwd: projectPath,
    timeoutMs: 40_000,
  });
  if (commitResult.code !== 0) {
    const commitOutput = `${commitResult.stdout}\n${commitResult.stderr}`;
    if (commitOutput.toLowerCase().includes("nothing to commit")) {
      return { summary: "No commit created (nothing to commit).", committed: false, commitHash: null };
    }
    throw new Error(`git commit failed: ${clipText(commitOutput, 1200)}`);
  }

  const hashResult = await runExecutableCommand({
    executable: "git",
    args: ["rev-parse", "--short", "HEAD"],
    cwd: projectPath,
    timeoutMs: 20_000,
  });
  const commitHash = hashResult.code === 0 ? (hashResult.stdout || "").trim() : "unknown";
  let summary = `Committed changes on ${task.branchName} (${commitHash}).`;
  if (excludedQaArtifacts.length > 0) summary += ` Excluded ${excludedQaArtifacts.length} QA artifact(s).`;

  if (!GIT_AUTO_PUSH) {
    return { summary: `${summary} Push skipped (JARVIS_GIT_AUTO_PUSH=false).`, committed: true, commitHash };
  }

  const remoteCheck = await runExecutableCommand({
    executable: "git",
    args: ["remote", "get-url", GIT_PUSH_REMOTE],
    cwd: projectPath,
    timeoutMs: 20_000,
  });
  if (remoteCheck.code !== 0) {
    return { summary: `${summary} Push skipped (remote '${GIT_PUSH_REMOTE}' not configured).`, committed: true, commitHash };
  }
  const remoteUrl = (remoteCheck.stdout || "").trim();

  const pushResult = await runExecutableCommand({
    executable: "git",
    args: ["push", "-u", GIT_PUSH_REMOTE, task.branchName],
    cwd: projectPath,
    timeoutMs: 120_000,
  });
  if (pushResult.code !== 0) {
    return { summary: `${summary} Push failed: ${clipText(pushResult.stderr || pushResult.stdout, 1200)}`, committed: true, commitHash };
  }

  const publishHint = inferPublishHint(remoteUrl);
  const prSummary = await createOrGetPullRequest(projectPath, task, taskId);
  if (publishHint) {
    return { summary: `${summary} Pushed to ${GIT_PUSH_REMOTE}/${task.branchName}. ${publishHint} ${prSummary}`, committed: true, commitHash };
  }
  return { summary: `${summary} Pushed to ${GIT_PUSH_REMOTE}/${task.branchName}. ${prSummary}`, committed: true, commitHash };
}

function inferPublishHint(remoteUrl) {
  if (!remoteUrl) {
    return null;
  }

  const normalized = remoteUrl.trim().replace(/\.git$/i, "");
  let owner = null;
  let repo = null;

  const httpsMatch = normalized.match(/^https?:\/\/github\.com\/([^/]+)\/([^/]+)$/i);
  const sshMatch = normalized.match(/^git@github\.com:([^/]+)\/([^/]+)$/i);
  if (httpsMatch) {
    owner = httpsMatch[1];
    repo = httpsMatch[2];
  } else if (sshMatch) {
    owner = sshMatch[1];
    repo = sshMatch[2];
  }

  if (!owner || !repo) {
    return null;
  }

  const lowerOwner = owner.toLowerCase();
  const lowerRepo = repo.toLowerCase();
  if (lowerRepo === `${lowerOwner}.github.io`) {
    return `Possible GitHub Pages URL (if enabled): https://${owner}.github.io/`;
  }
  return `Possible GitHub Pages URL (if enabled): https://${owner}.github.io/${repo}/`;
}

function buildCodexPrompt(taskPayload) {
  const backendPrompt = String(
    taskPayload?.agentContextPrompt
    || taskPayload?.agentContext?.prompt
    || ""
  ).trim();
  if (backendPrompt) {
    return backendPrompt;
  }

  const task = taskPayload.task || {};
  const project = taskPayload.project || {};
  const messages = Array.isArray(taskPayload.messages) ? taskPayload.messages : [];

  const history = messages
    .map((m, index) => `${index + 1}. [${m.role}] ${m.content}`)
    .join("\n");

  return [
    "You are an autonomous Android engineer working on a local repository.",
    "",
    `Task ID: ${task.id}`,
    `Project ID: ${project.id}`,
    `Project path: ${project.absolutePath}`,
    `Branch: ${task.branchName}`,
    `Iteration: ${task.iteration}`,
    "",
    "Conversation history (oldest first):",
    history || "(no previous messages)",
    "",
    "Hard requirements:",
    "- Fix the issue with minimal, safe diff.",
    "- Respect existing architecture and module boundaries.",
    "- Keep project buildable.",
    "- If you are blocked by missing details, explain exactly what is missing.",
    "- End with a concise summary of what changed and why.",
  ].join("\n");
}

function buildExecutionProfileTaskPrelude(taskPayload) {
  const task = taskPayload?.task || {};
  const project = taskPayload?.project || {};
  const backendRuntimeContext = String(taskPayload?.agentContextPrompt || "").trim();
  const jarvisRequiredContext = looksLikeAndroidComposeTaskPayload(taskPayload)
    ? [
      "Jarvis mandatory context (visible/non-removable):",
      "- Android Compose repositories must keep a complete Gradle wrapper: gradlew, gradlew.bat, gradle/wrapper/gradle-wrapper.jar and gradle/wrapper/gradle-wrapper.properties.",
      "- If the wrapper is missing, create or restore it before finishing.",
      "- Validate APK generation on Windows with ./gradlew.bat :app:assembleDebug from the project root.",
      "- Jarvis needs that wrapper to build/upload the debug APK into task history."
    ].join("\n")
    : "";
  return [
    "You are an autonomous Android engineer working on a local repository.",
    "",
    `Task ID: ${task.id}`,
    `Project ID: ${project.id}`,
    `Project path: ${project.absolutePath}`,
    `Branch: ${task.branchName}`,
    `Iteration: ${task.iteration}`,
    "",
    "Hard requirements:",
    "- Fix the issue with minimal, safe diff.",
    "- Respect existing architecture and module boundaries.",
    "- Keep project buildable.",
    "- If you are blocked by missing details, explain exactly what is missing.",
    "- End with a concise summary of what changed and why.",
    "",
    jarvisRequiredContext,
    "",
    backendRuntimeContext
      ? `Backend runtime/orchestration context:\n${backendRuntimeContext}`
      : "",
  ].join("\n");
}

function looksLikeAndroidComposeTaskPayload(taskPayload) {
  const project = taskPayload?.project || {};
  const candidates = [
    project.name,
    project.absolutePath,
    project.executionPath,
    project.worktreePath
  ].map((item) => String(item || "").toLowerCase());
  if (candidates.some((item) => item.includes("android-compose") || item.includes("compose"))) {
    return true;
  }
  const projectPath = String(project.absolutePath || project.executionPath || "").trim();
  if (!projectPath) return false;
  const files = [
    path.join(projectPath, "app", "template-context.md"),
    path.join(projectPath, "app", "build.gradle.kts"),
    path.join(projectPath, "app", "build.gradle")
  ];
  for (const file of files) {
    try {
      if (!fs.existsSync(file) || !fs.statSync(file).isFile()) continue;
      const lower = fs.readFileSync(file, "utf8").toLowerCase();
      if (
        lower.includes("template key: android-compose") ||
        lower.includes("jetpack compose") ||
        lower.includes("buildfeatures.compose") ||
        lower.includes("compose = true")
      ) {
        return true;
      }
    } catch (_error) {}
  }
  return false;
}

function resolveLocalPromptBudget(llmRuntimeConfig = null, options = {}) {
  const provider = String(llmRuntimeConfig?.provider || "").trim().toUpperCase();
  const engine = String(options?.engine || "").trim().toUpperCase();
  const reasons = [`global=${LOCAL_PROMPT_MAX_CHARS}`];
  let charLimit = LOCAL_PROMPT_MAX_CHARS;

  if (engine === "OPENCODE" && provider === "LMSTUDIO") {
    charLimit = Math.min(charLimit, OPENCODE_LOCAL_SAFE_PROMPT_MAX_CHARS);
    reasons.push(`opencode_lmstudio_safe=${OPENCODE_LOCAL_SAFE_PROMPT_MAX_CHARS}`);
  }

  const modelContextWindow = Number(llmRuntimeConfig?.modelContextWindow || 0);
  if (Number.isFinite(modelContextWindow) && modelContextWindow > 0) {
    const contextCap = Math.max(1200, Math.floor(modelContextWindow * 0.9));
    charLimit = Math.min(charLimit, contextCap);
    reasons.push(`runtime_ctx=${contextCap}`);
  }

  const modelInfo = options?.modelInfo || null;
  const loadedContextLength = Number(modelInfo?.loaded_context_length || 0);
  if (Number.isFinite(loadedContextLength) && loadedContextLength > 0) {
    const loadedCap = Math.max(1200, Math.floor(loadedContextLength * 0.9));
    charLimit = Math.min(charLimit, loadedCap);
    reasons.push(`lmstudio_loaded=${loadedCap}`);
  }

  const maxContextLength = Number(modelInfo?.max_context_length || 0);
  if (Number.isFinite(maxContextLength) && maxContextLength > 0) {
    reasons.push(`lmstudio_max=${Math.max(1200, Math.floor(maxContextLength * 0.9))}`);
  }

  return {
    charLimit: Math.max(1200, charLimit),
    reasons
  };
}

function buildLocalLlmAgentInstructions(llmRuntimeConfig = null) {
  const provider = String(llmRuntimeConfig?.provider || "").trim().toUpperCase() || "LOCAL";
  const localProvider = resolveLocalOssProvider(provider, llmRuntimeConfig?.localProvider);
  const contextWindow = Number(llmRuntimeConfig?.modelContextWindow || 0);
  const contextLine = Number.isFinite(contextWindow) && contextWindow > 0
    ? `- Ventana de contexto runtime declarada: ${contextWindow} tokens. Respeta ese presupuesto y no pidas mas contexto si puedes avanzar.`
    : "- Si el contexto parece limitado, prioriza la tarea actual, los errores de build y los archivos directamente relacionados.";

  return [
    "[LOCAL_LLM_AGENT_SHARED_CONTEXT]",
    `provider=${provider}`,
    `local_provider=${localProvider}`,
    `android_compose_build_retries=${LOCAL_AGENT_BUILD_RETRIES}`,
    `reasoning_effort=${getLocalAgentReasoningEffort() || "runtime-default"}`,
    "",
    "Eres un agente autonomo de desarrollo ejecutandose dentro de Jarvis con un LLM local. No eres un chatbot.",
    "Tu objetivo es modificar el repositorio real usando las herramientas disponibles hasta completar la tarea.",
    "",
    "Reglas obligatorias para modelos locales:",
    "- No preguntes al usuario antes de actuar. Si falta informacion, toma una decision razonable y continua.",
    "- No te quedes en modo plan. Puedes pensar brevemente, pero debes ejecutar comandos/herramientas y escribir archivos.",
    "- No entregues solo Markdown explicativo si la tarea requiere codigo. La tarea solo esta completa si hay cambios reales en disco o una verificacion ejecutada.",
    "- Usa shell/tool calling para inspeccionar, crear, editar y validar. Si una herramienta falla, corrige el comando y reintenta con una alternativa.",
    "- Resume al final que archivos tocaste, que validaste y que queda pendiente si algo externo bloquea la entrega.",
    "- En Windows usa PowerShell compatible: evita heredocs de Bash como `cat <<EOF` o `python - <<'PY'`. Para archivos largos usa `Set-Content`, `New-Item` o scripts auxiliares creados de forma compatible.",
    contextLine,
    "",
    "Reglas especificas Android/Kotlin/Jetpack Compose:",
    "- Si la tarea trata de una app Android, Kotlin, Jetpack Compose o Room, debes intentar compilar antes de terminar.",
    "- Ejecuta el assemble disponible, normalmente `./gradlew assembleDebug` en Unix o `.\\gradlew.bat assembleDebug` / `gradlew.bat assembleDebug` en Windows.",
    "- La entrega valida debe producir un APK en `app/build/outputs/apk/...` o una ruta equivalente del modulo Android.",
    `- Si assemble falla, lee el error, corrige el codigo/configuracion y reintenta hasta ${LOCAL_AGENT_BUILD_RETRIES} veces antes de declarar bloqueo.`,
    "- Si no puedes compilar por SDK/Gradle/red ausente, deja el codigo fuente completo, conserva el error exacto y explica el bloqueo externo.",
    "[/LOCAL_LLM_AGENT_SHARED_CONTEXT]",
  ].join("\n");
}

function prependLocalLlmAgentInstructions(prompt, llmRuntimeConfig = null) {
  const text = String(prompt || "");
  if (text.includes("[LOCAL_LLM_AGENT_SHARED_CONTEXT]")) {
    return text;
  }
  return `${buildLocalLlmAgentInstructions(llmRuntimeConfig)}\n\n${text}`.trim();
}

function toTomlBasicString(value) {
  return JSON.stringify(String(value || ""));
}

function toCodexConfigPath(filePath) {
  return path.resolve(filePath).replace(/\\/g, "/");
}

function getLocalAgentReasoningEffort() {
  const value = String(LOCAL_AGENT_REASONING_EFFORT || "").trim().toLowerCase();
  if (!value) return "";
  return ["none", "minimal", "low", "medium", "high", "xhigh"].includes(value) ? value : "";
}

function compactPromptForLocalProvider(prompt, llmRuntimeConfig = null, options = {}) {
  const provider = String(llmRuntimeConfig?.provider || "").trim().toUpperCase();
  if (!isLocalOssProvider(provider)) {
    return { prompt: String(prompt || ""), compacted: false, budget: null, originalLength: String(prompt || "").length };
  }
  const text = String(prompt || "");
  const budget = resolveLocalPromptBudget(llmRuntimeConfig, options);
  if (!text || text.length <= budget.charLimit) {
    return { prompt: prependLocalLlmAgentInstructions(text, { ...llmRuntimeConfig, provider }), compacted: false, budget, originalLength: text.length };
  }

  const header = [
    "[LOCAL_MODEL_PROMPT_COMPACTED]",
    `provider=${provider}`,
    `max_chars=${budget.charLimit}`,
    `budget_reasons=${budget.reasons.join(",")}`,
    "",
    "Se recorta el contexto para evitar errores de ventana de contexto en modelos locales.",
    "Se conserva e inyecta siempre el contexto compartido de agente autonomo local.",
    "Prioriza la tarea actual y aplica cambios directamente en este repositorio.",
    "",
  ].join("\n");

  const anchors = [
    "[EXECUTION_PROFILE_RUNTIME]",
    "Variables runtime:",
    "PROMPT ORIGINAL:",
    "Conversation history (oldest first):"
  ];
  const anchorIndex = anchors
    .map((anchor) => text.lastIndexOf(anchor))
    .filter((idx) => idx >= 0)
    .sort((a, b) => b - a)[0];
  const baseBody = anchorIndex >= 0 ? text.slice(anchorIndex).trim() : text.trim();
  const compactedBody = dedupeParagraphs(baseBody);
  const allowedBodyChars = Math.max(1000, budget.charLimit - header.length - 8);
  const body = clipBalancedText(compactedBody, allowedBodyChars).trim();

  return {
    prompt: prependLocalLlmAgentInstructions(`${header}${body}`.trim(), { ...llmRuntimeConfig, provider }),
    compacted: true,
    budget,
    originalLength: text.length,
  };
}

function buildOpencodeLmStudioContextError(prompt, llmRuntimeConfig = null, modelInfo = null) {
  const loadedContextLength = Number(modelInfo?.loaded_context_length || 0);
  if (!Number.isFinite(loadedContextLength) || loadedContextLength <= 0) {
    return "";
  }
  const promptTokenEstimate = estimateTokenCountFromText(prompt);
  const estimatedNeed = OPENCODE_LMSTUDIO_BASE_PROMPT_TOKENS + promptTokenEstimate + OPENCODE_LMSTUDIO_CONTEXT_SAFETY_MARGIN;
  if (loadedContextLength >= estimatedNeed) {
    return "";
  }
  const modelLabel = String(llmRuntimeConfig?.model || modelInfo?.id || "-").trim() || "-";
  return [
    "OpenCode LM Studio preflight failed:",
    `model=${modelLabel}`,
    `loaded_context_length=${loadedContextLength}`,
    `estimated_prompt_tokens=${promptTokenEstimate}`,
    `opencode_base_tokens≈${OPENCODE_LMSTUDIO_BASE_PROMPT_TOKENS}`,
    `required_tokens≈${estimatedNeed}`,
    "Conclusion: con este contexto cargado en LM Studio, OpenCode no cabe ni aunque el prompt del usuario sea corto.",
    "Acción: sube la ventana real cargada del modelo en LM Studio y recarga el modelo antes de reintentar."
  ].join(" ");
}

function resolveEngineIterationLogDir(taskPayload, taskLogDir, engineName) {
  const iteration = Math.max(0, Number(taskPayload?.task?.iteration) || 0);
  const dir = path.join(
    taskLogDir,
    `iteration-${String(iteration).padStart(3, "0")}`,
    sanitizeFileComponent(engineName || "engine").toLowerCase()
  );
  ensureDirectory(dir);
  return dir;
}

async function runCodex(taskPayload, projectPath, taskLogDir, runtimeConfig = {}) {
  if (!ENABLE_CODEX) {
    const msg = "Codex execution skipped (JARVIS_CODEX_ENABLED=false).";
    return { output: msg, skipped: true };
  }

  const llmRuntimeConfig = normalizeLlmRuntimeConfig(runtimeConfig?.llmRuntimeConfig || {});
  let effectiveProvider = llmRuntimeConfig.provider;
  let runtimeWarning = null;
  if (effectiveProvider === "ANTHROPIC") {
    effectiveProvider = "OPENAI";
    runtimeWarning = "Runtime LLM provider ANTHROPIC is not yet supported by Codex CLI in this worker; fallback to OPENAI execution.";
  }
  const rawPrompt = `${buildCodexPrompt(taskPayload)}\n\n${buildAdbPolicyPrompt()}`;
  const compactedPrompt = compactPromptForLocalProvider(rawPrompt, { ...llmRuntimeConfig, provider: effectiveProvider });
  const prompt = compactedPrompt.prompt;
  const iterationLogDir = resolveEngineIterationLogDir(taskPayload, taskLogDir, "codex");
  const promptFile = path.join(iterationLogDir, "codex-prompt.md");
  const liveStdoutFile = path.join(iterationLogDir, "codex-stdout.log");
  const attemptSummaryFile = path.join(iterationLogDir, "codex-attempts.log");
  fs.writeFileSync(promptFile, prompt, "utf8");
  fs.writeFileSync(liveStdoutFile, "", "utf8");

  const args = ["exec", "-C", projectPath, "-"];
  if (CODEX_EPHEMERAL) {
    args.splice(1, 0, "--ephemeral");
  }
  if (CODEX_SKIP_GIT_REPO_CHECK) {
    args.splice(1, 0, "--skip-git-repo-check");
  }
  const codexLocalProvider = isLocalOssProvider(effectiveProvider)
    ? resolveLocalOssProvider(effectiveProvider, llmRuntimeConfig.localProvider)
    : null;
  const reasoningEffort = normalizeReasoningEffort(llmRuntimeConfig.reasoningEffort) ||
    (codexLocalProvider ? getLocalAgentReasoningEffort() : "");
  if (reasoningEffort) {
    args.splice(1, 0, "--config", `model_reasoning_effort=${toTomlBasicString(reasoningEffort)}`);
  }
  let localAgentInstructionsFile = null;
  if (codexLocalProvider) {
    localAgentInstructionsFile = path.join(iterationLogDir, LOCAL_AGENT_INSTRUCTIONS_FILE_NAME);
    fs.writeFileSync(
      localAgentInstructionsFile,
      buildLocalLlmAgentInstructions({ ...llmRuntimeConfig, provider: effectiveProvider, localProvider: codexLocalProvider }),
      "utf8"
    );
    args.splice(1, 0, "--oss");
    args.splice(2, 0, "--local-provider", codexLocalProvider);
    args.splice(1, 0, "--config", `model_instructions_file=${toTomlBasicString(toCodexConfigPath(localAgentInstructionsFile))}`);
    if (Number.isFinite(llmRuntimeConfig.modelContextWindow) && llmRuntimeConfig.modelContextWindow > 0) {
      args.splice(1, 0, "--config", `model_context_window=${llmRuntimeConfig.modelContextWindow}`);
    }
  }
  const runtimeModel = llmRuntimeConfig.model || "";
  const finalModel = runtimeModel || CODEX_MODEL;
  if (finalModel) {
    args.unshift(finalModel);
    args.unshift("--model");
  }
  args.unshift(...buildCodexSecurityArgs());

  const accounts = codexLocalProvider
    ? [{ label: `${codexLocalProvider}-runtime`, token: null, source: "runtime", expiresAt: null }]
    : buildCodexExecutionAccounts();
  const attemptLogs = [];
  let lastError = "";

  for (let index = 0; index < accounts.length; index += 1) {
    const account = accounts[index];
    const outputFile = path.join(iterationLogDir, `attempt-${String(index + 1).padStart(2, "0")}-last-message.txt`);
    fs.rmSync(outputFile, { force: true });
    const attemptArgs = [...args];
    attemptArgs.splice(attemptArgs.length - 1, 0, "-o", outputFile);
    const envOverride = buildCodexChildEnv(account.token, { ...llmRuntimeConfig, provider: effectiveProvider, localProvider: codexLocalProvider || llmRuntimeConfig.localProvider });
    applyAdbPolicyToCodexEnv(envOverride, iterationLogDir);
    attemptLogs.push(
      [
        `=== command attempt ${index + 1}/${accounts.length} account=${account.label} source=${account.source} ===`,
        `codex ${attemptArgs.map((arg) => JSON.stringify(arg)).join(" ")}`,
        `cwd=${projectPath}`,
        codexLocalProvider ? `localProvider=${codexLocalProvider}` : "localProvider=n/a",
        localAgentInstructionsFile ? `localAgentInstructionsFile=${localAgentInstructionsFile}` : "localAgentInstructionsFile=n/a",
        `reasoningEffort=${reasoningEffort || "runtime-default"}`,
      ].join("\n")
    );
    appendFileSafe(
      liveStdoutFile,
      `\n=== attempt ${index + 1}/${accounts.length} account=${account.label} source=${account.source} @ ${new Date().toISOString()} ===\n`
    );

    const result = await runCodexCommand({
      args: attemptArgs,
      cwd: projectPath,
      timeoutMs: CODEX_TIMEOUT_MS,
      stdinText: prompt,
      env: envOverride,
      outputFile,
      outputStallTimeoutMs: CODEX_OUTPUT_STALL_TIMEOUT_MS,
      liveLogFile: liveStdoutFile,
    });

    const rawStd = [result.stdout, result.stderr].filter(Boolean).join("\n");
    attemptLogs.push(
      [
        `=== attempt ${index + 1}/${accounts.length} account=${account.label} source=${account.source} ===`,
        rawStd,
      ].join("\n")
    );

    if (result.processTreeTerminated === false) {
      fs.writeFileSync(attemptSummaryFile, attemptLogs.join("\n\n"), "utf8");
      throw new Error(`Codex process tree could not be terminated safely: ${result.terminationReason || "unknown reason"}`);
    }

    if (result.timedOut || result.stalledAfterOutput) {
      let output = "";
      if (fs.existsSync(outputFile)) {
        output = fs.readFileSync(outputFile, "utf8");
      }
      if (output.trim()) {
        const warning = result.timedOut
          ? `Codex timeout after ${CODEX_TIMEOUT_MS}ms, continuing with last captured response.`
          : `Codex process stalled after writing output, continuing with last captured response.`;
        attemptLogs.push(`=== watchdog ===\n${warning}`);
        fs.writeFileSync(attemptSummaryFile, attemptLogs.join("\n\n"), "utf8");
        return {
          output,
          skipped: false,
          accountLabel: account.label,
          warning: [
            warning,
            runtimeWarning,
            codexLocalProvider ? "Local LLM shared autonomous-agent context injected." : null,
            compactedPrompt.compacted ? `Local prompt compacted to ~${LOCAL_PROMPT_MAX_CHARS} chars.` : null,
          ].filter(Boolean).join(" Â· ") || null
        };
      }
      fs.writeFileSync(attemptSummaryFile, attemptLogs.join("\n\n"), "utf8");
      if (result.timedOut) {
        throw new Error(`Codex timed out after ${CODEX_TIMEOUT_MS}ms`);
      }
      throw new Error("Codex process stalled after output watchdog timeout.");
    }

    if (result.code === 0) {
      fs.writeFileSync(attemptSummaryFile, attemptLogs.join("\n\n"), "utf8");
      let output = "";
      if (fs.existsSync(outputFile)) {
        output = fs.readFileSync(outputFile, "utf8");
      }
      if (!output.trim()) {
        output = rawStd || "Codex completed without output text.";
      }
      return {
        output,
        skipped: false,
        accountLabel: account.label,
        warning: [
          runtimeWarning,
          codexLocalProvider ? "Local LLM shared autonomous-agent context injected." : null,
          compactedPrompt.compacted ? `Local prompt compacted to ~${LOCAL_PROMPT_MAX_CHARS} chars.` : null,
        ].filter(Boolean).join(" Â· ") || null
      };
    }

    lastError = rawStd || `exit=${result.code}`;
    const canRetry = index < accounts.length - 1 && isRetryableCodexAccountError(lastError);
    if (!canRetry) {
      fs.writeFileSync(attemptSummaryFile, attemptLogs.join("\n\n"), "utf8");
      throw new Error(`Codex failed (${account.label}): ${clipText(lastError, 2000)}`);
    }
  }

  fs.writeFileSync(attemptSummaryFile, attemptLogs.join("\n\n"), "utf8");
  throw new Error(`Codex failed after rotating all accounts: ${clipText(lastError, 2000)}`);
}

async function runClaude(taskPayload, projectPath, taskLogDir, runtimeConfig = {}) {
  const claudeRuntimeConfig = normalizeClaudeRuntimeConfig(runtimeConfig?.claudeRuntimeConfig || {});
  if (!claudeRuntimeConfig.enabled) {
    throw new Error("CLAUDE_CODE runtime is disabled in /runtime/integrations/claude.");
  }

  const prompt = buildCodexPrompt(taskPayload);
  const promptFile = path.join(taskLogDir, "claude-prompt.md");
  const liveStdoutFile = path.join(taskLogDir, "claude-stdout.log");
  fs.writeFileSync(promptFile, prompt, "utf8");
  fs.writeFileSync(
    liveStdoutFile,
    [
      `=== Claude Code runtime started @ ${new Date().toISOString()} ===`,
      `cwd=${projectPath}`,
      "",
    ].join("\n"),
    "utf8"
  );

  const args = [
    "-p",
    "--output-format",
    "stream-json",
    "--verbose",
    "--include-partial-messages",
    "--permission-mode",
    "bypassPermissions",
    "--max-turns",
    String(CLAUDE_MAX_TURNS),
  ];
  const finalModel = claudeRuntimeConfig.model || CLAUDE_MODEL;
  if (finalModel) {
    args.push("--model", finalModel);
  }

  const accounts = buildClaudeExecutionAccounts(claudeRuntimeConfig);
  const attemptLogs = [];
  let lastError = "";

  for (let index = 0; index < accounts.length; index += 1) {
    const account = accounts[index];
    const envOverride = buildClaudeChildEnv(claudeRuntimeConfig, account);
    attemptLogs.push(
      [
        `=== attempt ${index + 1}/${accounts.length} account=${account.label} source=${account.source} auth=${account.authMode} ===`,
        `claude ${args.map((arg) => JSON.stringify(arg)).join(" ")}`,
        `cwd=${projectPath}`,
      ].join("\n")
    );
    appendFileSafe(
      liveStdoutFile,
      [
        `\n=== attempt ${index + 1}/${accounts.length} account=${account.label} source=${account.source} auth=${account.authMode} @ ${new Date().toISOString()} ===`,
        `claude ${args.map((arg) => JSON.stringify(arg)).join(" ")}`,
        "",
      ].join("\n")
    );

    const result = await runExecutableCommand({
      executable: "claude",
      args,
      cwd: projectPath,
      timeoutMs: CLAUDE_TIMEOUT_MS,
      stdinText: prompt,
      env: envOverride,
      liveLogFile: liveStdoutFile,
    });

    const rawStd = [result.stdout, result.stderr].filter(Boolean).join("\n");
    attemptLogs.push(
      [
        `=== result ${index + 1}/${accounts.length} account=${account.label} source=${account.source} auth=${account.authMode} ===`,
        rawStd,
      ].join("\n")
    );

    const parsed = parseClaudeJsonOutput(result.stdout, result.stderr);
    const parsedResultText = String(parsed?.result || "").trim();
    const parsedIsError = Boolean(parsed?.is_error);
    const parsedUsage = parsed?.usage && typeof parsed.usage === "object"
      ? parsed.usage
      : null;
    const usageSummary = parsedUsage
      ? `Claude usage: in=${parsedUsage.input_tokens ?? 0} out=${parsedUsage.output_tokens ?? 0} cache_read=${parsedUsage.cache_read_input_tokens ?? 0} cache_create=${parsedUsage.cache_creation_input_tokens ?? 0}`
      : null;
    const claudeMaxTurnsError = isClaudeMaxTurnsResult(parsed)
      ? formatClaudeMaxTurnsError(parsed)
      : null;

    if (result.timedOut) {
      fs.writeFileSync(path.join(taskLogDir, "claude-stdout.log"), attemptLogs.join("\n\n"), "utf8");
      throw new Error(`Claude timed out after ${CLAUDE_TIMEOUT_MS}ms`);
    }

    if (result.code === 0 && !parsedIsError) {
      fs.writeFileSync(path.join(taskLogDir, "claude-stdout.log"), attemptLogs.join("\n\n"), "utf8");
      const output = parsedResultText || rawStd || "Claude completed without output text.";
      return {
        output,
        skipped: false,
        accountLabel: account.label,
        warning: usageSummary,
      };
    }

    lastError = claudeMaxTurnsError || parsedResultText || rawStd || `exit=${result.code}`;
    const canRetry = index < accounts.length - 1 && isRetryableClaudeAccountError(lastError);
    if (!canRetry) {
      fs.writeFileSync(path.join(taskLogDir, "claude-stdout.log"), attemptLogs.join("\n\n"), "utf8");
      throw new Error(`Claude failed (${account.label}): ${clipText(lastError, 2000)}`);
    }
  }

  fs.writeFileSync(path.join(taskLogDir, "claude-stdout.log"), attemptLogs.join("\n\n"), "utf8");
  throw new Error(`Claude failed after rotating all accounts: ${clipText(lastError, 2000)}`);
}

async function ensureOpencodeInstalled(taskLogDir) {
  const check = await runExecutableCommand({
    executable: "opencode",
    args: ["--version"],
    cwd: __dirname,
    timeoutMs: 20_000,
  });
  if (check.code === 0) {
    return null;
  }

  if (opencodeInstallAttempted) {
    throw new Error("OpenCode CLI is not available in PATH and automatic installation already failed in this worker session.");
  }
  opencodeInstallAttempted = true;

  const install = await runExecutableCommand({
    executable: "npm",
    args: ["install", "-g", "opencode-ai"],
    cwd: __dirname,
    timeoutMs: 900_000,
  });
  const installLog = [install.stdout, install.stderr].filter(Boolean).join("\n").trim();
  fs.writeFileSync(path.join(taskLogDir, "opencode-install.log"), installLog || "(no install output)", "utf8");

  if (install.code !== 0) {
    throw new Error(`Failed to install OpenCode CLI automatically: ${clipText(installLog || `exit=${install.code}`, 1800)}`);
  }

  const recheck = await runExecutableCommand({
    executable: "opencode",
    args: ["--version"],
    cwd: __dirname,
    timeoutMs: 20_000,
  });
  if (recheck.code !== 0) {
    const recheckOutput = [recheck.stdout, recheck.stderr].filter(Boolean).join("\n");
    throw new Error(`OpenCode CLI install completed but command is still unavailable: ${clipText(recheckOutput || `exit=${recheck.code}`, 1200)}`);
  }
  return "OpenCode CLI instalado automÃ¡ticamente con npm (opencode-ai).";
}

function buildOpencodeRuntimeConfig(taskLogDir, llmRuntimeConfig) {
  const runtimeModel = String(llmRuntimeConfig?.model || "").trim();
  const provider = String(llmRuntimeConfig?.provider || "OPENAI").trim().toUpperCase();
  const localProvider = isLocalOssProvider(provider)
    ? resolveLocalOssProvider(provider, llmRuntimeConfig?.localProvider)
    : String(llmRuntimeConfig?.localProvider || "").trim().toLowerCase();
  const lmApiToken = String(process.env.LM_API_TOKEN || "").trim();

  const ollamaBase = normalizeOllamaBaseUrl(
    process.env.JARVIS_OPENCODE_OLLAMA_API_BASE_URL
    || process.env.JARVIS_OLLAMA_API_BASE_URL
    || process.env.OLLAMA_BASE_URL
    || "http://localhost:11434/v1"
  );
  const lmstudioBase = normalizeLmStudioBaseUrl(
    process.env.JARVIS_OPENCODE_LMSTUDIO_API_BASE_URL
    || process.env.JARVIS_LMSTUDIO_API_BASE_URL
    || "http://localhost:1234/v1"
  );

  const config = {
    $schema: "https://opencode.ai/config.json",
    provider: {},
  };

  const addProvider = (id, name, baseURL, modelId, apiKey = null) => {
    const options = { baseURL };
    if (apiKey) {
      options.apiKey = apiKey;
    }
    const models = {};
    if (modelId) {
      models[modelId] = { name: `${modelId} (runtime)` };
    }
    config.provider[id] = {
      npm: "@ai-sdk/openai-compatible",
      name,
      options,
      models,
    };
  };

  addProvider(
    "ollama",
    "Ollama (runtime)",
    ollamaBase,
    (localProvider === "ollama" || provider === "OLLAMA") ? runtimeModel : "",
    null
  );
  addProvider(
    "lmstudio",
    "LM Studio (runtime)",
    lmstudioBase,
    (localProvider === "lmstudio" || provider === "LMSTUDIO") ? runtimeModel : "",
    lmApiToken || null
  );

  const selectedModel = resolveOpenCodeModelSpecifier(llmRuntimeConfig);
  if (selectedModel) {
    config.model = selectedModel;
  }

  const configPath = path.join(taskLogDir, "opencode.runtime.json");
  fs.writeFileSync(configPath, JSON.stringify(config, null, 2), "utf8");
  return { configPath, selectedModel };
}

function buildOpencodeChildEnv(apiKey, llmRuntimeConfig = null, configPath = null) {
  const env = { ...process.env };
  if (configPath) {
    env.OPENCODE_CONFIG = configPath;
  }
  env.OPENCODE_DISABLE_AUTOUPDATE = "true";
  const provider = String(llmRuntimeConfig?.provider || "OPENAI").trim().toUpperCase();
  if (isLocalOssProvider(provider)) {
    delete env.OPENAI_API_KEY;
  } else if (apiKey) {
    env.OPENAI_API_KEY = apiKey;
  }
  return env;
}

async function runOpencode(taskPayload, projectPath, taskLogDir, runtimeConfig = {}) {
  let llmRuntimeConfig = normalizeLlmRuntimeConfig(runtimeConfig?.llmRuntimeConfig || {});
  const installWarning = await ensureOpencodeInstalled(taskLogDir);
  const lmStudioBase = normalizeLmStudioBaseUrl(
    process.env.JARVIS_OPENCODE_LMSTUDIO_API_BASE_URL
    || process.env.JARVIS_LMSTUDIO_API_BASE_URL
    || "http://localhost:1234/v1"
  );
  const liveStdoutFile = path.join(taskLogDir, "opencode-live.log");
  let lmStudioContextPrep = null;
  if (String(llmRuntimeConfig.provider || "").toUpperCase() === "LMSTUDIO") {
    try {
      lmStudioContextPrep = await ensureLmStudioReady(lmStudioBase, llmRuntimeConfig.model, taskLogDir, liveStdoutFile);
      const effectiveLmStudioModel = String(lmStudioContextPrep?.effectiveModelId || "").trim();
      if (effectiveLmStudioModel && effectiveLmStudioModel !== llmRuntimeConfig.model) {
        appendLmStudioRuntimeLog(
          taskLogDir,
          liveStdoutFile,
          `Usando modelo LM Studio cargado con contexto suficiente: ${llmRuntimeConfig.model || "-"} -> ${effectiveLmStudioModel}`
        );
        llmRuntimeConfig = { ...llmRuntimeConfig, model: effectiveLmStudioModel };
      }
    } catch (error) {
      fs.writeFileSync(
        path.join(taskLogDir, "opencode-stdout.log"),
        [
          "=== LM Studio preflight ===",
          error?.message || String(error),
          "",
          `LM Studio base=${lmStudioBase}`,
          `Model=${llmRuntimeConfig.model || "-"}`,
        ].join("\n"),
        "utf8"
      );
      throw error;
    }
  }
  const lmStudioModelInfo = lmStudioContextPrep?.modelInfo || null;
  const rawPrompt = buildCodexPrompt(taskPayload);
  const compactedPrompt = compactPromptForLocalProvider(rawPrompt, llmRuntimeConfig, {
    engine: "OPENCODE",
    modelInfo: lmStudioModelInfo
  });
  const prompt = compactedPrompt.prompt;
  const opencodeContextError = String(llmRuntimeConfig.provider || "").toUpperCase() === "LMSTUDIO"
    ? buildOpencodeLmStudioContextError(prompt, llmRuntimeConfig, lmStudioModelInfo)
    : "";
  const promptFile = path.join(taskLogDir, "opencode-prompt.md");
  fs.writeFileSync(promptFile, prompt, "utf8");
  const { configPath, selectedModel } = buildOpencodeRuntimeConfig(taskLogDir, llmRuntimeConfig);

  if (opencodeContextError) {
    fs.writeFileSync(
      path.join(taskLogDir, "opencode-stdout.log"),
      [
        "=== preflight ===",
        opencodeContextError,
        "",
        `Prompt chars=${prompt.length}`,
        `Prompt token estimate=${estimateTokenCountFromText(prompt)}`,
        lmStudioModelInfo
          ? `LM Studio ctx model=${llmRuntimeConfig.model || "-"} loaded=${lmStudioModelInfo.loaded_context_length || "?"} max=${lmStudioModelInfo.max_context_length || "?"}.`
          : ""
      ].filter(Boolean).join("\n"),
      "utf8"
    );
    throw new Error(opencodeContextError);
  }

  const args = ["run", "--dangerously-skip-permissions"];
  if (selectedModel) {
    args.push("--model", selectedModel);
  }
  args.push(
    "--file",
    promptFile,
    "--",
    "Read the attached file and execute the task exactly as requested. Apply code changes directly in this repository and finish with a concise summary."
  );

  const effectiveProvider = String(llmRuntimeConfig.provider || "OPENAI").toUpperCase();
  const opencodeLocalProvider = isLocalOssProvider(effectiveProvider)
    ? resolveLocalOssProvider(effectiveProvider, llmRuntimeConfig.localProvider)
    : null;
  const accounts = opencodeLocalProvider
    ? [{ label: `${opencodeLocalProvider}-runtime`, token: null, source: "runtime", expiresAt: null }]
    : buildCodexExecutionAccounts();
  const attemptLogs = [];
  let lastError = "";

  for (let index = 0; index < accounts.length; index += 1) {
    const account = accounts[index];
    appendFileSafe(
      liveStdoutFile,
      `\n=== opencode attempt ${index + 1}/${accounts.length} account=${account.label} source=${account.source} started ${new Date().toISOString()} ===\n`
    );
    const envOverride = buildOpencodeChildEnv(account.token, llmRuntimeConfig, configPath);
    const result = await runExecutableCommand({
      executable: "opencode",
      args,
      cwd: projectPath,
      timeoutMs: OPENCODE_TIMEOUT_MS,
      env: envOverride,
      liveLogFile: liveStdoutFile,
    });

    const rawStd = [result.stdout, result.stderr].filter(Boolean).join("\n").trim();
    attemptLogs.push(
      [
        `=== attempt ${index + 1}/${accounts.length} account=${account.label} source=${account.source} ===`,
        rawStd || "(no output)",
      ].join("\n")
    );

    if (result.timedOut) {
      fs.writeFileSync(path.join(taskLogDir, "opencode-stdout.log"), attemptLogs.join("\n\n"), "utf8");
      throw new Error(`OpenCode timed out after ${OPENCODE_TIMEOUT_MS}ms`);
    }

    if (result.code === 0) {
      const fatalOutput = detectOpenCodeFatalOutput(rawStd);
      if (fatalOutput) {
        fs.writeFileSync(path.join(taskLogDir, "opencode-stdout.log"), attemptLogs.join("\n\n"), "utf8");
        throw new Error(fatalOutput);
      }
      fs.writeFileSync(path.join(taskLogDir, "opencode-stdout.log"), attemptLogs.join("\n\n"), "utf8");
      const output = rawStd || "OpenCode completed without output text.";
      const warningParts = [
        installWarning,
        opencodeLocalProvider ? "Local LLM shared autonomous-agent context injected." : null,
        lmStudioContextPrep?.warning || null,
        compactedPrompt.compacted
          ? `Local prompt compacted ${compactedPrompt.originalLength}->${prompt.length} chars (budget ${compactedPrompt?.budget?.charLimit || LOCAL_PROMPT_MAX_CHARS}).`
          : null,
        lmStudioModelInfo
          ? `LM Studio ctx model=${llmRuntimeConfig.model || "-"} loaded=${lmStudioModelInfo.loaded_context_length || "?"} max=${lmStudioModelInfo.max_context_length || "?"}.`
          : null,
      ].filter(Boolean);
      return {
        output,
        skipped: false,
        accountLabel: account.label,
        warning: warningParts.join(" | ") || null,
      };
    }

    lastError = rawStd || `exit=${result.code}`;
    const canRetry = index < accounts.length - 1 && isRetryableCodexAccountError(lastError);
    if (!canRetry) {
      fs.writeFileSync(path.join(taskLogDir, "opencode-stdout.log"), attemptLogs.join("\n\n"), "utf8");
      throw new Error(`OpenCode failed (${account.label}): ${clipText(lastError, 2000)}`);
    }
  }

  fs.writeFileSync(path.join(taskLogDir, "opencode-stdout.log"), attemptLogs.join("\n\n"), "utf8");
  throw new Error(`OpenCode failed after rotating all accounts: ${clipText(lastError, 2000)}`);
}

async function executeProfileStep({
  step,
  stepPrompt,
  taskPayload,
  projectPath,
  taskLogDir,
  llmRuntimeConfig,
  claudeRuntimeConfig
}) {
  const engine = String(step?.agentEngine || "CODEX").trim().toUpperCase() || "CODEX";
  const scopedTaskPayload = { ...taskPayload, agentContextPrompt: stepPrompt };
  const scopedStepDir = path.join(taskLogDir, `step-${String(step.index + 1).padStart(2, "0")}-${sanitizeFileComponent(step.name)}`);
  ensureDirectory(scopedStepDir);

  const scopedLlmConfig = mapStepProviderToRuntime(step.modelProvider, llmRuntimeConfig || {});
  if (step.model) {
    scopedLlmConfig.model = step.model;
  }
  if (step.reasoningEffort) {
    scopedLlmConfig.reasoningEffort = step.reasoningEffort;
  }

  if (engine === "CLAUDE_CODE") {
    if (isLocalOssProvider(scopedLlmConfig.provider)) {
      throw new Error(
        `CLAUDE_CODE + ${scopedLlmConfig.provider} (${scopedLlmConfig.model || "-"}) is not supported by this Jarvis runtime. Claude Code uses Claude CLI/auth, not LM Studio/Ollama OpenAI-compatible local models. Use the Codex/OpenCode local GPT-OSS profiles for real local-LLM execution.`
      );
    }
    const scopedClaudeConfig = { ...(claudeRuntimeConfig || {}) };
    if (step.model) scopedClaudeConfig.model = step.model;
    const result = await runClaude(scopedTaskPayload, projectPath, scopedStepDir, { claudeRuntimeConfig: scopedClaudeConfig });
    return { ...result, engine };
  }

  if (engine === "OPENCODE") {
    const result = await runOpencode(scopedTaskPayload, projectPath, scopedStepDir, {
      llmRuntimeConfig: scopedLlmConfig,
      claudeRuntimeConfig
    });
    return { ...result, engine };
  }

  const result = await runCodex(scopedTaskPayload, projectPath, scopedStepDir, {
    llmRuntimeConfig: scopedLlmConfig,
    claudeRuntimeConfig
  });
  return { ...result, engine: "CODEX" };
}

async function runExecutionProfilePipeline({
  taskPayload,
  projectPath,
  taskLogDir,
  profileConfig,
  llmRuntimeConfig,
  claudeRuntimeConfig
}) {
  const latestStateBundle = findLatestExecProfileState(taskPayload, profileConfig.profileKey);
  const latestState = latestStateBundle?.state || null;
  const shouldResumeFromWaiting =
    latestState &&
    latestState.status === "WAITING_USER" &&
    Number.isFinite(Number(latestState.pendingStepIndex));
  const latestResumeBundle = shouldResumeFromWaiting
    ? findLatestExecProfileResume(taskPayload, profileConfig.profileKey, latestStateBundle?.messageIndex ?? -1)
    : null;
  const resumeMode = String(latestResumeBundle?.resume?.mode || "RERUN").trim().toUpperCase() || "RERUN";
  const feedbackText = shouldResumeFromWaiting
    ? collectUserFeedbackAfterIndex(taskPayload, latestStateBundle?.messageIndex ?? -1)
    : "";

  const history = Array.isArray(latestState?.history)
    ? latestState.history.map((entry) => ({
      stepIndex: Number(entry?.stepIndex),
      name: String(entry?.name || ""),
      output: String(entry?.output || ""),
      engine: String(entry?.engine || "CODEX")
    }))
    : [];
  const originalUserPrompt = String(latestState?.originalUserPrompt || profileConfig.initialUserPrompt || "").trim();
  let startStepIndex = 0;
  let previousOutput = "";
  let skipWaitingStepIndex = -1;
  if (shouldResumeFromWaiting) {
    const pendingStepIndex = Math.max(0, Number(latestState.pendingStepIndex));
    if (resumeMode === "CONTINUE") {
      startStepIndex = pendingStepIndex + 1;
      previousOutput = String(history.find((entry) => Number(entry.stepIndex) === pendingStepIndex)?.output || "");
    } else {
      startStepIndex = pendingStepIndex;
      skipWaitingStepIndex = startStepIndex;
      previousOutput = startStepIndex > 0
        ? String(history.find((entry) => Number(entry.stepIndex) === startStepIndex - 1)?.output || "")
        : "";
    }
  }

  const totalSteps = profileConfig.steps.length;
  for (let idx = startStepIndex; idx < totalSteps; idx += 1) {
    const step = profileConfig.steps[idx];
    const stepNumber = idx + 1;
    const runtimeStepContext = await loadStepProjectContextRuntime(taskPayload, step, stepNumber, originalUserPrompt);
    await addMessage(
      taskPayload?.task?.id,
      "system",
      `Execution profile step ${stepNumber}/${totalSteps} runtime: ${step.agentEngine} Â· ${step.modelProvider || "ALL"} Â· ${step.model || "-"} Â· effort ${step.reasoningEffort || "runtime-default"}`
    );
    if (runtimeStepContext.warning) {
      await addMessage(taskPayload?.task?.id, "system", `Step ${stepNumber} contexto runtime: ${runtimeStepContext.warning}`);
    } else if (runtimeStepContext.selectedSourceCount > 0) {
      const unitLabel = runtimeStepContext.contextUnitLabel || "fuente(s)";
      const loadLabel = runtimeStepContext.mode === "context-graph-relevant" ? "contexto graph relevant" : "contexto runtime";
      await addMessage(
        taskPayload?.task?.id,
        "system",
        `Step ${stepNumber} ${loadLabel} cargado (${runtimeStepContext.projectId}): ${runtimeStepContext.selectedSourceCount} ${unitLabel}, ~${runtimeStepContext.selectedTokenEstimate} tok.`
      );
      if (runtimeStepContext.mode === "context-graph-relevant") {
        await addMessage(
          taskPayload?.task?.id,
          "system",
          `Step ${stepNumber} ContextGraph relevant: budget ~${runtimeStepContext.budgetTokens || "-"} tok; sources ${dedupeStringList(runtimeStepContext.selectedSourceKeys || []).join(", ") || "-"}.`
        );
      }
      if (runtimeStepContext.reduction && runtimeStepContext.reduction.savedTokens > 0) {
        await addMessage(
          taskPayload?.task?.id,
          "system",
          `Step ${stepNumber} contexto runtime reduccion: bruto ~${runtimeStepContext.reduction.rawTokens} tok -> efectivo ~${runtimeStepContext.reduction.effectiveTokens} tok; ahorro ~${runtimeStepContext.reduction.savedTokens} tok (${runtimeStepContext.reduction.savedPercent}%). fuentes ${runtimeStepContext.reduction.rawSourceCount}->${runtimeStepContext.reduction.effectiveSourceCount}.`
        );
        try {
          await recordUsageEvent(taskPayload?.task?.id, {
            iteration: Number(taskPayload?.task?.iteration || taskPayload?.task?.currentIteration || 0),
            executionStep: stepNumber,
            eventType: "CONTEXT_REDUCTION",
            engine: step.agentEngine || null,
            provider: step.modelProvider || null,
            model: step.model || null,
            injectedContextTokens: runtimeStepContext.reduction.effectiveTokens,
            rawContextTokens: runtimeStepContext.reduction.rawTokens,
            effectiveContextTokens: runtimeStepContext.reduction.effectiveTokens,
            savedContextTokens: runtimeStepContext.reduction.savedTokens,
            savedContextPercent: runtimeStepContext.reduction.savedPercent,
            source: runtimeStepContext.mode === "context-graph-relevant"
              ? "execution-profile-context-graph-relevant"
              : "execution-profile-runtime-context",
            rawUsageJson: JSON.stringify(runtimeStepContext.reduction),
          });
        } catch (error) {
          console.warn(`[agent] unable to persist context reduction usage event for step ${stepNumber}: ${String(error?.message || error)}`);
        }
      }
    }
    let previousOutputForPrompt = previousOutput;
    if (idx > 0 && shouldUsePreviousOutputGraphForStep(step, previousOutput)) {
      try {
        const previousOutputGraph = await loadPreviousStepOutputGraphRelevantRuntime({
          taskPayload,
          step,
          stepIndex: idx,
          previousOutput,
          originalUserPrompt
        });
        if (previousOutputGraph.warning) {
          await addMessage(taskPayload?.task?.id, "system", `Step ${stepNumber} OUTPUT_STEP_ANTERIOR graph: ${previousOutputGraph.warning}`);
        }
        if (previousOutputGraph.reduced) {
          previousOutputForPrompt = previousOutputGraph.outputForPrompt;
          await addMessage(
            taskPayload?.task?.id,
            "system",
            `Step ${stepNumber} OUTPUT_STEP_ANTERIOR reducido via ContextGraph: bruto ~${previousOutputGraph.rawTokens} tok -> efectivo ~${previousOutputGraph.effectiveTokens} tok; ahorro ~${previousOutputGraph.savedTokens} tok (${previousOutputGraph.savedPercent}%). source ${previousOutputGraph.sourceKey}.`
          );
          try {
            await recordUsageEvent(taskPayload?.task?.id, {
              iteration: Number(taskPayload?.task?.iteration || taskPayload?.task?.currentIteration || 0),
              executionStep: stepNumber,
              eventType: "CONTEXT_REDUCTION",
              engine: step.agentEngine || null,
              provider: step.modelProvider || null,
              model: step.model || null,
              injectedContextTokens: previousOutputGraph.effectiveTokens,
              rawContextTokens: previousOutputGraph.rawTokens,
              effectiveContextTokens: previousOutputGraph.effectiveTokens,
              savedContextTokens: previousOutputGraph.savedTokens,
              savedContextPercent: previousOutputGraph.savedPercent,
              source: "execution-profile-previous-output-graph",
              rawUsageJson: JSON.stringify({
                mode: "previous-output-graph",
                sourceKey: previousOutputGraph.sourceKey,
                budgetTokens: previousOutputGraph.budgetTokens,
                selectedSourceKeys: previousOutputGraph.selectedSourceKeys,
                selectedChunkCount: previousOutputGraph.selectedChunkCount,
                candidateChunkCount: previousOutputGraph.candidateChunkCount
              }),
            });
          } catch (error) {
            console.warn(`[agent] unable to persist previous-output reduction event for step ${stepNumber}: ${String(error?.message || error)}`);
          }
        }
      } catch (error) {
        await addMessage(
          taskPayload?.task?.id,
          "system",
          `Step ${stepNumber} OUTPUT_STEP_ANTERIOR graph falló; se usa bruto: ${String(error?.message || error).slice(0, 800)}`
        );
      }
    }
    const stepPrompt = buildExecutionProfileStepPrompt({
      basePrompt: buildExecutionProfileTaskPrelude(taskPayload),
      profileConfig,
      step,
      stepNumber,
      totalSteps,
      originalUserPrompt,
      previousOutput: previousOutputForPrompt,
      hitlFeedback: idx === startStepIndex ? feedbackText : "",
      runtimeProjectContextBlock: runtimeStepContext.block,
      llmRuntimeConfig: mapStepProviderToRuntime(step.modelProvider, llmRuntimeConfig || {})
    });
    let result;
    try {
      result = await executeProfileStep({
        step: { ...step, index: idx },
        stepPrompt,
        taskPayload,
        projectPath,
        taskLogDir,
        llmRuntimeConfig,
        claudeRuntimeConfig
      });
    } catch (stepError) {
      const marker = {
        profileKey: profileConfig.profileKey,
        profileName: profileConfig.profileName,
        status: "WAITING_USER",
        pendingStepIndex: idx,
        originalUserPrompt,
        history,
        error: clipText(stepError?.message || String(stepError), 2000)
      };
      await addMessage(taskPayload?.task?.id, "system", `${EXEC_PROFILE_STATE_TAG}\n${JSON.stringify(marker)}`);
      throw stepError;
    }
    const assistantRole = result.engine === "CLAUDE_CODE"
      ? "claude_code"
      : result.engine === "OPENCODE"
        ? "opencode"
        : "codex";
    const outputText = String(result.output || "").trim() || "(sin salida textual)";
    const stepHeader = `### Step ${stepNumber}/${totalSteps} Â· ${step.name} Â· ${result.engine}`;
    await addMessage(taskPayload?.task?.id, assistantRole, clipText(`${stepHeader}\n\n${outputText}`, 10000));
    if (result.accountLabel) {
      await addMessage(taskPayload?.task?.id, "system", `${result.engine} account used (step ${stepNumber}): ${result.accountLabel}`);
    }
    if (result.warning) {
      await addMessage(taskPayload?.task?.id, "system", `Step ${stepNumber} warning: ${result.warning}`);
    }
    const memoryOutputText = compactSuccessfulGradleOutputForMemory(outputText);
    try {
      const indexed = await storeExecutionProfileStepOutputInContextGraph({
        taskPayload,
        profileConfig,
        step,
        stepIndex: idx,
        stepNumber,
        outputText,
        engine: result.engine
      });
      if (indexed?.sourceKey) {
        await addMessage(
          taskPayload?.task?.id,
          "system",
          `Step ${stepNumber} output indexado en ContextGraph: ${indexed.sourceKey}; chunks=${Array.isArray(indexed.chunks) ? indexed.chunks.length : "-"}, ~${indexed.source?.estimatedTokens || estimateTokenCountFromText(memoryOutputText)} tok.`
        );
      }
    } catch (error) {
      console.warn(`[agent] unable to index execution profile step output ${stepNumber}: ${String(error?.message || error)}`);
      await addMessage(
        taskPayload?.task?.id,
        "system",
        `Step ${stepNumber} output no se pudo indexar en ContextGraph: ${String(error?.message || error).slice(0, 800)}`
      );
    }

    history.push({
      stepIndex: idx,
      name: step.name,
      output: clipText(memoryOutputText, 12000),
      engine: result.engine
    });
    previousOutput = memoryOutputText;

    const shouldPauseForHitl = step.finalizeWithWaitingUser === true && idx !== skipWaitingStepIndex;
    if (shouldPauseForHitl) {
      const marker = {
        profileKey: profileConfig.profileKey,
        profileName: profileConfig.profileName,
        status: "WAITING_USER",
        pendingStepIndex: idx,
        originalUserPrompt,
        history
      };
      await addMessage(taskPayload?.task?.id, "system", `${EXEC_PROFILE_STATE_TAG}\n${JSON.stringify(marker)}`);
      return {
        pausedForHitl: true,
        pausedStepIndex: idx,
        history
      };
    }
  }

  const completionMarker = {
    profileKey: profileConfig.profileKey,
    profileName: profileConfig.profileName,
    status: "COMPLETED",
    completedAt: new Date().toISOString(),
    originalUserPrompt,
    history
  };
  await addMessage(taskPayload?.task?.id, "system", `${EXEC_PROFILE_STATE_TAG}\n${JSON.stringify(completionMarker)}`);
  return {
    pausedForHitl: false,
    history
  };
}

function resolveGradleWrapper(projectPath) {
  const gradlewBat = path.join(projectPath, "gradlew.bat");
  const gradlewSh = path.join(projectPath, "gradlew");
  if (IS_WINDOWS && fs.existsSync(gradlewBat)) {
    const spec = buildExecutableCommand("gradlew.bat", []);
    return { command: spec.command, baseArgs: spec.args, cwd: projectPath };
  }
  if (fs.existsSync(gradlewSh)) {
    return { command: IS_WINDOWS ? "bash" : "/bin/bash", baseArgs: ["./gradlew"], cwd: projectPath };
  }
  if (fs.existsSync(gradlewBat)) {
    const spec = buildExecutableCommand("gradlew.bat", []);
    return { command: spec.command, baseArgs: spec.args, cwd: projectPath };
  }
  throw new Error(`Gradle wrapper not found in ${projectPath}`);
}

function hasGradleWrapper(projectPath) {
  return fs.existsSync(path.join(projectPath, "gradlew.bat")) || fs.existsSync(path.join(projectPath, "gradlew"));
}

function isMissingAndroidSdkError(text) {
  const raw = String(text || "").toLowerCase();
  return (
    raw.includes("sdk location not found")
    || raw.includes("android_home")
    || raw.includes("android_sdk_root")
    || raw.includes("sdk.dir path")
  );
}

function findAndroidSdkPath() {
  const candidates = [];
  const envSdk = String(process.env.ANDROID_HOME || process.env.ANDROID_SDK_ROOT || "").trim();
  if (envSdk) {
    candidates.push(envSdk);
  }

  const localAppData = String(process.env.LOCALAPPDATA || "").trim();
  const userProfile = String(process.env.USERPROFILE || "").trim();
  const homeDir = os.homedir();
  if (IS_WINDOWS) {
    if (localAppData) {
      candidates.push(path.join(localAppData, "Android", "Sdk"));
    }
    if (userProfile) {
      candidates.push(path.join(userProfile, "AppData", "Local", "Android", "Sdk"));
    }
    candidates.push("C:\\Android\\Sdk");
  } else if (IS_MACOS) {
    candidates.push(path.join(homeDir, "Library", "Android", "sdk"));
    candidates.push(path.join(homeDir, "Library", "Android", "Sdk"));
    candidates.push("/opt/android-sdk");
  } else {
    candidates.push(path.join(homeDir, "Android", "Sdk"));
    candidates.push(path.join(homeDir, "Android", "sdk"));
    candidates.push("/opt/android-sdk");
    candidates.push("/usr/local/android-sdk");
  }

  for (const candidate of candidates) {
    if (!candidate) continue;
    const resolved = path.resolve(candidate);
    if (fs.existsSync(resolved) && fs.statSync(resolved).isDirectory()) {
      return resolved;
    }
  }
  return "";
}

function ensureAndroidLocalProperties(projectPath) {
  const filePath = path.join(projectPath, "local.properties");
  try {
    if (fs.existsSync(filePath)) {
      const current = fs.readFileSync(filePath, "utf8");
      if (current.split(/\r?\n/).some((line) => line.trim().startsWith("sdk.dir="))) {
        return { configured: true, source: "existing-file", sdkPath: "" };
      }
    }

    const sdkPath = findAndroidSdkPath();
    if (!sdkPath) {
      return { configured: false, source: "missing-sdk", sdkPath: "" };
    }

    const normalized = sdkPath.replace(/\\/g, "/");
    const line = `sdk.dir=${normalized}\n`;
    if (fs.existsSync(filePath)) {
      fs.appendFileSync(filePath, currentEndsWithNewline(fs.readFileSync(filePath, "utf8")) ? line : `\n${line}`, "utf8");
    } else {
      fs.writeFileSync(filePath, line, "utf8");
    }
    return { configured: true, source: "auto-created", sdkPath };
  } catch (error) {
    return { configured: false, source: `error:${error.message}`, sdkPath: "" };
  }
}

function currentEndsWithNewline(text) {
  return /\r?\n$/.test(String(text || ""));
}

function isJavaHome(candidate) {
  if (!candidate) return false;
  const javaBinary = path.join(candidate, "bin", IS_WINDOWS ? "java.exe" : "java");
  return fs.existsSync(javaBinary);
}

function resolveGradleJavaHome() {
  const candidates = [];
  if (GRADLE_JAVA_HOME) candidates.push(GRADLE_JAVA_HOME);

  if (IS_MACOS) {
    candidates.push(
      "/Applications/Android Studio.app/Contents/jbr/Contents/Home",
      "/opt/homebrew/opt/openjdk@21/libexec/openjdk.jdk/Contents/Home",
      "/usr/local/opt/openjdk@21/libexec/openjdk.jdk/Contents/Home",
      "/opt/homebrew/opt/openjdk@17/libexec/openjdk.jdk/Contents/Home",
      "/usr/local/opt/openjdk@17/libexec/openjdk.jdk/Contents/Home"
    );
  }

  const currentJavaHome = String(process.env.JAVA_HOME || "").trim();
  if (currentJavaHome) candidates.push(currentJavaHome);
  return candidates.map((candidate) => path.resolve(candidate)).find(isJavaHome) || "";
}

async function runGradleTask(projectPath, taskName, taskLogDir) {
  const wrapper = resolveGradleWrapper(projectPath);
  const args = [...wrapper.baseArgs, taskName, "--console=plain"];
  const javaHome = resolveGradleJavaHome();
  const gradleEnv = { ...process.env };
  if (javaHome) {
    gradleEnv.JAVA_HOME = javaHome;
    prependExecutablePath(gradleEnv, path.join(javaHome, "bin"));
  }
  const logPath = path.join(taskLogDir, `gradle-${sanitizeFileComponent(taskName)}.log`);
  fs.writeFileSync(logPath, `JAVA_HOME=${javaHome || "runtime-default"}\n`, "utf8");
  const result = await runCommand({
    command: wrapper.command,
    args,
    cwd: wrapper.cwd,
    timeoutMs: GRADLE_TIMEOUT_MS,
    env: gradleEnv,
    liveLogFile: logPath,
  });

  if (result.timedOut) {
    throw new Error(`Gradle task ${taskName} timed out after ${GRADLE_TIMEOUT_MS}ms`);
  }
  if (result.code !== 0) {
    throw new Error(`Gradle task ${taskName} failed:\n${clipText(result.stderr || result.stdout, 2000)}`);
  }
}

function sha256File(filePath) {
  const hash = crypto.createHash("sha256");
  hash.update(fs.readFileSync(filePath));
  return hash.digest("hex").toUpperCase();
}

function normalizeChecksum(value) {
  return String(value || "").trim().replace(/^sha-?256:/i, "").toUpperCase();
}

function findPreviousApkChecksum(taskPayload) {
  const artifacts = Array.isArray(taskPayload?.artifacts) ? taskPayload.artifacts : [];
  return artifacts
    .filter((artifact) => String(artifact?.type || "").toLowerCase() === "apk")
    .sort((left, right) => (Number(right?.iteration) || 0) - (Number(left?.iteration) || 0))
    .map((artifact) => normalizeChecksum(artifact?.checksum))
    .find(Boolean) || "";
}

function validateBuiltApk(apkPath, options = {}) {
  const stat = fs.statSync(apkPath);
  const notBeforeMs = Number(options.notBeforeMs || 0);
  if (notBeforeMs > 0 && stat.mtimeMs < notBeforeMs - 2_000) {
    throw new Error(`APK is older than the current build: ${apkPath}`);
  }
  const checksum = sha256File(apkPath);
  const previousChecksum = normalizeChecksum(options.previousChecksum);
  if (previousChecksum && checksum === previousChecksum) {
    throw new Error(`Generated APK is byte-for-byte identical to the previous task artifact (${checksum}); refusing stale review artifact.`);
  }
  return { apkPath, checksum, sizeBytes: stat.size, mtimeMs: stat.mtimeMs };
}

function findLatestApkInProject(projectPath, notBeforeMs = 0) {
  if (APK_SOURCE_PATH) {
    const forced = path.resolve(APK_SOURCE_PATH);
    if (!fs.existsSync(forced)) {
      throw new Error(`Configured APK source path does not exist: ${forced}`);
    }
    validateBuiltApk(forced, { notBeforeMs });
    return forced;
  }

  const candidates = [];
  const queue = [projectPath];
  const skipDirs = new Set([".git", ".gradle", ".idea", "node_modules", ".kotlin"]);

  while (queue.length > 0) {
    const current = queue.shift();
    let entries = [];
    try {
      entries = fs.readdirSync(current, { withFileTypes: true });
    } catch (_ignored) {
      continue;
    }

    for (const entry of entries) {
      const fullPath = path.join(current, entry.name);
      if (entry.isDirectory()) {
        if (!skipDirs.has(entry.name)) {
          queue.push(fullPath);
        }
        continue;
      }

      if (entry.isFile() && entry.name === "app-debug.apk") {
        candidates.push(fullPath);
      }
    }
  }

  if (candidates.length === 0) {
    throw new Error(`No app-debug.apk found under ${projectPath}`);
  }

  candidates.sort((a, b) => {
    const aTime = fs.statSync(a).mtimeMs;
    const bTime = fs.statSync(b).mtimeMs;
    return bTime - aTime;
  });
  const latest = candidates[0];
  if (notBeforeMs > 0 && fs.statSync(latest).mtimeMs < notBeforeMs - 2_000) {
    throw new Error(`No APK produced by the current build under ${projectPath}`);
  }
  return latest;
}

async function processTask(taskPayload) {
  const task = taskPayload?.task;
  const taskId = task?.id;
  if (!taskId) {
    throw new Error("Invalid task payload: missing task.id");
  }

  const taskLogDir = path.join(LOG_DIR, sanitizeFileComponent(taskId));
  ensureDirectory(taskLogDir);
  setRuntimeStatus(RuntimeState.TASK_RECEIVED, {
    taskId,
    project: taskPayload?.project?.path || taskPayload?.projectPath || null,
    engine: String(task.agentEngine || "CODEX").trim().toUpperCase() || "CODEX",
    action: `Tarea recibida: ${task.title || taskId}`,
  });

  const runtimeTimelinePath = path.join(taskLogDir, "runtime.log");
  fs.writeFileSync(runtimeTimelinePath, "", "utf8");
  const summaryLines = [];
  const addSummary = (line) => {
    const stamped = `[${new Date().toISOString()}] ${line}`;
    summaryLines.push(stamped);
    appendFileSafe(runtimeTimelinePath, `${stamped}\n`);
  };
  addSummary(`Task received: ${task.title || taskId}.`);

  console.log(`[agent] processing task=${taskId} title="${task.title}"`);
  const sourceProjectPath = requireProjectPath(taskPayload);
  let projectPath = sourceProjectPath;
  let gradleAvailable = hasGradleWrapper(projectPath);
  let sdkConfig = null;
  let managedTaskWorktree = false;
  let executionStartHead = "";
  let builtApk = null;
  let sourceStateBeforeBuild = "";

  await claimHeartbeat(taskId);
  const runtimeLogSync = startRuntimeLogSync(taskId, taskLogDir);

  const heartbeatInterval = setInterval(() => {
    claimHeartbeat(taskId).catch((error) => {
      console.error(`[agent] heartbeat failed task=${taskId}: ${error.message}`);
    });
  }, HEARTBEAT_MS);

  let originalBranch = "";
  const selectedEngine = String(task.agentEngine || "CODEX").trim().toUpperCase() || "CODEX";
  setRuntimeStatus(RuntimeState.WORKING, {
    taskId,
    project: projectPath,
    engine: selectedEngine,
    action: `Ejecutando ${selectedEngine}`,
  });

  try {
    const executionWorkspace = await prepareTaskWorktree(taskPayload, { sourcePath: sourceProjectPath });
    projectPath = executionWorkspace.projectPath;
    managedTaskWorktree = executionWorkspace.managed;
    gradleAvailable = hasGradleWrapper(projectPath);
    addSummary(
      managedTaskWorktree
        ? `Isolated task worktree ${executionWorkspace.created ? "created" : "reused"}: ${projectPath}`
        : `Task worktree isolation disabled; using project checkout: ${projectPath}`
    );
    originalBranch = await getCurrentBranch(projectPath);
    addSummary(`Original branch before task: ${originalBranch || "(unknown)"}`);

    await ensureBranch(projectPath, task.branchName);
    await ensureLocalGitExclude(projectPath);
    executionStartHead = await getGitHead(projectPath);
    addSummary(`Checked out branch ${task.branchName}`);
    await addMessage(
      taskId,
      "system",
      `Agent started on branch ${task.branchName}${managedTaskWorktree ? ` in isolated worktree ${projectPath}` : ""}`
    );
    if (!poolWarningsNotified && POOL_STARTUP_WARNINGS.length > 0) {
      await addMessage(taskId, "system", `Token pools warning:\n- ${POOL_STARTUP_WARNINGS.join("\n- ")}`);
      addSummary(`Token pool warnings emitted: ${POOL_STARTUP_WARNINGS.length}.`);
      poolWarningsNotified = true;
    }

    const executionProfileConfig = parseExecutionProfileFromTask(taskPayload);
    const llmRuntimeConfig = await getLlmRuntimeConfigForAgent()
      .then((payload) => normalizeLlmRuntimeConfig(payload || {}))
      .catch((error) => {
        const warning = `LLM runtime config unavailable, using local defaults: ${clipText(error?.message || String(error), 300)}`;
        addSummary(warning);
        return normalizeLlmRuntimeConfig(null);
      });
    const runtimeModelForLogs = selectedEngine === "CODEX" ? "(hidden-for-codex)" : (llmRuntimeConfig.model || "-");
    addSummary(
      `Runtime LLM: provider=${llmRuntimeConfig.provider} model=${runtimeModelForLogs} ctx=${llmRuntimeConfig.modelContextWindow || "-"}`
    );
    if (executionProfileConfig && executionProfileConfig.steps.length > 0) {
      const stepRuntimeSummary = executionProfileConfig.steps
        .map((step, idx) => `${idx + 1}:${step.agentEngine}/${step.modelProvider || "ALL"}/${step.model || "-"}`)
        .join(" -> ");
      addSummary(`Task default engine ${selectedEngine}; execution profile step engines: ${stepRuntimeSummary}`);
      await addMessage(taskId, "system", `Execution profile runtime activo: ${executionProfileConfig.profileName} (${executionProfileConfig.profileKey})`);
      await addMessage(taskId, "system", `Engine seleccionado por execution profile: ${stepRuntimeSummary}`);
    } else {
      addSummary(`Task engine selected: ${selectedEngine}`);
      const runtimeMessage = selectedEngine === "CODEX"
        ? `Runtime LLM aplicado: ${llmRuntimeConfig.provider} Â· API mode Â· ctx ${llmRuntimeConfig.modelContextWindow || "n/d"}`
        : `Runtime LLM aplicado: ${llmRuntimeConfig.provider} Â· ${llmRuntimeConfig.model || "-"} Â· ctx ${llmRuntimeConfig.modelContextWindow || "n/d"}`;
      await addMessage(taskId, "system", runtimeMessage);
      await addMessage(taskId, "system", `Engine seleccionado: ${selectedEngine}`);
    }

    const claudeRuntimeConfig = await getClaudeRuntimeConfigForAgent()
      .then((payload) => normalizeClaudeRuntimeConfig(payload || {}))
      .catch((error) => {
        addSummary(`Claude runtime config unavailable: ${clipText(error?.message || String(error), 260)}`);
        return null;
      });
    if (claudeRuntimeConfig) {
      const enabled = Boolean(claudeRuntimeConfig.enabled);
      addSummary(`Runtime Claude: enabled=${enabled} model=${claudeRuntimeConfig.model || "-"}`);
    }

    if (executionProfileConfig && executionProfileConfig.steps.length > 0) {
      addSummary(`Execution profile runtime detected: ${executionProfileConfig.profileName} Â· ${executionProfileConfig.steps.length} step(s).`);
      const pipelineResult = await runExecutionProfilePipeline({
        taskPayload,
        projectPath,
        taskLogDir,
        profileConfig: executionProfileConfig,
        llmRuntimeConfig,
        claudeRuntimeConfig
      });
      if (pipelineResult.pausedForHitl) {
        const pausedStep = executionProfileConfig.steps[pipelineResult.pausedStepIndex];
        const pausedName = pausedStep?.name || `Paso ${Number(pipelineResult.pausedStepIndex) + 1}`;
        addSummary(`Pipeline pausado en WAITING_USER tras step ${Number(pipelineResult.pausedStepIndex) + 1}: ${pausedName}.`);
        await updateStatus(taskId, "WAITING_USER", `HITL requerido tras step ${Number(pipelineResult.pausedStepIndex) + 1}: ${pausedName}`);
        return;
      }
      addSummary("Execution profile pipeline completed.");
    } else {
      if (selectedEngine === "CODEX") {
        await addMessage(
          taskId,
          "system",
          `Codex iteration ${task.iteration} started. Raw decisions, commands and tool output are streamed to the live runtime log; BUILDING will not start until the Codex process tree has closed.`
        );
        addSummary(`Codex iteration ${task.iteration} process execution started.`);
      }
      const executionResult = selectedEngine === "CLAUDE_CODE"
        ? await runClaude(taskPayload, projectPath, taskLogDir, { claudeRuntimeConfig })
        : selectedEngine === "OPENCODE"
          ? await runOpencode(taskPayload, projectPath, taskLogDir, {
            llmRuntimeConfig,
            claudeRuntimeConfig,
          })
          : await runCodex(taskPayload, projectPath, taskLogDir, {
            llmRuntimeConfig,
            claudeRuntimeConfig,
          });
      if (executionResult.output) {
        const assistantRole = selectedEngine === "CLAUDE_CODE"
          ? "claude_code"
          : selectedEngine === "OPENCODE"
            ? "opencode"
            : "codex";
        await addMessage(taskId, assistantRole, clipText(executionResult.output, 10000));
        addSummary(`${selectedEngine} execution completed.`);
        if (executionResult.accountLabel) {
          await addMessage(taskId, "system", `${selectedEngine} account used: ${executionResult.accountLabel}`);
          addSummary(`${selectedEngine} account used: ${executionResult.accountLabel}`);
        }
        if (executionResult.warning) {
          await addMessage(taskId, "system", executionResult.warning);
          addSummary(executionResult.warning);
        }
      }
    }

    const gradleAvailableAfterExecution = hasGradleWrapper(projectPath);
    if (!gradleAvailable && gradleAvailableAfterExecution) {
      await addMessage(taskId, "system", "Gradle wrapper detected after agent execution.");
      addSummary("Gradle wrapper was created by the agent during execution.");
    }
    gradleAvailable = gradleAvailableAfterExecution;

    if (!gradleAvailable) {
      await addMessage(taskId, "system", "Gradle wrapper not found; treating repository as non-Android for this iteration.");
      addSummary("No Gradle wrapper detected. Non-Android pipeline enabled (no APK build).");
    } else {
      sdkConfig = ensureAndroidLocalProperties(projectPath);
      if (sdkConfig.configured && sdkConfig.source === "auto-created") {
        await addMessage(taskId, "system", `Android SDK detected automatically (${sdkConfig.sdkPath}) and local.properties configured.`);
        addSummary(`Configured local.properties sdk.dir from detected SDK path ${sdkConfig.sdkPath}.`);
      } else if (!sdkConfig.configured && sdkConfig.source === "missing-sdk") {
        await addMessage(taskId, "system", "Android SDK path not detected in this environment; Gradle checks may be skipped if SDK error appears.");
        addSummary("Android SDK path not detected; enabling graceful skip for SDK-missing Gradle failures.");
      }
    }

    sourceStateBeforeBuild = await computeSourceStateFingerprint(projectPath);
    setRuntimeStatus(RuntimeState.BUILDING, {
      taskId,
      project: projectPath,
      engine: selectedEngine,
      action: "Ejecutando build y pruebas",
    });
    await updateStatus(taskId, "BUILDING");
    addSummary("Task moved to BUILDING.");

    // Build now, but publish only after tests, commit, and final clean-worktree checks bind
    // the APK to the exact reviewed source state.
    if (RUN_BUILD && gradleAvailable) {
      try {
        const buildStartedAt = Date.now();
        await runGradleTask(projectPath, GRADLE_BUILD_TASK, taskLogDir);
        await addMessage(taskId, "system", `Gradle ${GRADLE_BUILD_TASK} succeeded.`);
        addSummary(`Gradle ${GRADLE_BUILD_TASK} succeeded.`);
        const apkPath = findLatestApkInProject(projectPath, buildStartedAt);
        builtApk = validateBuiltApk(apkPath, {
          notBeforeMs: buildStartedAt,
          previousChecksum: findPreviousApkChecksum(taskPayload),
        });
        await addMessage(taskId, "system", `APK built and held for validation: SHA-256 ${builtApk.checksum}`);
        addSummary(`APK built and held for validation: ${apkPath} · SHA-256 ${builtApk.checksum}.`);
      } catch (error) {
        if (isMissingAndroidSdkError(error.message)) {
          await addMessage(taskId, "system", `Gradle ${GRADLE_BUILD_TASK} skipped: Android SDK not configured in worker environment.`);
          addSummary(`Gradle ${GRADLE_BUILD_TASK} skipped due to missing Android SDK.`);
        } else {
          throw error;
        }
      }
    } else if (RUN_BUILD && !gradleAvailable) {
      await addMessage(taskId, "system", "APK build skipped (non-Android project without gradle wrapper).");
      addSummary("APK build skipped because gradle wrapper is missing.");
    } else {
      await addMessage(taskId, "system", "Gradle build skipped (JARVIS_RUN_BUILD=false).");
      addSummary("Gradle build skipped.");
    }

    if (RUN_TESTS && gradleAvailable) {
      try {
        await runGradleTask(projectPath, GRADLE_TEST_TASK, taskLogDir);
        await addMessage(taskId, "system", `Gradle ${GRADLE_TEST_TASK} succeeded.`);
        addSummary(`Gradle ${GRADLE_TEST_TASK} succeeded.`);
      } catch (error) {
        if (isMissingAndroidSdkError(error.message)) {
          await addMessage(taskId, "system", `Gradle ${GRADLE_TEST_TASK} skipped: Android SDK not configured in worker environment.`);
          addSummary(`Gradle ${GRADLE_TEST_TASK} skipped due to missing Android SDK.`);
        } else {
          throw error;
        }
      }
    } else if (RUN_TESTS && !gradleAvailable) {
      await addMessage(taskId, "system", "Gradle tests skipped (non-Android project without gradle wrapper).");
      addSummary("Gradle tests skipped because gradle wrapper is missing.");
    } else {
      await addMessage(taskId, "system", "Gradle tests skipped (JARVIS_RUN_TESTS=false).");
      addSummary("Gradle tests skipped.");
    }

    const sourceStateAfterChecks = await computeSourceStateFingerprint(projectPath);
    if (sourceStateAfterChecks !== sourceStateBeforeBuild) {
      throw new Error("Build or tests changed the source state after the APK was produced; refusing to bind that APK to a different commit.");
    }

    const gitResult = await gitAutoCommitAndPush(projectPath, task, taskId);
    await addMessage(taskId, "system", gitResult.summary);
    addSummary(gitResult.summary);
    const finalHead = await getGitHead(projectPath);
    if (Number(task.iteration || 0) > 0 && executionStartHead === finalHead) {
      throw new Error("Feedback iteration produced no new source commit; refusing to publish a review artifact.");
    }
    await assertTrackedWorktreeClean(projectPath);

    if (builtApk) {
      setRuntimeStatus(RuntimeState.UPLOADING_ARTIFACT, {
        taskId,
        project: projectPath,
        engine: selectedEngine,
        action: `Publicando ${path.basename(builtApk.apkPath)}`,
      });
      await uploadApk(taskId, builtApk.apkPath);
      await addMessage(
        taskId,
        "system",
        `APK registered from commit ${finalHead.slice(0, 12)} · SHA-256 ${builtApk.checksum} · ${builtApk.sizeBytes} bytes`
      );
      addSummary(`APK registered from commit ${finalHead} · SHA-256 ${builtApk.checksum}.`);
    }

    await updateStatus(taskId, "READY_FOR_REVIEW");
    addSummary("Task moved to READY_FOR_REVIEW.");
    console.log(`[agent] task=${taskId} moved to READY_FOR_REVIEW`);
  } catch (error) {
    const errText = clipText(error.message || String(error), 2000);
    console.error(`[agent] task=${taskId} failed: ${errText}`);
    setRuntimeStatus(RuntimeState.WAITING_USER, {
      taskId,
      project: projectPath,
      engine: selectedEngine,
      action: "La tarea necesita intervencion",
      message: errText,
    });
    if (
      selectedEngine === "CODEX"
      && isCodexUpdateRequiredError(errText)
      && !codexRecoveryAttemptedTasks.has(taskId)
    ) {
      codexRecoveryAttemptedTasks.add(taskId);
      pendingCodexRecoveryTaskId = taskId;
      await addMessage(
        taskId,
        "system",
        "El fallo parece causado por una version antigua de Codex. El agente comprobara y actualizara Codex cuando quede en reposo; si se actualiza, reintentara esta tarea una sola vez."
      ).catch((messageError) => {
        console.warn(`[agent][update] unable to announce Codex recovery task=${taskId}: ${messageError.message}`);
      });
      addSummary("Codex update recovery scheduled for the next idle cycle.");
    }
    await updateStatus(taskId, "WAITING_USER", errText);
    addSummary(`Agent error: ${errText}`);
  } finally {
    clearInterval(heartbeatInterval);
    if (
      RESTORE_ORIGINAL_BRANCH &&
      !managedTaskWorktree &&
      originalBranch &&
      originalBranch !== "HEAD" &&
      originalBranch !== task.branchName
    ) {
      const restore = await runExecutableCommand({
        executable: "git",
        args: ["checkout", originalBranch],
        cwd: projectPath,
        timeoutMs: 30_000,
      });
      if (restore.code === 0) {
        addSummary(`Restored original branch ${originalBranch} after task.`);
      } else {
        addSummary(`Failed to restore original branch ${originalBranch}: ${clipText(restore.stderr || restore.stdout, 400)}`);
      }
    }
    try {
      await runtimeLogSync.stop();
    } catch (syncError) {
      console.error(`[agent] failed to finalize runtime log task=${taskId}: ${syncError.message}`);
    }
    try {
      const summaryPath = path.join(taskLogDir, "agent-summary.log");
      fs.writeFileSync(summaryPath, summaryLines.join("\n") + "\n", "utf8");
      await uploadAgentLog(taskId, summaryPath);
    } catch (uploadError) {
      console.error(`[agent] failed to upload agent log for task=${taskId}: ${uploadError.message}`);
    }
  }
}

async function main() {
  ensureDirectory(LOG_DIR);
  if (!AGENT_TOKEN) {
    throw new Error("JARVIS_AGENT_TOKEN is required. Public Agent packages never include credentials.");
  }
  setRuntimeStatus(RuntimeState.STARTING, {
    action: "Iniciando y verificando el registro del agente",
  });
  console.log(
    `[agent] starting id=${AGENT_ID} version=${AGENT_RELEASE_VERSION} baseUrl=${BASE_URL} codex=${ENABLE_CODEX} tests=${RUN_TESTS} build=${RUN_BUILD} oneShot=${ONE_SHOT} backendAutoRestart=${BACKEND_AUTORESTART_ENABLED}`
  );
  console.log(`[agent] auth token accounts configured=${AGENT_AUTH_ACCOUNTS.length} active=${currentAgentAuthAccount()?.label || "n/a"}`);
  if (POOL_STARTUP_WARNINGS.length > 0) {
    console.warn(`[agent] token pool warnings:\n- ${POOL_STARTUP_WARNINGS.join("\n- ")}`);
  }

  const bootstrap = await bootstrapAgentDeviceWithRetry();
  const agentDeviceId = String(bootstrap?.agent?.id || "").trim();
  const ownerId = String(bootstrap?.ownerUserId || OWNER_USER_ID || "").trim();
  console.log(
    `[agent] bootstrap verified owner=${ownerId || "legacy-local-user"} device=${agentDeviceId} agentId=${AGENT_ID}`
  );
  patchRuntimeStatus({
    backend: {
      url: BASE_URL,
      connected: true,
      lastHeartbeatAt: new Date().toISOString(),
    },
  });

  try {
    const synced = await syncAgentWorkspaces();
    console.log(`[agent] workspace sync ok count=${synced}`);
  } catch (error) {
    console.warn(`[agent] workspace sync failed: ${error.message}`);
  }

  const heartbeatLoop = setInterval(() => {
    sendAgentHeartbeat(null)
      .then(() => {
        patchRuntimeStatus({
          backend: {
            url: BASE_URL,
            connected: true,
            lastHeartbeatAt: new Date().toISOString(),
          },
        });
      })
      .catch((error) => {
        patchRuntimeStatus({
          backend: {
            url: BASE_URL,
            connected: false,
            lastError: clipText(error.message, 300),
            lastHeartbeatAt: runtimeStatus.current?.backend?.lastHeartbeatAt || null,
          },
        });
        console.warn(`[agent] global heartbeat failed: ${error.message}`);
      });
  }, Math.max(HEARTBEAT_MS, 3000));

  const workspaceLoop = setInterval(() => {
    syncAgentWorkspaces().catch((error) => {
      console.warn(`[agent] workspace sync loop failed: ${error.message}`);
    });
  }, Math.max(WORKSPACE_SYNC_MS, 15000));

  let idleSince = Date.now();
  setRuntimeStatus(RuntimeState.LISTENING, {
    action: "A la escucha de comandos y tareas",
  });
  try {
    const startupMaintenance = await runIdleMaintenance();
    if (startupMaintenance.restartRequired) {
      console.log("[agent] restart requested by startup maintenance.");
      return;
    }
    while (true) {
      try {
        const claimedCommand = await claimNextAgentCommand();
        if (claimedCommand) {
          idleSince = Date.now();
          await processAgentCommand(claimedCommand);
          if (ONE_SHOT) {
            console.log("[agent] one-shot command completed, exiting.");
            return;
          }
          setRuntimeStatus(RuntimeState.LISTENING, {
            action: "A la escucha de comandos y tareas",
          });
          continue;
        }

        const claimed = await claimNextTask();
        if (!claimed) {
          if (ONE_SHOT && (Date.now() - idleSince) >= ONE_SHOT_IDLE_TIMEOUT_MS) {
            console.log(`[agent] one-shot idle timeout reached (${ONE_SHOT_IDLE_TIMEOUT_MS}ms), exiting.`);
            return;
          }
          const maintenance = await runIdleMaintenance();
          if (maintenance.restartRequired) {
            console.log("[agent] restart requested after agent update.");
            return;
          }
          await sleep(POLL_MS);
          continue;
        }

        idleSince = Date.now();
        await processTask(claimed);
        if (ONE_SHOT) {
          console.log("[agent] one-shot task completed, exiting.");
          return;
        }
        setRuntimeStatus(RuntimeState.LISTENING, {
          action: "A la escucha de comandos y tareas",
        });
      } catch (error) {
        console.error(`[agent] loop error: ${error.message}`);
        setRuntimeStatus(RuntimeState.DEGRADED, {
          action: "Error temporal del bucle; se reintentara",
          message: clipText(error.message, 500),
        });
        await sleep(POLL_MS);
        setRuntimeStatus(RuntimeState.LISTENING, {
          action: "A la escucha de comandos y tareas",
        });
      }
    }
  } finally {
    setRuntimeStatus(RuntimeState.STOPPING, {
      action: "Deteniendo el agente",
    });
    clearInterval(heartbeatLoop);
    clearInterval(workspaceLoop);
  }
}

if (require.main === module) {
  main().catch((error) => {
    console.error(`[agent] fatal: ${error.message}`);
    setRuntimeStatus(RuntimeState.ERROR, {
      action: "El agente se ha detenido por un error fatal",
      message: clipText(error.message, 500),
    });
    process.exit(1);
  });
}

module.exports = {
  executeRemoteProjectHandoff,
  normalizeGitRemoteForHandoff,
  buildExecutableCommand,
  prependExecutablePath,
  resolveWindowsSystemExecutable,
  runCodexCommand,
  terminateChildProcessTree,
  resolveEngineIterationLogDir,
  prepareTaskWorktree,
  releaseManagedTaskWorktree,
  normalizeAdbPolicy,
  createAdbPolicyShim,
  applyAdbPolicyToCodexEnv,
  buildAdbPolicyPrompt,
  normalizeCodexSandboxMode,
  buildCodexSecurityArgs,
  isQaArtifactPath,
  unstageQaArtifacts,
  sha256File,
  findPreviousApkChecksum,
  validateBuiltApk,
  computeSourceStateFingerprint,
};
