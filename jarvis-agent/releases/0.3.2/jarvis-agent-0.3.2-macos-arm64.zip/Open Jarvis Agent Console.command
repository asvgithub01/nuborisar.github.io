#!/usr/bin/env bash
set -euo pipefail

INSTALL_ROOT="${JARVIS_AGENT_INSTALL_ROOT:-$HOME/Library/Application Support/JarvisAgent}"
APP_DIR="${INSTALL_ROOT}/app"
LOG_DIR="${INSTALL_ROOT}/logs"

if [[ ! -f "${APP_DIR}/agent-console.js" ]]; then
  echo "ERROR: no se encontro la consola de Jarvis Agent en ${APP_DIR}." >&2
  read -r -p "Pulsa Enter para cerrar..." _ || true
  exit 1
fi

cd "$APP_DIR"
JARVIS_AGENT_LOG_DIR="$LOG_DIR" exec /usr/bin/env node agent-console.js
