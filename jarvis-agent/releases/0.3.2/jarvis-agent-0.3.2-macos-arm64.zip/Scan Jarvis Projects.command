#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INSTALL_ROOT="${JARVIS_AGENT_INSTALL_ROOT:-$HOME/Library/Application Support/JarvisAgent}"
INSTALLED_SCANNER="${INSTALL_ROOT}/bin/jarvis-agent-projects"

pause_before_close() {
  local code="$?"
  echo
  if [[ "$code" -eq 0 ]]; then
    echo "Escaneo finalizado. Ya puedes cerrar esta ventana."
  else
    echo "El escaneo termino con error (codigo ${code})."
  fi
  if [[ -t 0 ]]; then read -r -p "Pulsa Enter para cerrar..." _ || true; fi
  exit "$code"
}
trap pause_before_close EXIT

clear || true
cat <<'BANNER'
============================================================
  JARVIS - ESCANEAR PROYECTOS DEL MAC
============================================================

Detecta repositorios Git, actualiza el agente y los envia a
Ops y JarvisMobile.
BANNER

if [[ -x "${SCRIPT_DIR}/agent/installers/macos/scan-projects.sh" ]]; then
  SCANNER="${SCRIPT_DIR}/agent/installers/macos/scan-projects.sh"
elif [[ -x "${SCRIPT_DIR}/scan-projects.sh" ]]; then
  SCANNER="${SCRIPT_DIR}/scan-projects.sh"
elif [[ -x "$INSTALLED_SCANNER" ]]; then
  SCANNER="$INSTALLED_SCANNER"
else
  echo "ERROR: no se encuentra la utilidad instalada de Jarvis." >&2
  echo "Vuelve a ejecutar Install Jarvis Agent.command." >&2
  exit 1
fi

"$SCANNER"
