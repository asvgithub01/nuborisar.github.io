# Jarvis Agent para MacBook (agente 2)

Version: 0.3.0

## Instalacion

1. Descomprime este ZIP en el MacBook.
2. En Ops, abre **Settings > Cuenta y agentes** y genera un codigo de vinculacion.
3. Haz doble clic en Install Jarvis Agent.command y pega ese codigo cuando lo solicite.
4. Si macOS lo bloquea, pulsa Control + clic, elige **Abrir** y confirma.
5. Escribe el nombre MagicDNS de Tailscale del backend; no uses una IP.
6. Introduce el token del agente cuando el instalador lo solicite. El ZIP publico no contiene credenciales.
7. Al terminar, autentica codex y gh auth login si el instalador lo indica.

El instalador registra un LaunchAgent por usuario con id <hostname>-jarvis-agent-02,
sin sustituir al agente de Windows. Durante la instalacion escanea los repositorios Git
del Mac mediante raices de desarrollo acotadas, con progreso y timeout por carpeta.
Tambien verifica el id externo/interno del agente antes de sincronizar proyectos.

Cuando clones o borres repositorios, abre Scan Jarvis Projects.command para actualizar
la lista de Ops y JarvisMobile.

## Diagnostico

`ash
./agent/installers/macos/doctor-agent.sh
tail -f "$HOME/Library/Application Support/JarvisAgent/logs/agent.log"
`

Tambien puedes abrir Open Jarvis Agent Console.command; es solo un visor de terminal
y cerrarlo no detiene el servicio.

## Desinstalacion

`ash
./agent/installers/macos/uninstall-agent.sh --purge
`

Este ZIP es un instalador headless versionado; todavia no es un PKG/DMG firmado y notarizado.
