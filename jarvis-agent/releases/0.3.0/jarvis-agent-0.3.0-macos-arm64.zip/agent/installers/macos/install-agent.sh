#!/usr/bin/env bash
set -euo pipefail

LABEL="com.jarvis.agent"
DEFAULT_BACKEND_URL="${JARVIS_BASE_URL:-http://localhost:8080}"
DEFAULT_AGENT_TOKEN="${JARVIS_AGENT_APP_TOKEN:-${JARVIS_AGENT_TOKEN:-}}"
DEFAULT_INSTALL_ROOT="${JARVIS_AGENT_INSTALL_ROOT:-$HOME/Library/Application Support/JarvisAgent}"
DEFAULT_WORKSPACE_ROOT="${JARVIS_WORKSPACE_ROOTS:-$HOME/Projects}"
DEFAULT_AGENT_ID="$(hostname -s 2>/dev/null || hostname)-jarvis-agent-02"

BACKEND_URL="$DEFAULT_BACKEND_URL"
AGENT_TOKEN="$DEFAULT_AGENT_TOKEN"
AGENT_ID="${JARVIS_AGENT_ID:-$DEFAULT_AGENT_ID}"
AGENT_DISPLAY_NAME="${JARVIS_AGENT_DISPLAY_NAME:-Jarvis MacBook (agente 2)}"
AGENT_RELEASE_VERSION="${JARVIS_AGENT_RELEASE_VERSION:-dev}"
OWNER_USER_ID="${JARVIS_OWNER_USER_ID:-}"
PAIRING_CODE="${JARVIS_AGENT_PAIRING_CODE:-}"
WORKSPACE_ROOT="$DEFAULT_WORKSPACE_ROOT"
INSTALL_ROOT="$DEFAULT_INSTALL_ROOT"
START_AGENT="true"
FORCE="false"
SKIP_BACKEND_CHECK="false"
INTERACTIVE="true"

usage() {
  cat <<USAGE
Jarvis Agent macOS installer (segundo agente)

Usage:
  ./install-agent.sh [options]

Options:
  --backend-url URL       Jarvis backend reachable from this Mac.
  --token TOKEN           Agent token. Required; public ZIPs never include one.
  --agent-id ID           Unique id. Default: <hostname>-jarvis-agent-02
  --display-name NAME     Name shown in Ops. Default: Jarvis MacBook (agente 2)
  --agent-version VERSION Release shown in Ops. Usually injected by the ZIP.
  --owner-user-id ID      Optional owner/user scope.
  --pairing-code CODE     One-time code generated in Ops for the logged-in account.
  --workspace-root PATH   Root containing Mac repositories. Default: ~/Projects
  --install-root PATH     Install root. Default: ~/Library/Application Support/JarvisAgent
  --skip-backend-check    Install even when backend health cannot be reached.
  --no-start              Install files and LaunchAgent but do not start it.
  --non-interactive       Do not ask for values already provided as arguments.
  --force                 Overwrite existing config without confirmation.
  -h, --help              Show this help.

Example:
  ./install-agent.sh --backend-url http://rayder.tail124179.ts.net:8080 \
    --token YOUR_AGENT_TOKEN --workspace-root "$HOME/Projects"
USAGE
}

require_value() {
  local option="$1"
  local value="${2:-}"
  if [[ -z "$value" ]]; then
    echo "ERROR: ${option} requires a value." >&2
    exit 2
  fi
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --backend-url)
      require_value "$1" "${2:-}"; BACKEND_URL="$2"; shift 2 ;;
    --token|--agent-app-token|--code)
      require_value "$1" "${2:-}"; AGENT_TOKEN="$2"; shift 2 ;;
    --agent-id)
      require_value "$1" "${2:-}"; AGENT_ID="$2"; shift 2 ;;
    --display-name)
      require_value "$1" "${2:-}"; AGENT_DISPLAY_NAME="$2"; shift 2 ;;
    --agent-version)
      require_value "$1" "${2:-}"; AGENT_RELEASE_VERSION="$2"; shift 2 ;;
    --owner-user-id)
      require_value "$1" "${2:-}"; OWNER_USER_ID="$2"; shift 2 ;;
    --pairing-code)
      require_value "$1" "${2:-}"; PAIRING_CODE="$2"; shift 2 ;;
    --workspace-root)
      require_value "$1" "${2:-}"; WORKSPACE_ROOT="$2"; shift 2 ;;
    --install-root)
      require_value "$1" "${2:-}"; INSTALL_ROOT="$2"; shift 2 ;;
    --skip-backend-check)
      SKIP_BACKEND_CHECK="true"; shift ;;
    --no-start)
      START_AGENT="false"; shift ;;
    --non-interactive)
      INTERACTIVE="false"; shift ;;
    --force)
      FORCE="true"; shift ;;
    -h|--help)
      usage; exit 0 ;;
    *)
      echo "Unknown argument: $1" >&2
      usage >&2
      exit 2 ;;
  esac
done

if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "ERROR: this installer must run on macOS." >&2
  exit 1
fi

if [[ "$INTERACTIVE" == "true" && -t 0 ]]; then
  read -r -p "Backend URL [${BACKEND_URL}]: " input_backend
  [[ -n "$input_backend" ]] && BACKEND_URL="$input_backend"

  read -r -s -p "Agent token [press Enter to keep current/default]: " input_token
  echo
  [[ -n "$input_token" ]] && AGENT_TOKEN="$input_token"

  read -r -p "Agent id [${AGENT_ID}]: " input_agent_id
  [[ -n "$input_agent_id" ]] && AGENT_ID="$input_agent_id"

  read -r -p "Visible name [${AGENT_DISPLAY_NAME}]: " input_display_name
  [[ -n "$input_display_name" ]] && AGENT_DISPLAY_NAME="$input_display_name"

  read -r -p "Ops pairing code (JARVIS-XXXX-XXXX) [optional for an already linked agent]: " input_pairing_code
  [[ -n "$input_pairing_code" ]] && PAIRING_CODE="$input_pairing_code"

  read -r -p "Repositories root [${WORKSPACE_ROOT}]: " input_workspace_root
  [[ -n "$input_workspace_root" ]] && WORKSPACE_ROOT="$input_workspace_root"
fi

for required in BACKEND_URL AGENT_TOKEN AGENT_ID AGENT_DISPLAY_NAME AGENT_RELEASE_VERSION WORKSPACE_ROOT; do
  if [[ -z "${!required}" ]]; then
    echo "ERROR: ${required} is required." >&2
    exit 1
  fi
  if [[ "${!required}" == *$'\n'* || "${!required}" == *$'\r'* ]]; then
    echo "ERROR: ${required} contains an invalid newline." >&2
    exit 1
  fi
done

BACKEND_HOST="${BACKEND_URL#*://}"
BACKEND_HOST="${BACKEND_HOST%%/*}"
BACKEND_HOST="${BACKEND_HOST%%:*}"
if [[ "$BACKEND_HOST" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
  echo "ERROR: backend URL must use the Tailscale MagicDNS name, never a literal IP address." >&2
  exit 1
fi

if [[ -n "$PAIRING_CODE" && ! "$PAIRING_CODE" =~ ^JARVIS-[[:alnum:]]{4}-[[:alnum:]]{4}$ ]]; then
  echo "ERROR: invalid pairing code. Expected JARVIS-XXXX-XXXX." >&2
  exit 1
fi

if ! command -v node >/dev/null 2>&1; then
  echo "ERROR: Node.js 18+ is required. Run Install Jarvis Agent.command for automatic setup." >&2
  exit 1
fi

NODE_VERSION="$(node -v 2>/dev/null || true)"
NODE_MAJOR="${NODE_VERSION#v}"
NODE_MAJOR="${NODE_MAJOR%%.*}"
if [[ ! "$NODE_MAJOR" =~ ^[0-9]+$ || "$NODE_MAJOR" -lt 18 ]]; then
  echo "ERROR: Node.js 18+ is required. Found: ${NODE_VERSION:-unknown}" >&2
  exit 1
fi

BACKEND_URL="${BACKEND_URL%/}"
if [[ "$SKIP_BACKEND_CHECK" != "true" ]]; then
  if ! command -v curl >/dev/null 2>&1; then
    echo "ERROR: curl is required to validate the backend." >&2
    exit 1
  fi
  if ! curl --fail --silent --show-error --connect-timeout 5 --max-time 10 \
      "${BACKEND_URL}/health" >/dev/null; then
    cat >&2 <<ERR
ERROR: Jarvis backend is not reachable at ${BACKEND_URL}.
Start Jarvis on the Windows host, check port 8080/firewall, and use its stable Tailscale MagicDNS name.
Use --skip-backend-check only when you intentionally want an offline install.
ERR
    exit 1
  fi
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
AGENT_SOURCE_DIR="$(cd "${SCRIPT_DIR}/../.." && pwd)"
APP_DIR="${INSTALL_ROOT}/app"
BIN_DIR="${INSTALL_ROOT}/bin"
LOG_DIR="${INSTALL_ROOT}/logs"
CONFIG_FILE="${APP_DIR}/.env"
LAUNCH_AGENTS_DIR="${HOME}/Library/LaunchAgents"
PLIST_FILE="${LAUNCH_AGENTS_DIR}/${LABEL}.plist"
LAUNCH_DOMAIN="gui/$(id -u)"
USER_APP_DIR="${HOME}/Applications/Jarvis Agent"
SCANNER_BIN="${BIN_DIR}/jarvis-agent-projects"
SCANNER_LAUNCHER="${USER_APP_DIR}/Scan Jarvis Projects.command"
CONSOLE_LAUNCHER="${USER_APP_DIR}/Open Jarvis Agent Console.command"

if [[ -f "$CONFIG_FILE" && "$FORCE" != "true" && "$INTERACTIVE" == "true" && -t 0 ]]; then
  read -r -p "Existing config found. Overwrite? [y/N]: " confirm
  case "$confirm" in y|Y|yes|YES) ;; *) echo "Install cancelled."; exit 0 ;; esac
fi

mkdir -p "$APP_DIR" "$BIN_DIR" "$LOG_DIR" "$LAUNCH_AGENTS_DIR" "$USER_APP_DIR" "$WORKSPACE_ROOT"

# Copy runtime assets only; never copy local credentials or historical logs.
cp "${AGENT_SOURCE_DIR}/agent.js" "${APP_DIR}/agent.js"
cp "${AGENT_SOURCE_DIR}/agent-console.js" "${APP_DIR}/agent-console.js"
cp "${AGENT_SOURCE_DIR}/runtime-status.js" "${APP_DIR}/runtime-status.js"
cp "${AGENT_SOURCE_DIR}/update-manager.js" "${APP_DIR}/update-manager.js"
cp "${AGENT_SOURCE_DIR}/restart-agent.js" "${APP_DIR}/restart-agent.js"
cp "${AGENT_SOURCE_DIR}/package.json" "${APP_DIR}/package.json"
cp "${AGENT_SOURCE_DIR}/README.md" "${APP_DIR}/README.md"
cp "${AGENT_SOURCE_DIR}/.env.example" "${APP_DIR}/.env.example"
rm -rf "${APP_DIR}/agents" "${APP_DIR}/skills" "${APP_DIR}/scripts"
[[ -d "${AGENT_SOURCE_DIR}/agents" ]] && cp -R "${AGENT_SOURCE_DIR}/agents" "${APP_DIR}/agents"
[[ -d "${AGENT_SOURCE_DIR}/skills" ]] && cp -R "${AGENT_SOURCE_DIR}/skills" "${APP_DIR}/skills"
[[ -d "${AGENT_SOURCE_DIR}/scripts" ]] && cp -R "${AGENT_SOURCE_DIR}/scripts" "${APP_DIR}/scripts"
cp "${SCRIPT_DIR}/scan-projects.sh" "$SCANNER_BIN"
cp "${SCRIPT_DIR}/Scan Jarvis Projects.command" "$SCANNER_LAUNCHER"
cp "${SCRIPT_DIR}/Open Jarvis Agent Console.command" "$CONSOLE_LAUNCHER"
chmod 755 "$SCANNER_BIN" "$SCANNER_LAUNCHER" "$CONSOLE_LAUNCHER" "${APP_DIR}/agent-console.js" "${APP_DIR}/restart-agent.js"

cat > "$CONFIG_FILE" <<ENV
# Generated by Jarvis Agent macOS installer.
JARVIS_BASE_URL=${BACKEND_URL}
JARVIS_AGENT_TOKEN=${AGENT_TOKEN}
JARVIS_AGENT_ID=${AGENT_ID}
JARVIS_AGENT_DISPLAY_NAME=${AGENT_DISPLAY_NAME}
JARVIS_AGENT_RELEASE_VERSION=${AGENT_RELEASE_VERSION}
JARVIS_OWNER_USER_ID=${OWNER_USER_ID}
JARVIS_AGENT_PAIRING_CODE=${PAIRING_CODE}
JARVIS_WORKSPACE_ROOTS=${WORKSPACE_ROOT}
JARVIS_WORKSPACE_PATHS=
JARVIS_PROJECT_SCAN_ROOTS=${WORKSPACE_ROOT};${HOME}/repos;${HOME}/src;${HOME}/code;${HOME}/workspace;${HOME}/Documents/GitHub;${HOME}/Documents/Playground;${HOME}/Documents/Projects
JARVIS_PROJECT_SCAN_TIMEOUT_SECONDS=30
JARVIS_WORKSPACE_SCAN_DEPTH=3
JARVIS_WORKSPACE_SYNC_MS=60000
JARVIS_AGENT_BOOTSTRAP_MAX_ATTEMPTS=8
JARVIS_AGENT_BOOTSTRAP_RETRY_MS=1500
JARVIS_AGENT_LOG_DIR=${LOG_DIR}
JARVIS_POLL_MS=3000
JARVIS_HEARTBEAT_MS=3000
JARVIS_CODEX_ENABLED=true
JARVIS_CODEX_TIMEOUT_MS=1200000
JARVIS_CODEX_SKIP_GIT_REPO_CHECK=true
JARVIS_CODEX_AUTO_UPDATE=true
JARVIS_CODEX_UPDATE_INTERVAL_HOURS=6
JARVIS_AGENT_AUTO_UPDATE=true
JARVIS_AGENT_UPDATE_URL=https://asvgithub01.github.io/nuborisar.github.io/jarvis-agent/update/stable.json
JARVIS_AGENT_UPDATE_INTERVAL_HOURS=6
JARVIS_RUN_TESTS=true
JARVIS_RUN_BUILD=true
JARVIS_GRADLE_JAVA_HOME=
JARVIS_GIT_AUTO_COMMIT=true
JARVIS_GIT_AUTO_PUSH=true
JARVIS_GIT_PUSH_REMOTE=origin
JARVIS_GIT_AUTO_PR=false
JARVIS_RESTORE_ORIGINAL_BRANCH=true
JARVIS_BACKEND_AUTORESTART_ENABLED=false
JARVIS_BACKEND_HEALTH_PATH=/health
JARVIS_ONE_SHOT=false
ENV
chmod 600 "$CONFIG_FILE"

# Discover repositories already present across the user's Mac. Explicit paths
# avoid relying on a single ~/Projects convention and are synced on first boot.
"$SCANNER_BIN" --no-restart

xml_escape() {
  local value="$1"
  value="${value//&/&amp;}"
  value="${value//</&lt;}"
  value="${value//>/&gt;}"
  value="${value//\"/&quot;}"
  value="${value//\'/&apos;}"
  printf '%s' "$value"
}

RUN_COMMAND="cd \"${APP_DIR}\" && exec /usr/bin/env node agent.js >> \"${LOG_DIR}/agent.log\" 2>> \"${LOG_DIR}/agent.err.log\""
RUN_COMMAND_XML="$(xml_escape "$RUN_COMMAND")"

cat > "$PLIST_FILE" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key><string>${LABEL}</string>
  <key>ProgramArguments</key>
  <array><string>/bin/bash</string><string>-lc</string><string>${RUN_COMMAND_XML}</string></array>
  <key>RunAtLoad</key><true/>
  <key>KeepAlive</key><true/>
  <key>WorkingDirectory</key><string>$(xml_escape "$APP_DIR")</string>
  <key>StandardOutPath</key><string>$(xml_escape "${LOG_DIR}/launchd.out.log")</string>
  <key>StandardErrorPath</key><string>$(xml_escape "${LOG_DIR}/launchd.err.log")</string>
  <key>EnvironmentVariables</key>
  <dict><key>PATH</key><string>/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin</string></dict>
</dict>
</plist>
PLIST

plutil -lint "$PLIST_FILE" >/dev/null

if [[ "$START_AGENT" == "true" ]]; then
  launchctl bootout "$LAUNCH_DOMAIN" "$PLIST_FILE" >/dev/null 2>&1 || true
  if launchctl bootstrap "$LAUNCH_DOMAIN" "$PLIST_FILE" 2>/dev/null; then
    launchctl enable "${LAUNCH_DOMAIN}/${LABEL}" >/dev/null 2>&1 || true
    launchctl kickstart -k "${LAUNCH_DOMAIN}/${LABEL}"
  else
    # Compatibility fallback for older macOS releases.
    launchctl unload "$PLIST_FILE" >/dev/null 2>&1 || true
    launchctl load -w "$PLIST_FILE"
  fi
  echo "Jarvis Agent installed and started as the second agent."
else
  echo "Jarvis Agent installed but not started (--no-start)."
fi

echo "Agent id:      ${AGENT_ID}"
echo "Visible name:  ${AGENT_DISPLAY_NAME}"
echo "Version:       ${AGENT_RELEASE_VERSION}"
echo "Backend:       ${BACKEND_URL}"
echo "Workspaces:    ${WORKSPACE_ROOT}"
echo "Scanner:       ${SCANNER_LAUNCHER}"
echo "Console:       ${CONSOLE_LAUNCHER}"
echo "Install root:  ${INSTALL_ROOT}"
echo "LaunchAgent:   ${PLIST_FILE}"
echo "Logs:          ${LOG_DIR}"
