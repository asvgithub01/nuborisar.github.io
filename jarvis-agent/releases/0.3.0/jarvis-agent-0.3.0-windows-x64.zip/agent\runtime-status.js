"use strict";

const fs = require("node:fs");
const path = require("node:path");

const RuntimeState = Object.freeze({
  STARTING: "STARTING",
  LISTENING: "LISTENING",
  TASK_RECEIVED: "TASK_RECEIVED",
  WORKING: "WORKING",
  BUILDING: "BUILDING",
  UPLOADING_ARTIFACT: "UPLOADING_ARTIFACT",
  UPDATE_PENDING: "UPDATE_PENDING",
  UPDATING_CODEX: "UPDATING_CODEX",
  UPDATING_AGENT: "UPDATING_AGENT",
  WAITING_USER: "WAITING_USER",
  DEGRADED: "DEGRADED",
  ERROR: "ERROR",
  STOPPING: "STOPPING",
});

const VALID_STATES = new Set(Object.values(RuntimeState));

function sanitizeValue(value, key = "") {
  if (value === undefined) return undefined;
  if (value === null || typeof value === "boolean" || typeof value === "number") return value;
  if (typeof value === "string") {
    if (/token|secret|password|authorization|api.?key/i.test(key)) return "[redacted]";
    return value;
  }
  if (Array.isArray(value)) {
    return value.map((entry) => sanitizeValue(entry, key));
  }
  if (typeof value === "object") {
    return Object.fromEntries(
      Object.entries(value)
        .map(([entryKey, entryValue]) => [entryKey, sanitizeValue(entryValue, entryKey)])
        .filter(([, entryValue]) => entryValue !== undefined)
    );
  }
  return String(value);
}

function writeJsonAtomic(filePath, value) {
  const directory = path.dirname(filePath);
  fs.mkdirSync(directory, { recursive: true });
  const temporaryPath = `${filePath}.${process.pid}.${Date.now()}.tmp`;
  fs.writeFileSync(temporaryPath, `${JSON.stringify(value, null, 2)}\n`, {
    encoding: "utf8",
    mode: 0o600,
  });
  try {
    fs.renameSync(temporaryPath, filePath);
  } catch (error) {
    if (process.platform !== "win32" || !fs.existsSync(filePath)) throw error;
    fs.rmSync(filePath, { force: true });
    fs.renameSync(temporaryPath, filePath);
  }
}

class RuntimeStatusStore {
  constructor({ filePath, agentId, agentVersion, platform = process.platform, clock = () => new Date() }) {
    if (!filePath) throw new Error("Runtime status filePath is required");
    this.filePath = path.resolve(filePath);
    this.clock = clock;
    this.base = {
      schemaVersion: 1,
      agentId: String(agentId || "unknown"),
      agentVersion: String(agentVersion || "dev"),
      platform: String(platform || "unknown"),
      hostname: String(detailsHostname()),
      pid: process.pid,
      startedAt: this.clock().toISOString(),
    };
    this.current = null;
  }

  set(state, details = {}) {
    if (!VALID_STATES.has(state)) {
      throw new Error(`Unknown runtime state: ${state}`);
    }
    const safeDetails = sanitizeValue(details);
    const next = {
      ...this.base,
      state,
      updatedAt: this.clock().toISOString(),
      taskId: safeDetails.taskId || null,
      commandId: safeDetails.commandId || null,
      action: safeDetails.action || null,
      message: safeDetails.message || null,
      project: safeDetails.project || null,
      engine: safeDetails.engine || null,
      backend: safeDetails.backend || this.current?.backend || null,
      codex: safeDetails.codex || null,
      update: safeDetails.update || null,
    };
    this.current = next;
    writeJsonAtomic(this.filePath, next);
    return next;
  }

  patch(details = {}) {
    if (!this.current) return null;
    const safeDetails = sanitizeValue(details);
    const next = {
      ...this.current,
      ...safeDetails,
      state: this.current.state,
      updatedAt: this.clock().toISOString(),
    };
    this.current = next;
    writeJsonAtomic(this.filePath, next);
    return next;
  }
}

function detailsHostname() {
  try {
    return require("node:os").hostname();
  } catch (_error) {
    return "unknown";
  }
}

module.exports = {
  RuntimeState,
  RuntimeStatusStore,
  sanitizeValue,
  writeJsonAtomic,
};
