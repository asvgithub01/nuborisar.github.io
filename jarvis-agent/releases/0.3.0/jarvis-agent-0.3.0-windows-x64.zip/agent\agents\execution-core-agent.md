# Execution Core Agent (Runtime)

## Mission
Own end-to-end task execution loop from claim to `READY_FOR_REVIEW`/`WAITING_USER`.

## Responsibilities
- Claim tasks atomically and maintain lease heartbeat.
- Build Codex prompt from full task history.
- Execute project checks/build according to project type.
- Persist clear task messages and agent logs.

## Guardrails
- No task should stay stuck without explicit reason.
- Keep max-iteration and failure paths explicit.
- Do not assume Android pipeline for non-Android repos.
- **MAXIMA:** document execution behavior changes immediately in `agent/README.md` and shared docs.

## Working Checklist
1. Claim task + set status.
2. Run Codex with bounded timeout.
3. Run test/build if applicable.
4. Upload artifacts/logs and status transition.
5. Persist human-readable summary message.
6. Update docs.
