"use strict";

const crypto = require("node:crypto");
const fs = require("node:fs");
const path = require("node:path");
const { spawn } = require("node:child_process");

const CODEX_PACKAGE = "@openai/codex";
const DEFAULT_UPDATE_CHECK_MS = 6 * 60 * 60 * 1000;

function parseVersion(raw) {
  const match = String(raw || "").match(/(?:^|[^\d])v?(\d+)\.(\d+)\.(\d+)(?:[-+][0-9A-Za-z.-]+)?(?:$|[^\d])/);
  if (!match) return null;
  return {
    raw: `${Number(match[1])}.${Number(match[2])}.${Number(match[3])}`,
    parts: [Number(match[1]), Number(match[2]), Number(match[3])],
  };
}

function compareVersions(left, right) {
  const a = typeof left === "string" ? parseVersion(left) : left;
  const b = typeof right === "string" ? parseVersion(right) : right;
  if (!a || !b) throw new Error(`Invalid semantic version comparison: ${left} / ${right}`);
  for (let index = 0; index < 3; index += 1) {
    if (a.parts[index] !== b.parts[index]) return a.parts[index] > b.parts[index] ? 1 : -1;
  }
  return 0;
}

function commandSpec(executable, args, platform = process.platform) {
  if (platform === "win32") return { command: "cmd.exe", args: ["/d", "/s", "/c", executable, ...args] };
  return { command: executable, args };
}

function runProcess(executable, args = [], options = {}) {
  const platform = options.platform || process.platform;
  const spec = commandSpec(executable, args, platform);
  return new Promise((resolve) => {
    let stdout = "";
    let stderr = "";
    let settled = false;
    const child = spawn(spec.command, spec.args, {
      cwd: options.cwd || process.cwd(),
      env: options.env || process.env,
      stdio: ["ignore", "pipe", "pipe"],
      windowsHide: true,
    });
    const finish = (result) => {
      if (settled) return;
      settled = true;
      if (timer) clearTimeout(timer);
      resolve(result);
    };
    const timer = setTimeout(() => {
      child.kill();
      finish({ code: null, stdout, stderr: `${stderr}\nCommand timed out`.trim(), timedOut: true });
    }, Math.max(1_000, options.timeoutMs || 120_000));
    child.stdout.on("data", (chunk) => { stdout += chunk.toString(); });
    child.stderr.on("data", (chunk) => { stderr += chunk.toString(); });
    child.on("error", (error) => finish({ code: null, stdout, stderr: error.message, error }));
    child.on("close", (code) => finish({ code, stdout, stderr, timedOut: false }));
  });
}

function requireSuccessful(result, label) {
  if (!result || result.code !== 0) {
    const detail = String(result?.stderr || result?.stdout || `exit=${result?.code}`).trim();
    throw new Error(`${label} failed: ${detail}`);
  }
  return String(result.stdout || result.stderr || "").trim();
}

function parseNpmVersionOutput(raw) {
  const text = String(raw || "").trim();
  try {
    const parsed = JSON.parse(text);
    if (typeof parsed === "string") return parseVersion(parsed)?.raw || null;
    if (Array.isArray(parsed)) return parseVersion(parsed.at(-1))?.raw || null;
  } catch (_error) {
    // npm can return plain text depending on its version.
  }
  return parseVersion(text)?.raw || null;
}

function isCodexUpdateRequiredError(raw) {
  const text = String(raw || "").toLowerCase();
  return [
    /codex.{0,80}(out of date|too old|update required|requires? (?:a )?newer|unsupported (?:client )?version)/,
    /(please|must|need to).{0,40}(update|upgrade).{0,40}codex/,
    /unsupported (?:codex )?(?:cli |client )?version/,
    /minimum (?:supported )?codex version/,
  ].some((pattern) => pattern.test(text));
}

async function inspectCodex({ runner = runProcess } = {}) {
  const locator = process.platform === "win32" ? "where" : "which";
  const located = await runner(locator, ["codex"], { timeoutMs: 20_000 });
  const result = await runner("codex", ["--version"], { timeoutMs: 20_000 });
  const output = requireSuccessful(result, "Codex version detection");
  const version = parseVersion(output)?.raw;
  if (!version) throw new Error(`Codex returned an unrecognized version: ${output}`);
  const executablePath = located?.code === 0
    ? String(located.stdout || "").split(/\r?\n/).map((line) => line.trim()).find(Boolean) || null
    : null;
  return { version, output, executablePath };
}

async function fetchLatestCodexVersion({ runner = runProcess } = {}) {
  const result = await runner("npm", ["view", CODEX_PACKAGE, "version", "--json"], { timeoutMs: 45_000 });
  const output = requireSuccessful(result, "Codex registry lookup");
  const version = parseNpmVersionOutput(output);
  if (!version) throw new Error(`npm returned an unrecognized Codex version: ${output}`);
  return version;
}

async function verifyCodexNpmInstall({ runner = runProcess } = {}) {
  const result = await runner("npm", ["list", "--global", CODEX_PACKAGE, "--depth=0", "--json"], { timeoutMs: 30_000 });
  if (result.code !== 0) return false;
  try {
    const parsed = JSON.parse(result.stdout || "{}");
    return Boolean(parsed.dependencies?.[CODEX_PACKAGE]?.version);
  } catch (_error) {
    return false;
  }
}

async function updateCodexIfNeeded({
  runner = runProcess,
  onState = () => {},
  logger = console,
  force = false,
  skippedVersions = new Set(),
} = {}) {
  const current = await inspectCodex({ runner });
  const latestVersion = await fetchLatestCodexVersion({ runner });
  const npmManaged = await verifyCodexNpmInstall({ runner });
  if (!force && compareVersions(latestVersion, current.version) <= 0) {
    return {
      checked: true,
      updated: false,
      currentVersion: current.version,
      latestVersion,
      executablePath: current.executablePath,
      managedBy: npmManaged ? "npm-global" : "unknown",
    };
  }
  if (compareVersions(latestVersion, current.version) <= 0) {
    return {
      checked: true,
      updated: false,
      currentVersion: current.version,
      latestVersion,
      executablePath: current.executablePath,
      managedBy: npmManaged ? "npm-global" : "unknown",
    };
  }
  if (skippedVersions.has(latestVersion)) {
    return {
      checked: true,
      updated: false,
      blockedByCircuitBreaker: true,
      currentVersion: current.version,
      latestVersion,
      executablePath: current.executablePath,
      managedBy: npmManaged ? "npm-global" : "unknown",
    };
  }
  if (!npmManaged) {
    const error = new Error("Codex auto-update was skipped because this installation is not managed by global npm");
    error.currentVersion = current.version;
    error.latestVersion = latestVersion;
    throw error;
  }

  onState({ currentVersion: current.version, latestVersion });
  logger.info?.(`[agent][update] updating Codex ${current.version} -> ${latestVersion}`);
  const install = await runner("npm", ["install", "--global", `${CODEX_PACKAGE}@${latestVersion}`], {
    timeoutMs: 10 * 60 * 1000,
  });
  try {
    requireSuccessful(install, "Codex update");
  } catch (error) {
    error.targetVersion = latestVersion;
    error.currentVersion = current.version;
    error.latestVersion = latestVersion;
    throw error;
  }

  try {
    const verified = await inspectCodex({ runner });
    if (compareVersions(verified.version, latestVersion) !== 0) {
      throw new Error(`post-update version is ${verified.version}, expected ${latestVersion}`);
    }
    return {
      checked: true,
      updated: true,
      previousVersion: current.version,
      currentVersion: verified.version,
      latestVersion,
      executablePath: verified.executablePath || current.executablePath,
      managedBy: "npm-global",
    };
  } catch (error) {
    logger.error?.(`[agent][update] Codex verification failed; rolling back to ${current.version}: ${error.message}`);
    const rollback = await runner("npm", ["install", "--global", `${CODEX_PACKAGE}@${current.version}`], {
      timeoutMs: 10 * 60 * 1000,
    });
    try {
      requireSuccessful(rollback, "Codex rollback");
    } catch (rollbackError) {
      rollbackError.targetVersion = latestVersion;
      rollbackError.currentVersion = current.version;
      rollbackError.latestVersion = latestVersion;
      throw rollbackError;
    }
    const wrapped = new Error(`Codex update verification failed and rollback was applied: ${error.message}`);
    wrapped.targetVersion = latestVersion;
    wrapped.currentVersion = current.version;
    wrapped.latestVersion = latestVersion;
    throw wrapped;
  }
}

function validateHttpsUrl(raw, { allowHttp = false } = {}) {
  let url;
  try {
    url = new URL(String(raw || ""));
  } catch (_error) {
    throw new Error(`Invalid update URL: ${raw}`);
  }
  if (url.protocol !== "https:" && !(allowHttp && url.protocol === "http:")) {
    throw new Error(`Update URL must use HTTPS: ${url}`);
  }
  return url;
}

function selectAgentArtifact(manifest, platformKey, expectedChannel = "stable") {
  if (!manifest || Number(manifest.schemaVersion) !== 1) throw new Error("Unsupported agent update manifest schema");
  const manifestChannel = String(manifest.channel || "").trim().toLowerCase();
  const normalizedExpectedChannel = String(expectedChannel || "stable").trim().toLowerCase();
  if (manifestChannel !== normalizedExpectedChannel) {
    throw new Error(
      `Unexpected agent update channel: received ${manifest.channel || "missing"}, expected ${normalizedExpectedChannel}`
    );
  }
  const version = parseVersion(manifest.version)?.raw;
  if (!version) throw new Error("Agent update manifest has an invalid version");
  const artifact = manifest.platforms?.[platformKey];
  const minimumAutoUpdateVersion = manifest.minimumAutoUpdateVersion
    ? parseVersion(manifest.minimumAutoUpdateVersion)?.raw
    : null;
  if (manifest.minimumAutoUpdateVersion && !minimumAutoUpdateVersion) {
    throw new Error("Agent update manifest has an invalid minimumAutoUpdateVersion");
  }
  if (!artifact) return { version, minimumAutoUpdateVersion, artifact: null };
  const sha256 = String(artifact.sha256 || "").trim().toLowerCase();
  if (!/^[a-f0-9]{64}$/.test(sha256)) throw new Error(`Invalid SHA-256 for ${platformKey}`);
  return { version, minimumAutoUpdateVersion, artifact: { url: String(artifact.url || ""), sha256 } };
}

async function fetchJson(url, { fetchFn = globalThis.fetch, allowHttp = false } = {}) {
  if (typeof fetchFn !== "function") throw new Error("This Node.js version does not provide fetch");
  const safeUrl = validateHttpsUrl(url, { allowHttp });
  const response = await fetchFn(safeUrl, { headers: { Accept: "application/json" } });
  if (!response.ok) throw new Error(`Update manifest request failed with HTTP ${response.status}`);
  return response.json();
}

async function downloadVerifiedArtifact(url, destination, expectedSha256, {
  fetchFn = globalThis.fetch,
  allowHttp = false,
  maxBytes = 250 * 1024 * 1024,
} = {}) {
  const safeUrl = validateHttpsUrl(url, { allowHttp });
  const response = await fetchFn(safeUrl);
  if (!response.ok) throw new Error(`Agent update download failed with HTTP ${response.status}`);
  const contentLength = Number(response.headers?.get?.("content-length") || 0);
  if (contentLength > maxBytes) throw new Error(`Agent update exceeds ${maxBytes} bytes`);
  const bytes = Buffer.from(await response.arrayBuffer());
  if (bytes.length > maxBytes) throw new Error(`Agent update exceeds ${maxBytes} bytes`);
  const actualSha256 = crypto.createHash("sha256").update(bytes).digest("hex");
  if (actualSha256 !== expectedSha256) {
    throw new Error(`Agent update SHA-256 mismatch: expected ${expectedSha256}, received ${actualSha256}`);
  }
  fs.mkdirSync(path.dirname(destination), { recursive: true });
  fs.writeFileSync(destination, bytes, { mode: 0o600 });
  return { bytes: bytes.length, sha256: actualSha256 };
}

async function extractZip(zipPath, destination, { runner = runProcess, platform = process.platform } = {}) {
  await validateArchiveEntries(zipPath, { runner, platform });
  fs.rmSync(destination, { recursive: true, force: true });
  fs.mkdirSync(destination, { recursive: true });
  let result;
  if (platform === "win32") {
    const escapedZip = zipPath.replace(/'/g, "''");
    const escapedDestination = destination.replace(/'/g, "''");
    result = await runner("powershell", [
      "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command",
      `Expand-Archive -LiteralPath '${escapedZip}' -DestinationPath '${escapedDestination}' -Force`,
    ], { timeoutMs: 120_000, platform });
  } else if (platform === "darwin") {
    result = await runner("ditto", ["-x", "-k", zipPath, destination], { timeoutMs: 120_000, platform });
  } else {
    result = await runner("unzip", ["-q", zipPath, "-d", destination], { timeoutMs: 120_000, platform });
  }
  requireSuccessful(result, "Agent update extraction");
}

function validateArchivePath(entry) {
  const normalized = String(entry || "").replace(/\\/g, "/").trim();
  if (!normalized) return true;
  if (normalized.startsWith("/") || /^[A-Za-z]:\//.test(normalized)) return false;
  const segments = normalized.split("/");
  return !segments.includes("..");
}

async function validateArchiveEntries(zipPath, { runner = runProcess, platform = process.platform } = {}) {
  const result = platform === "win32"
    ? await runner("tar", ["-tf", zipPath], { timeoutMs: 60_000, platform })
    : await runner("unzip", ["-Z1", zipPath], { timeoutMs: 60_000, platform });
  const output = requireSuccessful(result, "Agent update archive inspection");
  const invalidEntry = output.split(/\r?\n/).find((entry) => !validateArchivePath(entry));
  if (invalidEntry) throw new Error(`Unsafe path in agent update archive: ${invalidEntry}`);
  return output.split(/\r?\n/).filter(Boolean);
}

function findExtractedAgentRoot(extractedPath) {
  const candidates = [extractedPath, path.join(extractedPath, "agent")];
  for (const candidate of candidates) {
    if (fs.existsSync(path.join(candidate, "agent.js")) && fs.existsSync(path.join(candidate, "package.json"))) {
      return candidate;
    }
  }
  throw new Error("Agent update archive does not contain agent.js and package.json");
}

function copyTree(source, destination, { excludedNames = new Set() } = {}) {
  fs.mkdirSync(destination, { recursive: true });
  for (const entry of fs.readdirSync(source, { withFileTypes: true })) {
    if (excludedNames.has(entry.name)) continue;
    const sourcePath = path.join(source, entry.name);
    const destinationPath = path.join(destination, entry.name);
    if (entry.isDirectory()) {
      copyTree(sourcePath, destinationPath, { excludedNames });
    } else if (entry.isFile()) {
      fs.copyFileSync(sourcePath, destinationPath);
      if (process.platform !== "win32") fs.chmodSync(destinationPath, fs.statSync(sourcePath).mode);
    }
  }
}

function applyExtractedAgentUpdate({
  extractedPath,
  installRoot,
  backupRoot,
  expectedVersion,
}) {
  const sourceRoot = findExtractedAgentRoot(extractedPath);
  const packageJson = JSON.parse(fs.readFileSync(path.join(sourceRoot, "package.json"), "utf8"));
  const packageVersion = parseVersion(packageJson.version)?.raw;
  if (packageVersion !== expectedVersion) {
    throw new Error(`Agent archive version is ${packageVersion || "invalid"}, expected ${expectedVersion}`);
  }
  const excludedNames = new Set([".env", "logs", "runtime-status.json", "update-staging", "update-backups"]);
  fs.mkdirSync(backupRoot, { recursive: true });
  copyTree(installRoot, backupRoot, { excludedNames });
  try {
    copyTree(sourceRoot, installRoot, { excludedNames });
  } catch (error) {
    copyTree(backupRoot, installRoot, { excludedNames });
    throw new Error(`Agent update copy failed; backup restored: ${error.message}`);
  }
  return { sourceRoot, packageVersion, backupRoot };
}

class IdleUpdateManager {
  constructor(options = {}) {
    this.agentVersion = options.agentVersion || "dev";
    this.manifestUrl = options.manifestUrl || "";
    this.channel = String(options.channel || "stable").trim().toLowerCase() || "stable";
    this.platformKey = options.platformKey || `${process.platform}-${process.arch}`;
    this.logDir = path.resolve(options.logDir || path.join(process.cwd(), "logs"));
    this.installRoot = path.resolve(options.installRoot || process.cwd());
    this.codexEnabled = options.codexEnabled !== false;
    this.agentEnabled = options.agentEnabled !== false;
    this.codexCheckMs = Math.max(60_000, options.codexCheckMs || DEFAULT_UPDATE_CHECK_MS);
    this.agentCheckMs = Math.max(60_000, options.agentCheckMs || DEFAULT_UPDATE_CHECK_MS);
    this.runner = options.runner || runProcess;
    this.fetchFn = options.fetchFn || globalThis.fetch;
    this.allowHttp = options.allowHttp === true;
    this.logger = options.logger || console;
    this.onStatus = options.onStatus || (() => {});
    this.now = options.now || (() => Date.now());
    this.lastCodexCheckAt = 0;
    this.lastAgentCheckAt = 0;
    this.failedCodexVersions = new Set();
  }

  async maintain({ forceCodex = false } = {}) {
    const result = { codex: null, agent: null };
    const now = this.now();
    if (this.codexEnabled && (forceCodex || now - this.lastCodexCheckAt >= this.codexCheckMs)) {
      this.lastCodexCheckAt = now;
      try {
        result.codex = await updateCodexIfNeeded({
          runner: this.runner,
          force: forceCodex,
          skippedVersions: this.failedCodexVersions,
          logger: this.logger,
          onState: (codex) => this.onStatus("UPDATING_CODEX", { codex, action: "Actualizando Codex CLI" }),
        });
      } catch (error) {
        if (error.targetVersion) this.failedCodexVersions.add(error.targetVersion);
        result.codex = {
          checked: true,
          updated: false,
          currentVersion: error.currentVersion || null,
          latestVersion: error.latestVersion || error.targetVersion || null,
          error: error.message,
        };
        this.logger.warn?.(`[agent][update] Codex maintenance failed: ${error.message}`);
      }
    }

    if (this.agentEnabled && this.manifestUrl && now - this.lastAgentCheckAt >= this.agentCheckMs) {
      this.lastAgentCheckAt = now;
      try {
        const manifest = await fetchJson(this.manifestUrl, { fetchFn: this.fetchFn, allowHttp: this.allowHttp });
        const selection = selectAgentArtifact(manifest, this.platformKey, this.channel);
        if (
          selection.minimumAutoUpdateVersion
          && parseVersion(this.agentVersion)
          && compareVersions(this.agentVersion, selection.minimumAutoUpdateVersion) < 0
        ) {
          throw new Error(
            `Agent ${this.agentVersion} is older than minimumAutoUpdateVersion ${selection.minimumAutoUpdateVersion}; manual update required`
          );
        }
        if (!selection.artifact || compareVersions(selection.version, this.agentVersion) <= 0) {
          result.agent = { checked: true, updated: false, currentVersion: this.agentVersion, latestVersion: selection.version };
        } else {
          this.onStatus("UPDATING_AGENT", {
            action: `Descargando Jarvis Agent ${selection.version}`,
            update: { currentVersion: this.agentVersion, latestVersion: selection.version },
          });
          const stageRoot = path.join(this.logDir, "update-staging", selection.version);
          const zipPath = path.join(stageRoot, "agent-update.zip");
          const extractedPath = path.join(stageRoot, "extracted");
          const artifactUrl = new URL(selection.artifact.url, this.manifestUrl).href;
          await downloadVerifiedArtifact(artifactUrl, zipPath, selection.artifact.sha256, {
            fetchFn: this.fetchFn,
            allowHttp: this.allowHttp,
          });
          await extractZip(zipPath, extractedPath, { runner: this.runner });
          const backupRoot = path.join(this.logDir, "update-backups", `${this.agentVersion}-${Date.now()}`);
          applyExtractedAgentUpdate({
            extractedPath,
            installRoot: this.installRoot,
            backupRoot,
            expectedVersion: selection.version,
          });
          result.agent = {
            checked: true,
            updated: true,
            previousVersion: this.agentVersion,
            currentVersion: selection.version,
            backupRoot,
            restartRequired: true,
          };
        }
      } catch (error) {
        result.agent = { checked: true, updated: false, error: error.message };
        this.logger.warn?.(`[agent][update] Agent maintenance failed: ${error.message}`);
      }
    }
    return result;
  }
}

module.exports = {
  CODEX_PACKAGE,
  DEFAULT_UPDATE_CHECK_MS,
  IdleUpdateManager,
  applyExtractedAgentUpdate,
  compareVersions,
  downloadVerifiedArtifact,
  extractZip,
  fetchLatestCodexVersion,
  findExtractedAgentRoot,
  inspectCodex,
  isCodexUpdateRequiredError,
  parseNpmVersionOutput,
  parseVersion,
  runProcess,
  selectAgentArtifact,
  updateCodexIfNeeded,
  validateArchiveEntries,
  validateArchivePath,
  validateHttpsUrl,
  verifyCodexNpmInstall,
};
