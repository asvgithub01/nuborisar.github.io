# Jarvis Agent Skeleton (Node)

Version actual del runtime: **0.3.0**.

Agent local MVP para el loop:

- polling cada 3s (`POST /tasks/next`)
- polling cada 3s de comandos remotos (`POST /agent-commands/next`)
- heartbeat/lease keepalive (`POST /tasks/{id}/claim-heartbeat`)
- sincronizacion incremental del Runtime Log (`PUT /tasks/{id}/runtime-log`) mientras el LLM y Gradle siguen ejecutandose
- ejecucion Codex CLI no interactiva (`codex exec`)
- ejecucion real Gradle (test + build)
- auto commit/push a rama `fix/codex-{taskId}` (y `feature/codex-{taskId}` cuando se habilite task type)
- subida de APK + log del agent y transicion final `READY_FOR_REVIEW`

## Requisitos

- Node.js 18+

## Arranque rapido (Windows)

En un paquete publico, crea primero `.env` desde `.env.example` y completa al menos
`JARVIS_AGENT_TOKEN`, `JARVIS_BASE_URL`, `JARVIS_AGENT_ID` y los workspaces. La release
no incluye credenciales.

```bat
copy .env.example .env
start-agent.cmd
```

En segundo plano (minimizado + `agent.log`):

```bat
start-agent-bg.cmd
```

Consola de estado (solo visor; cerrarla no detiene el agente):

```bat
Open Jarvis Agent Console.cmd
```

Prueba rapida one-shot (sin Codex/Gradle, util para validar flujo completo):

```bat
start-agent-fast-oneshot.cmd
```

## Arranque manual

```bash
node agent.js
```

## Instalador macOS para segundo agente

El paquete macOS incluye un launcher de doble clic que registra el MacBook como worker adicional con id propio y workspaces propios:

```text
Install Jarvis Agent.command
```

Instalacion manual equivalente:

```bash
cd agent/installers/macos
chmod +x *.sh
./install-agent.sh \
  --backend-url http://rayder.tail124179.ts.net:8080 \
  --token YOUR_AGENT_TOKEN \
  --pairing-code JARVIS-XXXX-XXXX \
  --agent-id "$(hostname -s)-jarvis-agent-02" \
  --display-name "Jarvis MacBook (agente 2)" \
  --workspace-root "$HOME/Projects"
```

El codigo se genera en **Ops > Settings > Cuenta y agentes**, caduca en 15 minutos y vincula el nuevo dispositivo al UUID Auth SDK del usuario autenticado. El instalador copia el runtime a `~/Library/Application Support/JarvisAgent/app`, genera una configuracion `0600`, escanea raices de desarrollo acotadas con timeout, crea `~/Library/LaunchAgents/com.jarvis.agent.plist` y arranca el agente con `launchctl`. Antes de sincronizar workspaces, el runtime reintenta el bootstrap y verifica mediante `/agents/me/config` que el backend reconoce el mismo id externo e interno. La URL debe ser un nombre DNS estable de Tailscale/MagicDNS accesible desde el MacBook, nunca `localhost` ni una IP literal cuando el backend corre en Windows.

Desde la version 0.2.7, el agente publica cada cambio de sus logs de Codex/Claude/OpenCode, la linea temporal de ejecucion y la salida Gradle mientras la tarea esta `RUNNING` o `BUILDING`. Ops recibe un evento SSE dedicado y mantiene polling ligero como respaldo.

Para volver a detectar proyectos despues de clonar, mover o borrar repositorios:

```bash
"$HOME/Library/Application Support/JarvisAgent/bin/jarvis-agent-projects"
```

Tambien queda un launcher de Finder en `~/Applications/Jarvis Agent/Scan Jarvis Projects.command`.
La instalacion 0.3.0 añade tambien `Open Jarvis Agent Console.command`, que muestra
`STARTING`, `LISTENING`, `WORKING`, builds y actualizaciones leyendo
`runtime-status.json` y el log, sin iniciar otro worker.

Comprobacion rapida:

```bash
./doctor-agent.sh
tail -f "$HOME/Library/Application Support/JarvisAgent/logs/agent.log"
```

El ZIP se genera con `scripts/package-agent-macos-mvp.ps1`, conserva permisos ejecutables Unix y publica checksum/manifest en `releases/macos-second-agent/`. Sigue pendiente convertirlo en `.pkg/.dmg` firmado y notarizado.

La release publica completa para Windows x64 y macOS Apple Silicon se genera con:

```powershell
powershell -ExecutionPolicy Bypass -File scripts/package-agent-030.ps1
```

El empaquetado excluye `.env`, rechaza credenciales incrustadas y produce
`releases/jarvis-agent/update/stable.json`. La primera instalacion de 0.3.0 es manual;
las siguientes versiones se descubren desde GitHub Pages y se verifican por SHA-256.


## Equipo de desarrollo agentico

Para preparar una maquina completa de desarrollo/CI local hay scripts separados:

```bash
# macOS
agent/installers/dev-platform/macos/install-dev-platform.sh --yes

# Windows PowerShell
agent\installers\dev-platform\windows\install-dev-platform.ps1 -Yes
```

Instalan/verifican Node 18+, Git, GitHub CLI, Codex CLI, Claude Code CLI y OpenCode CLI. Android Studio/SDK es opcional con `--with-android` / `-WithAndroid`.

Inventario completo de comandos y requisitos CI: [`../docs/agent-command-inventory-ci.md`](../docs/agent-command-inventory-ci.md).

Pendientes operativos del runtime/agentes: [`../docs/agent-runtime-todos.md`](../docs/agent-runtime-todos.md).


## Smoke test pre-merge

Antes de llevar esta rama a `develop`:

```powershell
powershell -ExecutionPolicy Bypass -File ..\scripts\e2e\test-agent-platform-installers.ps1
```

O desde `agent/`:

```bash
npm run test:platform-installers
```

## Variables de entorno

Revisa `.env.example`:

- `JARVIS_BASE_URL`
- `JARVIS_AGENT_TOKEN`
- `JARVIS_AGENT_TOKEN_POOL` (opcional, rotación de token de backend en 401/403)
- `JARVIS_AGENT_ID`
- `JARVIS_AGENT_DISPLAY_NAME` (nombre visible del dispositivo en Ops)
- `JARVIS_OWNER_USER_ID` (scope opcional de propietario)
- `JARVIS_AGENT_PAIRING_CODE` (codigo de un solo uso generado por la cuenta de Ops)
- `JARVIS_WORKSPACE_PATHS` (repositorios directos separados por `;` o `,`)
- `JARVIS_WORKSPACE_ROOTS` (raices que el agente escanea y registra)
- `JARVIS_WORKSPACE_SCAN_DEPTH`
- `JARVIS_PROJECT_SCAN_ROOTS` (raices separadas por `;` usadas por la utilidad macOS)

Para agentes remotos, `JARVIS_BASE_URL` debe usar siempre el nombre MagicDNS de
Tailscale del backend (por ejemplo `http://rayder.tail124179.ts.net:8080`), nunca
una IP LAN o Tailscale literal. `localhost` se reserva al agente que corre en el
mismo PC que backend.
- `JARVIS_PROJECT_SCAN_TIMEOUT_SECONDS` (timeout por raiz del escaner macOS)
- `JARVIS_AGENT_RELEASE_VERSION` (version del paquete mostrada en Ops)
- `JARVIS_AGENT_BOOTSTRAP_MAX_ATTEMPTS` / `JARVIS_AGENT_BOOTSTRAP_RETRY_MS`
- `JARVIS_WORKSPACE_SYNC_MS`
- `JARVIS_POLL_MS`
- `JARVIS_HEARTBEAT_MS`
- `JARVIS_CODEX_ENABLED`
- `JARVIS_CODEX_TIMEOUT_MS`
- `JARVIS_CODEX_MODEL`
- `JARVIS_CLAUDE_TIMEOUT_MS` (timeout para engine `CLAUDE_CODE`, fallback a `JARVIS_CODEX_TIMEOUT_MS`)
- `JARVIS_CLAUDE_MODEL` (fallback local si runtime Claude no define modelo)
- `JARVIS_OPENCODE_TIMEOUT_MS` (timeout para engine `OPENCODE`; `0` lo desactiva para esperar a LLMs locales lentos)
- `JARVIS_OPENCODE_MODEL` (modelo por defecto de OpenCode en formato `provider/model`; runtime LLM tiene prioridad)
- `JARVIS_CODEX_SKIP_GIT_REPO_CHECK`
- `JARVIS_CODEX_AUTO_UPDATE` (default `true`; solo se ejecuta cuando no hay task activa)
- `JARVIS_CODEX_UPDATE_INTERVAL_HOURS` (default `6`)
- `JARVIS_CODEX_ACCOUNT_POOL` (opcional, pool de cuentas para failover)
- `JARVIS_CLAUDE_ACCOUNT_POOL` (opcional, pool de cuentas para Claude)
- `JARVIS_TOKEN_EXPIRY_ALERT_DAYS` (umbral de alerta de caducidad, default `30`)
- `JARVIS_RUN_TESTS`
- `JARVIS_RUN_BUILD`
- `JARVIS_GRADLE_TEST_TASK`
- `JARVIS_GRADLE_BUILD_TASK`
- `JARVIS_GRADLE_JAVA_HOME` (opcional; si queda vacio, macOS prioriza el JBR de Android Studio y despues OpenJDK 21/17 antes que el `JAVA_HOME` global)
- `JARVIS_GRADLE_TIMEOUT_MS`
- `JARVIS_GIT_AUTO_COMMIT`
- `JARVIS_GIT_AUTO_PUSH`
- `JARVIS_GIT_PUSH_REMOTE`
- `JARVIS_GIT_USER_NAME` (opcional: setea `git config user.name` local por repo)
- `JARVIS_GIT_USER_EMAIL` (opcional: setea `git config user.email` local por repo)
- `JARVIS_GIT_AUTO_PR` (`true` para crear PR automatica tras push)
- `JARVIS_GIT_PR_BASE` (default `main`)
- `JARVIS_GIT_PR_DRAFT` (`true/false`)
- `JARVIS_GITHUB_TOKEN` (opcional; alternativa a `GH_TOKEN` para `gh pr create`)
- `JARVIS_GIT_LOCAL_EXCLUDE_PATTERNS` (opcional, coma-separado)
- `JARVIS_RESTORE_ORIGINAL_BRANCH` (`true/false`, recomendado `true` para volver a la rama original tras cada task)
- `JARVIS_ONE_SHOT`
- `JARVIS_ONE_SHOT_IDLE_TIMEOUT_MS`
- `JARVIS_BACKEND_AUTORESTART_ENABLED` (watchdog para levantar backend si cae)
- `JARVIS_BACKEND_RESTART_ONLY_LOCAL` (solo auto-restart si `JARVIS_BASE_URL` es localhost)
- `JARVIS_BACKEND_HEALTH_PATH` (endpoint de probe, por defecto `/actuator/health`)
- `JARVIS_BACKEND_RESTART_COMMAND` (comando ejecutado para levantar backend)
- `JARVIS_BACKEND_RESTART_COOLDOWN_MS` (cooldown entre reintentos de restart)
- `JARVIS_BACKEND_RESTART_WAIT_MS` (tiempo maximo esperando que backend vuelva)
- `JARVIS_BACKEND_PROBE_TIMEOUT_MS` (timeout de cada probe de salud)
- `JARVIS_ARTIFACT_UPLOAD_TIMEOUT_MS` (timeout de subida binaria de APK; default `120000`)
- `JARVIS_APK_SOURCE_PATH` (opcional)
- `JARVIS_AGENT_LOG_DIR`
- `JARVIS_AGENT_STATUS_FILE` (snapshot JSON atomico consumido por la consola)
- `JARVIS_AGENT_AUTO_UPDATE` (default `true`)
- `JARVIS_AGENT_UPDATE_URL` (manifest HTTPS `stable.json`)
- `JARVIS_AGENT_UPDATE_CHANNEL` (`stable` por defecto; permite probar `candidate`)
- `JARVIS_AGENT_UPDATE_INTERVAL_HOURS` (default `6`)
- `JARVIS_AGENT_UPDATE_ALLOW_HTTP` (solo tests; debe permanecer `false` en produccion)
- `JARVIS_AGENT_ALLOW_SOURCE_SELF_UPDATE` (default `false`; evita sobrescribir un checkout Git)

### Formato de pools de cuentas

`JARVIS_CODEX_ACCOUNT_POOL`, `JARVIS_CLAUDE_ACCOUNT_POOL` y `JARVIS_AGENT_TOKEN_POOL` usan:

`label|token|YYYY-MM-DD;label2|token2|YYYY-MM-DD`

- `label`: nombre de la cuenta (ej. `codex-main`, `codex-backup`)
- `token`: API key de esa cuenta
- `YYYY-MM-DD`: fecha de caducidad para alertas preventivas (30 días por defecto)

Cuando Codex falla por límite/cuota/auth en una cuenta, el agente rota a la siguiente cuenta del pool automáticamente.
Si una llamada al backend devuelve `401/403`, el agente rota al siguiente token de `JARVIS_AGENT_TOKEN_POOL`.

## Flujo por task

0. Poll de comandos remotos (`/agent-commands/next`) y ejecución local cuando hay orden pendiente.
1. Claim de task (`/tasks/next`) y keepalive lease.
2. Checkout/creacion de rama `fix/codex-{taskId}`.
3. Ejecucion del engine efectivo del task (`CODEX`, `CLAUDE_CODE` u `OPENCODE`) con historial de mensajes.
4. Estado `BUILDING` + Gradle build (`assembleDebug` por defecto) y subida inmediata del APK.
5. Gradle test (`testDebugUnitTest` por defecto). Si falla, la task conserva el APK ya registrado y pasa a `WAITING_USER` con el error.
6. Commit/push automatico (si hay cambios).
7. Creacion automatica de PR (opcional, si `JARVIS_GIT_AUTO_PR=true` y `gh` autenticado con token).
8. Registro de APK y log en backend. El APK se transfiere como multipart a `/tasks/{id}/artifacts/apk/upload`, por lo que funciona aunque agente y backend esten en equipos/SO distintos; `/tasks/{id}/artifacts/apk` se conserva para rutas locales legacy.
9. Estado `READY_FOR_REVIEW`.

### Comando remoto implementado (Bloque A Beta)

- `REMOTE_MERGE_TASK_BRANCH`:
  - checkout base branch,
  - pull `--ff-only` (si existe remoto),
  - merge de rama de task,
  - push a remoto,
  - delete local branch (best effort).
- `REMOTE_CREATE_PROJECT`:
  - crea el directorio en la ruta absoluta elegida desde Ops;
  - inicializa Git/main y escribe el scaffold Jarvis;
  - persiste el nuevo repositorio en `JARVIS_WORKSPACE_PATHS`;
  - sincroniza el workspace antes de lanzar la tarea bootstrap.
- `REMOTE_PROJECT_INSPECT`:
  - lee Git overview y diff en el equipo propietario del workspace;
  - detecta o elimina contexto copiado en el filesystem remoto;
  - devuelve JSON a Ops sin traducir rutas macOS a rutas Windows.
- `REMOTE_PROJECT_HANDOFF`:
  - publica la rama limpia del agente origen y verifica el commit en `origin`;
  - recibe exactamente ese commit por checkout/fast-forward en el agente destino;
  - bloquea cambios locales, ramas divergentes, detached HEAD, origin ausente/distinto
    y cualquier push/fetch fallido; nunca hace `reset --hard` ni sobrescribe trabajo.
- Reporte de resultado al backend:
  - `POST /agent-commands/{id}/complete`.

Si el repo no tiene `gradlew`/`gradlew.bat` (ej. web), el agente:

- no rompe la tarea por falta de Gradle
- salta tests/build Android con mensaje explicito
- mantiene flujo de Codex + git commit/push + `READY_FOR_REVIEW`

Si falla cualquier paso:

- mensaje `system` con error
- estado `WAITING_USER`

Si el backend local se cae durante polling/requests del agente, el watchdog puede intentar levantarlo automaticamente ejecutando `JARVIS_BACKEND_RESTART_COMMAND` y reintentando la llamada una vez.

Cuando hay push a GitHub, el agent incluye un hint de URL probable de GitHub Pages en el mensaje de sistema (si aplica).
